package com.hyewon.bot

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** /cmds 패널 아래에 붙는 '자리비움 자동응답' 패널 */
object AwayCard {

    private class AppItem(val pkg: String, val name: String, val game: Boolean)

    @Volatile private var apps: List<AppItem>? = null
    private val ui = Handler(Looper.getMainLooper())

    private fun loadApps(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = ArrayList<AppItem>()
        for (ri in pm.queryIntentActivities(intent, 0)) {
            val ai = ri.activityInfo.applicationInfo
            if (ai.packageName == ctx.packageName) continue
            @Suppress("DEPRECATION")
            val game = ai.category == ApplicationInfo.CATEGORY_GAME ||
                (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            out.add(AppItem(ai.packageName, ri.loadLabel(pm).toString(), game))
        }
        return out.distinctBy { it.pkg }
    }

    fun build(
        ctx: Context, base: Int, fg: Int, softCol: Int, lineCol: Int, hintCol: Int,
        closePanel: () -> Unit
    ): LinearLayout {
        val dp = ctx.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun round(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
            setColor(color)
            cornerRadius = r * dp
            if (stroke != null) setStroke(px(1), stroke)
        }
        fun wrapLp() = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(18), px(14), px(18), px(14))
            background = round(base, 22, lineCol)
        }

        fun pill(t: String): TextView = TextView(ctx).apply {
            text = t
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(px(12), px(8), px(12), px(8))
            isClickable = true
        }

        fun paint(tv: TextView, on: Boolean) {
            tv.setTextColor(if (on) base else fg)
            tv.background = round(if (on) fg else android.graphics.Color.TRANSPARENT, 12, lineCol)
        }

        // ----- 제목 줄 -----
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(ctx).apply {
            text = "🎮 자리비움 자동응답"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(fg)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val onTv = pill("")
        head.addView(onTv)
        card.addView(head)

        // ----- 정보/선택 줄 -----
        val infoTv = TextView(ctx).apply { textSize = 14f; setTextColor(fg) }
        val groupTv = pill("")
        val pickTv = pill("게임 선택 ▾")
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(infoTv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(groupTv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = px(8) })
        row.addView(pickTv)
        card.addView(row, wrapLp().apply { topMargin = px(10) })

        // ----- 경고 (권한) -----
        val warn = TextView(ctx).apply {
            textSize = 13f
            setTextColor(fg)
            background = round(softCol, 10, lineCol)
            setPadding(px(10), px(8), px(10), px(8))
            visibility = View.GONE
            isClickable = true
        }
        card.addView(warn, wrapLp().apply { topMargin = px(8) })

        // ----- 게임 목록 -----
        val listBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val search = EditText(ctx).apply {
            hint = "앱 검색"
            setHintTextColor(hintCol)
            setTextColor(fg)
            textSize = 14f
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
            background = round(softCol, 12, lineCol)
            setPadding(px(10), px(8), px(10), px(8))
        }
        listBox.addView(search, wrapLp())
        val listCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(ctx).apply { addView(listCol) }
        listBox.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(150)).apply { topMargin = px(6) })
        card.addView(listBox, wrapLp().apply { topMargin = px(8) })

        fun refreshInfo() {
            val n = Cfg.awayGames(ctx).size
            infoTv.text = if (n == 0) "선택한 게임 없음" else "선택한 게임 ${n}개"
            val on = Cfg.awayOn(ctx)
            onTv.text = if (on) "켜짐" else "꺼짐"
            paint(onTv, on)
            val g = Cfg.awayGroup(ctx)
            groupTv.text = if (g) "단톡방 포함" else "1:1만"
            paint(groupTv, g)
            paint(pickTv, listBox.visibility == View.VISIBLE)
            val msg = when {
                !Foreground.hasAccess(ctx) -> "⚠ '사용 정보 접근'을 허용해야 지금 하는 게임을 알 수 있어요. 눌러서 열기"
                !Replier.connected -> "⚠ '알림 접근'을 켜야 자동 답장이 돼요. 눌러서 열기"
                else -> ""
            }
            warn.text = msg
            warn.visibility = if (msg.isEmpty()) View.GONE else View.VISIBLE
            warn.setOnClickListener {
                val act = if (!Foreground.hasAccess(ctx)) Settings.ACTION_USAGE_ACCESS_SETTINGS
                else Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
                try {
                    ctx.startActivity(Intent(act).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    closePanel()
                } catch (e: Exception) { }
            }
        }

        fun renderList() {
            listCol.removeAllViews()
            val all = apps
            if (all == null) {
                listCol.addView(TextView(ctx).apply { text = "불러오는 중…"; setTextColor(hintCol); setPadding(px(6), px(8), px(6), px(8)) })
                return
            }
            val q = search.text.toString().trim().lowercase()
            val chosen = Cfg.awayGames(ctx)
            val shown = all.filter { q.isEmpty() || it.name.lowercase().contains(q) }
                .sortedWith(compareByDescending<AppItem> { chosen.contains(it.pkg) }
                    .thenByDescending { it.game }
                    .thenBy { it.name.lowercase() })
                .take(60)
            if (shown.isEmpty()) {
                listCol.addView(TextView(ctx).apply { text = "없어요"; setTextColor(hintCol); setPadding(px(6), px(8), px(6), px(8)) })
            }
            for (a in shown) {
                val tv = TextView(ctx).apply {
                    textSize = 15f
                    setTextColor(fg)
                    setPadding(px(8), px(9), px(8), px(9))
                    isClickable = true
                }
                fun paintRow() {
                    tv.text = (if (Cfg.awayGames(ctx).contains(a.pkg)) "☑  " else "☐  ") + a.name + (if (a.game) "  🎮" else "")
                }
                paintRow()
                tv.setOnClickListener {
                    val s = Cfg.awayGames(ctx).toMutableSet()
                    if (!s.remove(a.pkg)) s.add(a.pkg)
                    Cfg.setAwayGames(ctx, s)
                    paintRow()
                    refreshInfo()
                }
                listCol.addView(tv)
            }
        }

        onTv.setOnClickListener {
            Cfg.p(ctx).edit().putBoolean("awayOn", !Cfg.awayOn(ctx)).apply()
            refreshInfo()
        }
        groupTv.setOnClickListener {
            Cfg.p(ctx).edit().putBoolean("awayGroup", !Cfg.awayGroup(ctx)).apply()
            refreshInfo()
        }
        pickTv.setOnClickListener {
            val open = listBox.visibility != View.VISIBLE
            listBox.visibility = if (open) View.VISIBLE else View.GONE
            pickTv.text = if (open) "접기 ▴" else "게임 선택 ▾"
            refreshInfo()
            if (open) {
                renderList()
                if (apps == null) {
                    Thread {
                        val list = try { loadApps(ctx) } catch (e: Exception) { emptyList() }
                        apps = list
                        ui.post { renderList() }
                    }.start()
                }
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { renderList() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        refreshInfo()
        return card
    }
}
