package com.hyewon.bot

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import java.util.concurrent.ConcurrentHashMap

/**
 * 카톡 알림에 붙어 있는 '답장' 기능(RemoteInput)을 방 이름별로 보관해 두었다가,
 * 입력창을 건드리지 않고 스크립트로 메시지를 보냄.
 */
object Replier {
    class Session(val action: Notification.Action, val inputs: Array<RemoteInput>, val room: String) {
        @Volatile var time: Long = System.currentTimeMillis()
    }

    private val sessions = ConcurrentHashMap<String, Session>()

    @Volatile var connected = false

    fun count(): Int = sessions.size
    fun rooms(): List<String> = sessions.keys.toList()

    class Msg(val room: String, val sender: String, val text: String, val isGroup: Boolean)

    /** 알림에서 방 이름과 답장 기능을 뽑아 저장. 답장 기능이 있는 알림이면 메시지 정보를 돌려줌 */
    fun capture(n: Notification): Msg? {
        val ex = n.extras ?: return null
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
        val conv = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()?.trim() ?: ""
        val sub = ex.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.trim() ?: ""
        var text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim() ?: ""
        if (text.isEmpty()) { // 메시지 묶음(MessagingStyle) 알림이면 마지막 메시지를 사용
            try {
                val arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
                val last = arr?.lastOrNull() as? Bundle
                text = last?.getCharSequence("text")?.toString()?.trim() ?: ""
            } catch (e: Exception) { }
        }
        val room = when {
            conv.isNotEmpty() -> conv
            sub.isNotEmpty() -> sub
            else -> title
        }
        if (room.isEmpty()) return null
        val isGroup = conv.isNotEmpty() || sub.isNotEmpty()

        val actions = ArrayList<Notification.Action>()
        n.actions?.let { actions.addAll(it) }
        try {
            Notification.WearableExtender(n).actions?.let { actions.addAll(it) }
        } catch (e: Exception) { }
        val act = actions.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return null
        val ris = act.remoteInputs ?: return null

        val old = sessions[room]
        sessions[room] = Session(act, ris, room)
        if (old == null) Bridge.log("알림 답장 준비됨: $room")
        return Msg(room, if (isGroup) title else room, text, isGroup)
    }

    fun has(names: Collection<String>): Boolean = find(names) != null

    private fun find(names: Collection<String>): Session? {
        var best: Session? = null
        for (nm in names) {
            val s = sessions[nm.trim()] ?: continue
            if (best == null || s.time > best.time) best = s
        }
        return best
    }

    /** 방 이름이 names 중 하나와 정확히 같은 세션으로 전송. 성공하면 true */
    fun send(ctx: Context, names: Collection<String>, text: String): Boolean {
        val s = find(names) ?: return false
        return try {
            val intent = Intent()
            val b = Bundle()
            for (ri in s.inputs) b.putCharSequence(ri.resultKey, text)
            RemoteInput.addResultsToIntent(s.inputs, intent, b)
            if (Build.VERSION.SDK_INT >= 28) {
                RemoteInput.setResultsSource(intent, RemoteInput.SOURCE_FREE_FORM_INPUT)
            }
            s.action.actionIntent.send(ctx, 0, intent)
            true
        } catch (e: Exception) {
            Bridge.log("알림 답장 실패(${s.room}): ${e.message}")
            sessions.remove(s.room)
            false
        }
    }
}
