package com.hyewon.bot

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * 게임 같은 다른 앱 위에 뜨는 작은 알림창.
 * 가볍게: 애니메이션 없음, 글자만 바꿈, 요약 글자는 0.12초에 한 번만 갱신, 하드웨어 가속 켬.
 */
class AwayOverlay(private val svc: AccessibilityService, private val h: Handler) {

    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: View? = null
    private var bodyTv: TextView? = null
    private val body = StringBuilder()
    @Volatile private var refreshPending = false
    private val dismissTask = Runnable { hideNow() }
    private val refreshTask = Runnable {
        refreshPending = false
        val t = synchronized(body) { body.toString() }
        bodyTv?.text = if (t.isEmpty()) "요약하는 중…" else t
    }

    private val bg = 0xF2121318.toInt()
    private val btnBg = 0xFF2C2E36.toInt()
    private val textMain = Color.WHITE
    private val textSub = 0xFFC9CBD2.toInt()

    /** 알림 + 선택지 보여주기 (어느 스레드에서 불러도 됨) */
    fun show(title: String, text: String, options: List<Pair<String, () -> Unit>>, autoHideMs: Long) {
        h.post { render(title, text, options, autoHideMs, false) }
    }

    fun summaryStart(who: String) {
        synchronized(body) { body.setLength(0) }
        h.post { render("📝 ${who}님 메시지 요약 중…", "요약하는 중…", emptyList(), 0L, true) }
    }

    fun summaryReset() {
        synchronized(body) { body.setLength(0) }
        schedule()
    }

    fun summaryDelta(d: String) {
        synchronized(body) { body.append(d) }
        schedule()
    }

    private fun schedule() {
        if (!refreshPending) {
            refreshPending = true
            h.postDelayed(refreshTask, 120)
        }
    }

    fun summaryDone(who: String, full: String, options: List<Pair<String, () -> Unit>>) {
        h.post { render("📝 ${who}님 메시지 요약", full, options, 90000L, false) }
    }

    fun summaryFail(who: String, msg: String) {
        h.post { render("📝 ${who}님 요약 실패", msg.take(160), emptyList(), 15000L, false) }
    }

    fun hide() {
        h.post { hideNow() }
    }

    private fun hideNow() {
        h.removeCallbacks(dismissTask)
        h.removeCallbacks(refreshTask)
        refreshPending = false
        val v = root
        if (v != null) {
            try { wm.removeView(v) } catch (e: Exception) { }
        }
        root = null
        bodyTv = null
    }

    private fun render(
        title: String, text: String, options: List<Pair<String, () -> Unit>>,
        autoHideMs: Long, streaming: Boolean
    ) {
        hideNow()
        val dm = svc.resources.displayMetrics
        val dp = dm.density
        fun px(v: Int) = (v * dp).toInt()

        val col = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(10), px(7), px(10), px(8))
            background = GradientDrawable().apply { setColor(bg); cornerRadius = px(12).toFloat() }
        }

        val head = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(svc).apply {
            this.text = title
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(textMain)
            maxLines = 1
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(TextView(svc).apply {
            this.text = "✕"
            textSize = 15f
            setTextColor(textSub)
            setPadding(px(10), px(2), px(2), px(2))
            setOnClickListener { hideNow() }
        })
        col.addView(head)

        val tv = TextView(svc).apply {
            this.text = text
            textSize = 12f
            setTextColor(textSub)
            maxLines = if (streaming || title.contains("요약")) 9 else 2
            setPadding(0, px(3), 0, px(4))
        }
        col.addView(tv)
        if (streaming) bodyTv = tv

        if (options.isNotEmpty()) {
            val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL }
            for ((i, o) in options.withIndex()) {
                row.addView(TextView(svc).apply {
                    this.text = o.first
                    textSize = 12f
                    setTextColor(textMain)
                    maxLines = 3
                    gravity = Gravity.CENTER_VERTICAL
                    minHeight = px(38)
                    setPadding(px(8), px(5), px(8), px(5))
                    background = GradientDrawable().apply { setColor(btnBg); cornerRadius = px(9).toFloat() }
                    setOnClickListener {
                        hideNow()
                        try { o.second() } catch (e: Exception) { Bridge.log("선택지 전송 오류: ${e.message}") }
                    }
                }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (i > 0) leftMargin = px(6)
                })
            }
            col.addView(row)
        }

        val w = minOf((dm.widthPixels * 0.92).toInt(), px(440))
        val lp = WindowManager.LayoutParams(
            w, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = px(6)
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            wm.addView(col, lp)
            root = col
            if (autoHideMs > 0) h.postDelayed(dismissTask, autoHideMs)
        } catch (e: Exception) {
            Bridge.log("게임 화면 위 알림을 못 띄웠어요: ${e.message}")
        }
    }
}
