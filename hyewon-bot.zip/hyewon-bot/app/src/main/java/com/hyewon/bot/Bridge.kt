package com.hyewon.bot

import android.util.Log
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/** 화면(MainActivity)과 서비스가 주고받는 로그/요청 */
object Bridge {
    @Volatile var dumpRequested = false
    private val logs = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.KOREA)

    @Synchronized
    fun log(s: String) {
        Log.d("HyewonBot", s)
        logs.addLast(fmt.format(Date()) + "  " + s)
        while (logs.size > 40) logs.removeFirst()
    }

    @Synchronized
    fun text(): String = logs.joinToString("\n")
}
