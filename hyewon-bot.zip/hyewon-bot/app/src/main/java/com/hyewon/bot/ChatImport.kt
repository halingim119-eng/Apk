package com.hyewon.bot

import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.util.ArrayDeque
import java.util.zip.ZipInputStream

/**
 * 카톡 '대화내용 내보내기 → 텍스트만 저장' 파일을 읽어서 메시지 목록으로 바꿈.
 * 지원 형식
 *  - 안드로이드:  [이름] [오후 3:21] 내용        (날짜 줄: --------------- 2024년 1월 1일 월요일 ---------------)
 *  - PC/아이폰:   2024. 1. 1. 오후 3:21, 이름 : 내용
 * 여러 줄 메시지는 앞 메시지에 이어 붙임. 압축(zip)으로 받아도 안의 .txt 를 읽음.
 */
object ChatImport {
    private const val T = "(?:(?:오전|오후|AM|PM)\\s*)?\\d{1,2}:\\d{2}(?::\\d{2})?"
    private const val D = "\\d{4}\\s*(?:년|[.\\-/])\\s*\\d{1,2}\\s*(?:월|[.\\-/])\\s*\\d{1,2}\\s*(?:일|\\.)?"
    // [이름] [오후 3:21] 내용
    private val A = Regex("^\\[(.+?)\\]\\s*\\[\\s*$T\\s*\\]\\s?(.*)$")
    // 2024년 1월 1일 오후 3:21, 이름 : 내용   /   2024. 1. 1. 오후 3:21, 이름 : 내용
    private val B = Regex("^$D\\s*$T\\s*,\\s*(.+?) : (.*)$")
    // 2024년 1월 1일 오후 3:21: ○○님이 들어왔습니다.  (시스템 글)
    private val SYSTIME = Regex("^$D\\s*$T\\s*:\\s.*$")
    // 날짜만 있는 줄:  2024년 1월 1일 월요일   /   --------------- 2024년 1월 1일 월요일 ---------------
    private val DATEONLY = Regex("^$D\\s*(?:[월화수목금토일]요일)?$")
    private val DATE = Regex("^-{3,}.*-{3,}$")
    private val SYS = Regex(".*(들어왔습니다|나갔습니다|초대했습니다|내보냈습니다)\\.?$")
    private val MEDIA = Regex("^(사진|동영상|이모티콘|음성메시지|사진 \\d+장|파일: .*|삭제된 메시지입니다\\.?)$")

    /** 마지막으로 읽은 파일의 첫 줄들 (형식을 못 알아봤을 때 원인 확인용) */
    @Volatile var sample: String = ""

    private fun openText(ins: InputStream): BufferedReader {
        val bis = ins.buffered()
        bis.mark(16)
        val b0 = bis.read()
        val b1 = bis.read()
        bis.reset()
        if (b0 == 'P'.code && b1 == 'K'.code) {
            val zip = ZipInputStream(bis)
            while (true) {
                val e = zip.nextEntry ?: break
                if (!e.isDirectory && e.name.lowercase().endsWith(".txt")) break
            }
            return BufferedReader(InputStreamReader(zip, Charsets.UTF_8), 1 shl 16)
        }
        val cs = when {
            b0 == 0xFF && b1 == 0xFE -> Charsets.UTF_16LE
            b0 == 0xFE && b1 == 0xFF -> Charsets.UTF_16BE
            else -> Charsets.UTF_8
        }
        return BufferedReader(InputStreamReader(bis, cs), 1 shl 16)
    }

    /** 맨 끝(최신)에서 limit 개만 남겨서 돌려줌. myName 과 같은 이름은 '내 메시지'로 표시 */
    fun parse(ins: InputStream, myName: String, limit: Int): List<Msg> {
        val out = ArrayDeque<Msg>()
        var who: String? = null
        var sb: StringBuilder? = null
        val me = normText(myName)
        val head = ArrayList<String>()

        fun flush() {
            val b = sb ?: return
            sb = null
            val t = normText(b.toString())
            if (t.isEmpty() || MEDIA.matches(t)) return
            val w = who
            val own = w != null && me.isNotEmpty() && normText(w) == me
            out.addLast(Msg(if (own) null else w, t, own))
            if (out.size > limit) out.removeFirst()
        }

        openText(ins).use { rd ->
            var first = true
            while (true) {
                var line = rd.readLine() ?: break
                if (first) { line = line.removePrefix("\uFEFF"); first = false }
                if (head.size < 4 && line.isNotBlank()) head.add(line.trim().take(40))
                val tl = line.trim()
                val m = A.matchEntire(tl) ?: B.matchEntire(tl)
                if (m != null) {
                    flush()
                    who = m.groupValues[1].trim()
                    sb = StringBuilder(m.groupValues[2])
                } else if (DATE.matches(tl) || DATEONLY.matches(tl) || SYSTIME.matches(tl) || SYS.matches(tl)) {
                    flush()
                    who = null
                } else if (sb != null) {
                    sb!!.append('\n').append(line)
                }
            }
            flush()
        }
        sample = head.joinToString(" / ")
        return out.toList()
    }
}
