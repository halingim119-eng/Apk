package com.hyewon.bot

import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.util.ArrayDeque
import java.util.zip.ZipInputStream

/**
 * 카톡 '대화내용 내보내기 → 텍스트만 저장' 파일을 읽어서 메시지 목록으로 바꿈.
 * 지원 형식
 *  - 안드로이드:  [이름] [오후 3:21] 내용        (날짜 줄: --------------- 2024년 1월 1일 월요일 ---------------)
 *  - PC/아이폰:   2024. 1. 1. 오후 3:21, 이름 : 내용
 * 여러 줄 메시지는 앞 메시지에 이어 붙임. 압축(zip)으로 받아도 안의 .txt 를 읽음.
 */
object ChatImport {
    private val A = Regex("^\\[(.+?)\\] \\[(?:오전|오후|AM|PM) ?\\d{1,2}:\\d{2}\\] ?(.*)$")
    private val B = Regex("^\\d{4}[.\\-/]\\s*\\d{1,2}[.\\-/]\\s*\\d{1,2}\\.?\\s*(?:오전|오후|AM|PM)\\s*\\d{1,2}:\\d{2},\\s*(.+?) : (.*)$")
    private val DATE = Regex("^-{3,}.*-{3,}$")
    private val SYS = Regex(".*(들어왔습니다|나갔습니다|초대했습니다|내보냈습니다)\\.?$")
    private val MEDIA = Regex("^(사진|동영상|이모티콘|음성메시지|사진 \\d+장|파일: .*|삭제된 메시지입니다\\.?)$")

    private fun openText(ins: InputStream): BufferedReader {
        val bis = ins.buffered()
        bis.mark(8)
        val b0 = bis.read()
        val b1 = bis.read()
        bis.reset()
        if (b0 == 'P'.code && b1 == 'K'.code) {
            val zip = ZipInputStream(bis)
            while (true) {
                val e = zip.nextEntry ?: break
                if (!e.isDirectory && e.name.lowercase().endsWith(".txt")) break
            }
            return BufferedReader(InputStreamReader(zip, Charsets.UTF_8), 1 shl 16)
        }
        return BufferedReader(InputStreamReader(bis, Charsets.UTF_8), 1 shl 16)
    }

    /** 맨 끝(최신)에서 limit 개만 남겨서 돌려줌. myName 과 같은 이름은 '내 메시지'로 표시 */
    fun parse(ins: InputStream, myName: String, limit: Int): List<Msg> {
        val out = ArrayDeque<Msg>()
        var who: String? = null
        var sb: StringBuilder? = null
        val me = normText(myName)

        fun flush() {
            val b = sb ?: return
            sb = null
            val t = normText(b.toString())
            if (t.isEmpty() || MEDIA.matches(t)) return
            val w = who
            val own = w != null && me.isNotEmpty() && normText(w) == me
            out.addLast(Msg(if (own) null else w, t, own))
            if (out.size > limit) out.removeFirst()
        }

        openText(ins).use { rd ->
            var first = true
            while (true) {
                var line = rd.readLine() ?: break
                if (first) { line = line.removePrefix("﻿"); first = false }
                val m = A.matchEntire(line) ?: B.matchEntire(line)
                if (m != null) {
                    flush()
                    who = m.groupValues[1].trim()
                    sb = StringBuilder(m.groupValues[2])
                } else if (DATE.matches(line.trim()) || SYS.matches(line.trim())) {
                    flush()
                    who = null
                } else if (sb != null) {
                    sb!!.append('\n').append(line)
                }
            }
            flush()
        }
        return out.toList()
    }
}
