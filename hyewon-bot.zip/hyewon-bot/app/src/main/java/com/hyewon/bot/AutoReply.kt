package com.hyewon.bot

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

/**
 * '모든 메세지 자동답변'의 알림 경로.
 * 카톡 채팅방을 열어 두지 않았을 때(백그라운드/화면 꺼짐)도, 새 메시지 알림이 오면 바로 감지해서
 * 알림 '답장' 기능으로 AI 답장을 보냄. 채팅방이 화면에 열려 있을 땐 BotService 가 화면을 읽어서 처리.
 */
object AutoReply {
    private val h = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private class Room(val room: String) {
        val pending = ArrayList<String>()
        val hist = ArrayList<Entry>()
        var task: Runnable? = null
        var lastSent = 0L
    }

    private val rooms = HashMap<String, Room>()
    private val seen = ArrayList<String>()
    private const val MIN_GAP = 2500L

    fun onMessage(ctx: Context, m: Replier.Msg, postTime: Long) {
        if (!Cfg.enabled(ctx) || !Cfg.everyone(ctx)) return
        if (m.text.isBlank() || m.text.startsWith("| ")) return
        val now = System.currentTimeMillis()
        if (now - postTime > 30000) return
        val key = m.room + "|" + m.text + "|" + postTime
        synchronized(seen) {
            if (seen.contains(key)) return
            seen.add(key)
            while (seen.size > 40) seen.removeAt(0)
        }
        // 채팅방이 화면에 열려 있으면 화면 읽기 쪽에서 처리하므로 중복 답장 방지
        if (BotService.inst?.kakaoInRoom() == true) return
        // 자리비움(게임 중) 자동응답이 맡는 중이면 양보
        if (Away.active(ctx)) return
        if (Cfg.blocks(ctx).any { b -> m.room.contains(b, true) || m.sender.contains(b, true) }) return

        h.post {
            val r = rooms.getOrPut(m.room) { Room(m.room) }
            r.pending.add(if (m.isGroup && m.sender.isNotEmpty()) "${m.sender}: ${m.text}" else m.text)
            r.task?.let { h.removeCallbacks(it) }
            val t = Runnable { fire(ctx, r) }
            r.task = t
            h.postDelayed(t, maxOf(Cfg.waitMs(ctx), 600L))
        }
    }

    private fun fire(ctx: Context, r: Room) {
        r.task = null
        if (r.pending.isEmpty()) return
        val wait = r.lastSent + MIN_GAP - System.currentTimeMillis()
        if (wait > 0) { // 너무 빠르게 연달아 답하지 않도록 잠깐 미룸
            val t = Runnable { fire(ctx, r) }
            r.task = t
            h.postDelayed(t, wait)
            return
        }
        val text = r.pending.joinToString("\n")
        r.pending.clear()
        val opts = Cfg.opts(ctx)
        val noEmoji = Cfg.noEmoji(ctx)
        Bridge.log("[자동답변] ${r.room}: ${text.replace("\n", " / ").take(300)}")
        io.execute {
            try {
                r.hist.add(Entry("user", text, ""))
                while (r.hist.size > 40) r.hist.removeAt(0)
                val raw = Ai.ask(ArrayList(r.hist), opts)
                val answer = Ai.clean(raw, noEmoji)
                if (raw.contains("[SKIP]") || answer.isEmpty()) {
                    Bridge.log("[자동답변] 답하지 않음")
                    return@execute
                }
                r.hist.add(Entry("bot", answer, ""))
                h.post {
                    if (Replier.send(ctx, listOf(r.room), answer)) {
                        r.lastSent = System.currentTimeMillis()
                        Bridge.log("[자동답변] 전송: ${answer.replace("\n", " / ").take(300)}")
                    } else {
                        Bridge.log("[자동답변] 이 방은 알림 답장이 준비 안 됨 (알림이 한 번 와야 해요)")
                    }
                }
            } catch (e: Exception) {
                Bridge.log("[자동답변] AI 실패: ${e.message}")
            }
        }
    }
}
