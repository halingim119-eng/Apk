package com.hyewon.bot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import java.io.ByteArrayInputStream

/**
 * 카톡 '대화내용 내보내기 → 텍스트만 저장' 을 '혜원 봇' 으로 공유하면 여기로 들어옴.
 * 파일을 읽어서 메시지로 바꾸고, 바로 AI 욕 검사(2번 나눠서)까지 자동으로 진행함.
 */
class ShareActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = applicationContext
        val myName = "" // 내 이름은 욕 감지 때 화면의 내 말풍선과 맞춰서 자동으로 찾음
        val uris = ArrayList<Uri>()
        var plain: String? = null
        try {
            when (intent?.action) {
                Intent.ACTION_SEND -> {
                    @Suppress("DEPRECATION")
                    val u = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                    if (u != null) uris.add(u)
                    plain = intent.getStringExtra(Intent.EXTRA_TEXT)
                }
                Intent.ACTION_SEND_MULTIPLE -> {
                    @Suppress("DEPRECATION")
                    val l = intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                    if (l != null) uris.addAll(l)
                }
            }
        } catch (e: Exception) { Bridge.log("공유 받기 실패: ${e.message}") }
        if (uris.isEmpty() && plain.isNullOrBlank()) {
            Toast.makeText(app, "받은 대화 파일이 없어요", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        Toast.makeText(app, "대화 파일을 읽는 중…", Toast.LENGTH_SHORT).show()
        // 공유로 받은 파일 읽기 권한은 이 화면이 열려 있는 동안만 유효해서, 다 읽은 뒤에 닫음
        Thread {
            var list: List<Msg> = emptyList()
            var err: String? = null
            try {
                val all = ArrayList<Msg>()
                for (u in uris) {
                    val ins = contentResolver.openInputStream(u) ?: continue
                    ins.use { all.addAll(ChatImport.parse(it, myName, Mod.SCAN_LIMIT)) }
                }
                if (all.isEmpty() && !plain.isNullOrBlank()) {
                    all.addAll(ChatImport.parse(ByteArrayInputStream(plain!!.toByteArray(Charsets.UTF_8)), myName, Mod.SCAN_LIMIT))
                }
                list = if (all.size > Mod.SCAN_LIMIT) all.takeLast(Mod.SCAN_LIMIT) else all
            } catch (e: Exception) {
                err = (e.message ?: e.toString()).take(100)
                Bridge.log("대화 파일 읽기 실패: $err")
            }
            runOnUiThread {
                val svc = BotService.inst
                when {
                    err != null -> Toast.makeText(app, "파일을 못 읽었어요: $err", Toast.LENGTH_LONG).show()
                    list.isEmpty() -> Toast.makeText(app, "메시지를 못 찾았어요. '텍스트만 저장'으로 내보낸 파일인지 확인해 주세요", Toast.LENGTH_LONG).show()
                    svc == null -> {
                        ModState.msgs = list; ModState.fromFile = true; ModState.stale = false
                        ModState.lastReport = "파일에서 메시지 ${String.format("%,d", list.size)}개 읽음 (접근성 서비스가 꺼져 있어서 AI 검사는 안 함)"
                        Toast.makeText(app, "메시지 ${list.size}개를 읽었어요. 접근성에서 '혜원 봇'을 켠 뒤 /cmds 에서 욕 감지를 눌러 주세요", Toast.LENGTH_LONG).show()
                    }
                    else -> {
                        Toast.makeText(app, "메시지 ${String.format("%,d", list.size)}개를 읽었어요. AI 검사를 시작해요", Toast.LENGTH_SHORT).show()
                        svc.mod.importAndDetect(list, svc.chipBaseColor(), svc.chipFgColor())
                    }
                }
                finish()
            }
        }.start()
    }
}
