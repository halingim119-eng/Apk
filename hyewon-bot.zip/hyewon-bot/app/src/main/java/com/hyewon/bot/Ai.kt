package com.hyewon.bot

import android.content.Context
import android.net.ConnectivityManager
import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

/** 서비스/화면 시작 때 네트워크(OkHttp)를 건드리지 않도록 컨텍스트만 따로 보관 */
object NetCtx { @Volatile var ctx: Context? = null }

data class Opts(val system: String, val temperature: Double, val maxTokens: Int, val context: Int)

/** 시사아리 AI (OpenAI 호환 /v1/chat/completions, 스트리밍) */
object Ai {
    const val URL = "https://sisaari-ai-chat-mingyu.y66675218.chatgpt.site/v1/chat/completions"
    const val DEFAULT_MODEL = "sisaari"
    const val DEFAULT_KEY = "sisaari_sk_d5f59aa3c3d6d233155e6047ce356664b6fe4a658dec0bd1905968c85ce35cba"

    private class Res(val text: String, val truncated: Boolean)
    private class RateLimitEx(val waitMs: Long, msg: String) : Exception(msg)

    // 전역 호출 속도 제한: 서버 한도(429)를 건드리지 않도록 호출 간격/횟수를 조절
    private val gate = Any()
    private val callTimes = ArrayList<Long>()
    @Volatile private var blockedUntil = 0L
    private const val MIN_GAP_MS = 1200L
    private const val MAX_PER_MIN = 10

    /** 호출 직전에 한 번 통과해야 함. 너무 잦으면 잠깐 기다리거나(간격) 막음(분당 한도) */
    private fun throttle(): Long {
        val now0 = System.currentTimeMillis()
        if (now0 < blockedUntil) {
            throw Exception("서버가 요청 한도에 걸려서 ${(blockedUntil - now0) / 1000 + 1}초 쉬는 중이에요")
        }
        return synchronized(gate) {
            var now = System.currentTimeMillis()
            callTimes.removeAll { now - it > 60000L }
            if (callTimes.size >= MAX_PER_MIN) {
                throw Exception("1분에 AI를 ${MAX_PER_MIN}번 넘게 불러서 잠깐 멈췄어요 (반복 호출 방지)")
            }
            val last = callTimes.lastOrNull()
            if (last != null && now - last < MIN_GAP_MS) {
                try { Thread.sleep(MIN_GAP_MS - (now - last)) } catch (_: InterruptedException) {}
                now = System.currentTimeMillis()
            }
            callTimes.add(now)
            now
        }
    }

    /** 서버가 429로 거절한 시도는 '내가 부른 횟수'에서 빼 줌 (안 그러면 재시도만으로 내 한도가 차 버림) */
    private fun forget(ts: Long) {
        if (ts == 0L) return
        synchronized(gate) { callTimes.remove(ts) }
    }

    /** 한 번에 한 요청만 서버로 나가게 줄 세움 (테스트 연타/동시 답장이 겹쳐 429 나는 것 방지) */
    private val one = Semaphore(1)
    private fun <T> serial(f: () -> T): T {
        one.acquireUninterruptibly()
        try { return f() } finally { one.release() }
    }

    @Volatile private var idx = 0
    private val JSON_T by lazy { "application/json; charset=utf-8".toMediaType() }

    /** IPv4 먼저 + 현재 네트워크의 DNS 사용 */
    private val dns = object : Dns {
        override fun lookup(hostname: String): List<InetAddress> {
            val all: List<InetAddress> = try {
                val cm = NetCtx.ctx?.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                val net = cm?.activeNetwork
                if (net != null) net.getAllByName(hostname).toList() else Dns.SYSTEM.lookup(hostname)
            } catch (e: Exception) {
                Dns.SYSTEM.lookup(hostname)
            }
            return all.sortedBy { if (it is Inet4Address) 0 else 1 }
        }
    }

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .protocols(listOf(Protocol.HTTP_1_1))
            .connectionPool(okhttp3.ConnectionPool(0, 1, TimeUnit.SECONDS))
            .dns(dns)
            .retryOnConnectionFailure(true)
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    private fun <T> withRetry(tag: String, k: Int, f: () -> T): T {
        var lastErr: Exception? = null
        for (a in 1..4) {
            var ts = 0L
            try { ts = throttle(); return f() } catch (e: RateLimitEx) {
                forget(ts)
                lastErr = e
                if (a == 4) { blockedUntil = System.currentTimeMillis() + 20000L; throw e }
                val w = maxOf(e.waitMs, 4000L * a).coerceAtMost(20000L)
                Bridge.log("$tag 요청 한도(429) 서버 메시지: ${(e.message ?: "").take(100)}")
                Bridge.log("$tag ${w / 1000}초 뒤 다시 시도 ($a/3)")
                try { Thread.sleep(w) } catch (_: InterruptedException) {}
            } catch (e: Exception) {
                lastErr = e
                if (e !is IOException || a >= 3) throw e
                Bridge.log("$tag 키 ${k + 1} 연결 오류, 다시 시도 ($a/2): ${(e.message ?: e.toString()).take(60)}")
                try { Thread.sleep(700L * a) } catch (_: InterruptedException) {}
            }
        }
        throw lastErr ?: Exception("알 수 없는 오류")
    }

    private fun apiMsg(txt: String): String = try {
        val j = JSONObject(txt)
        val e = j.opt("error")
        if (e is JSONObject) e.optString("message", txt.take(120)) else (e?.toString() ?: txt.take(120))
    } catch (e: Exception) { txt.take(120) }

    private fun post(key: String, body: String): Response {
        // HTML 예시와 동일: Content-Type(application/json) + Authorization 만 보냄
        val req = Request.Builder().url(URL)
            .header("Authorization", "Bearer $key")
            .post(body.toRequestBody(JSON_T)).build()
        return client.newCall(req).execute()
    }

    private fun body(model: String, messages: JSONArray): String =
        JSONObject().put("model", model).put("messages", messages).put("stream", true).toString()

    /** 스트림을 읽어서 글자가 올 때마다 onDelta. 전체 글과 길이제한 여부를 돌려줌 */
    private fun streamCall(key: String, model: String, messages: JSONArray, onDelta: (String) -> Unit): Res {
        val sb = StringBuilder()
        var truncated = false
        post(key, body(model, messages)).use { res ->
            if (!res.isSuccessful) {
                val m = apiMsg(res.body?.string() ?: "")
                if (res.code == 429) {
                    val ra = (res.header("Retry-After")?.trim()?.toLongOrNull() ?: 0L) * 1000L
                    throw RateLimitEx(ra, "HTTP 429 $m")
                }
                throw Exception("HTTP ${res.code} $m")
            }
            val ct = res.header("Content-Type") ?: ""
            val src = res.body?.source() ?: throw Exception("빈 응답")
            if (!ct.contains("text/event-stream")) {
                // 스트림이 아니라 일반 JSON 으로 왔을 때도 읽어줌
                val j = JSONObject(src.readUtf8())
                if (j.has("error")) throw Exception(apiMsg(j.toString()))
                val c = j.optJSONArray("choices")?.optJSONObject(0)
                val t = c?.optJSONObject("message")?.optString("content", "") ?: ""
                if (t.isNotEmpty()) { sb.append(t); onDelta(t) }
                truncated = c?.optString("finish_reason") == "length"
                return@use
            }
            var done = false
            while (!done) {
                val line = src.readUtf8Line() ?: break
                if (!line.startsWith("data:")) continue
                val data = line.substring(5).trim()
                if (data.isEmpty()) continue
                if (data == "[DONE]") { done = true; continue }
                val item = try { JSONObject(data) } catch (e: Exception) { throw Exception("스트리밍 응답 형식 오류") }
                if (item.has("error")) throw Exception(apiMsg(item.toString()))
                val c = item.optJSONArray("choices")?.optJSONObject(0) ?: continue
                val t = c.optJSONObject("delta")?.optString("content", "") ?: ""
                if (t.isNotEmpty() && t != "null") { sb.append(t); onDelta(t) }
                if (c.optString("finish_reason") == "length") truncated = true
            }
            if (!done && sb.isEmpty()) throw Exception("답변 도중 연결이 끊겼어요")
        }
        return Res(sb.toString().trim(), truncated)
    }

    /** 키를 차례로 시도하고, 실패하면 다음 키로 넘어감 */
    fun ask(keys: List<String>, model: String, hist: List<Entry>, o: Opts): String {
        if (keys.isEmpty()) throw Exception("API 키가 없어요")
        val merged = ArrayList<Pair<String, String>>()
        for (e in hist.takeLast(o.context)) {
            val r = if (e.role == "user") "user" else "assistant"
            if (merged.isNotEmpty() && merged.last().first == r) {
                merged[merged.size - 1] = r to (merged.last().second + "\n" + e.text)
            } else merged.add(r to e.text)
        }
        while (merged.isNotEmpty() && merged[0].first != "user") merged.removeAt(0)
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", o.system))
        merged.forEach { (r, t) -> msgs.put(JSONObject().put("role", r).put("content", t)) }
        return serial { execute(keys, model, msgs, "", null) }
    }

    /** 글자가 만들어지는 대로 onDelta 로 넘겨주는 요청. 키를 바꿔 다시 시도할 때 onReset 호출 */
    fun stream(
        keys: List<String>, model: String, system: String, user: String,
        temp: Double, maxTokens: Int, onReset: () -> Unit, onDelta: (String) -> Unit
    ): String {
        if (keys.isEmpty()) throw Exception("API 키가 없어요")
        val msgs = JSONArray()
            .put(JSONObject().put("role", "system").put("content", system))
            .put(JSONObject().put("role", "user").put("content", user))
        return serial { execute(keys, model, msgs, "요약", Pair(onReset, onDelta)) }
    }

    private fun execute(
        keys: List<String>, model: String, msgs: JSONArray, tag: String,
        cb: Pair<() -> Unit, (String) -> Unit>?
    ): String {
        var last = ""
        val deadline = System.currentTimeMillis() + 60000L
        for (i in keys.indices) {
            if (i > 0 && System.currentTimeMillis() > deadline) { last = "시간 초과 · $last"; break }
            val k = (idx + i) % keys.size
            try {
                val r = withRetry(tag, k) {
                    cb?.first?.invoke()
                    streamCall(keys[k], model, msgs) { d -> cb?.second?.invoke(d) }
                }
                if (r.text.isBlank()) throw Exception("AI에서 빈 답변을 받았어요")
                idx = k
                return if (r.truncated) trimToSentence(r.text) else r.text
            } catch (e: Exception) {
                last = e.message ?: e.toString()
                Bridge.log("$tag 키 ${k + 1} 실패: ${last.take(100)}")
            }
        }
        throw Exception("모든 키 실패: $last")
    }

    private fun trimToSentence(t: String): String {
        val m = Regex("[.!?。]|[다요죠까네](?=\\s|$)").findAll(t).lastOrNull() ?: return t
        val end = m.range.last + 1
        return if (end >= t.length / 3) t.substring(0, end).trim() else t
    }

    /** 이모지 제거(선택) + 공백 정리 */
    fun clean(t: String, noEmoji: Boolean): String {
        var r = t
        if (noEmoji) r = r.replace(Regex("[\\p{So}\\uFE0F\\u200D]"), "")
        return r.replace(Regex("[ \\t]+\\n"), "\n").trim()
    }
}
