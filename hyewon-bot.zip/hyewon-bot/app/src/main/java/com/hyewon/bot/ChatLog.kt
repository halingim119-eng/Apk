package com.hyewon.bot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** /cmds 패널 안에서 AI와 나눈 대화. 최대 200개 메시지까지 저장 (넘치면 오래된 것부터 삭제) */
object ChatLog {
    const val MAX = 200

    private fun file(c: Context): File {
        val base = c.getExternalFilesDir(null) ?: c.filesDir
        val d = File(base, "hyewon")
        d.mkdirs()
        return File(d, "panel_chat.json")
    }

    @Synchronized
    fun load(c: Context): MutableList<Entry> {
        val f = file(c)
        if (!f.exists()) return mutableListOf()
        return try {
            val a = JSONArray(f.readText())
            MutableList(a.length()) {
                val o = a.getJSONObject(it)
                Entry(o.getString("role"), o.getString("text"), o.optString("time", ""))
            }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    @Synchronized
    fun add(c: Context, role: String, text: String) {
        val list = load(c)
        list.add(Entry(role, text, SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.KOREA).format(Date())))
        val keep = if (list.size > MAX) list.drop(list.size - MAX) else list
        val arr = JSONArray()
        keep.forEach { arr.put(JSONObject().put("role", it.role).put("text", it.text).put("time", it.time)) }
        try { file(c).writeText(arr.toString(1)) } catch (e: Exception) { }
    }

    @Synchronized
    fun clear(c: Context) {
        try { file(c).delete() } catch (e: Exception) { }
    }

    /** 카톡 답장 등 다른 AI 호출에 붙여 보낼 '나와 AI가 앱에서 나눈 최근 대화' (없으면 빈 글자) */
    fun memoryBlock(c: Context, n: Int = 16): String {
        val l = load(c).takeLast(n)
        if (l.isEmpty()) return ""
        val who = Cfg.userName(c)
        val sb = StringBuilder("\n\n[참고: ${who}(너의 주인)와 앱에서 직접 나눈 최근 대화. 배경 기억으로만 쓰고, 카톡 상대에게 이 대화를 그대로 말하거나 언급하지 마]\n")
        for (e in l) sb.append(if (e.role == "user") who else "나").append(": ").append(e.text.take(300)).append('\n')
        return sb.toString().trimEnd()
    }
}
