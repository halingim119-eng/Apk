package com.hyewon.bot

import org.json.JSONArray
import org.json.JSONObject
import android.content.Context
import android.net.ConnectivityManager
import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.TimeUnit

data class Opts(val system: String, val temperature: Double, val maxTokens: Int, val context: Int)

object Gemini {
    private class Res(val text: String, val truncated: Boolean, val reason: String)

    @Volatile private var idx = 0
    @Volatile var appCtx: Context? = null

    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
    private val JSON_T = "application/json; charset=utf-8".toMediaType()

    /** IPv4 먼저 시도 + 현재 연결된 네트워크의 DNS 사용 (IPv6/DNS 문제로 연결이 끊기는 것 방지) */
    private val dns = object : Dns {
        override fun lookup(hostname: String): List<InetAddress> {
            val all: List<InetAddress> = try {
                val cm = appCtx?.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                val net = cm?.activeNetwork
                if (net != null) net.getAllByName(hostname).toList() else Dns.SYSTEM.lookup(hostname)
            } catch (e: Exception) {
                Dns.SYSTEM.lookup(hostname)
            }
            return all.sortedBy { if (it is Inet4Address) 0 else 1 }
        }
    }

    // HTTP/1.1 고정 + 연결 재사용 안 함(오래된 연결이 끊겨 'connection abort' 나는 것 방지)
    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .protocols(listOf(Protocol.HTTP_1_1))
            .connectionPool(okhttp3.ConnectionPool(0, 1, TimeUnit.SECONDS))
            .dns(dns)
            .retryOnConnectionFailure(true)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    private fun isNetErr(e: Exception) = e is IOException

    /** 네트워크 오류면 잠깐 쉬었다가 같은 키로 최대 4번 다시 시도 */
    private fun <T> withRetry(tag: String, k: Int, f: () -> T): T {
        var lastErr: Exception? = null
        for (a in 1..4) {
            try { return f() } catch (e: Exception) {
                lastErr = e
                if (!isNetErr(e) || a == 4) throw e
                Bridge.log("$tag 키 ${k + 1} 연결 오류, 다시 시도 ($a/3): ${(e.message ?: e.toString()).take(60)}")
                try { Thread.sleep(700L * a) } catch (_: InterruptedException) {}
            }
        }
        throw lastErr ?: Exception("알 수 없는 오류")
    }

    private fun post(url: String, key: String, body: String, readSec: Long): Response {
        val req = Request.Builder().url(url)
            .header("x-goog-api-key", key)
            .header("Connection", "close")
            .post(body.toRequestBody(JSON_T)).build()
        val c = client.newBuilder().readTimeout(readSec, TimeUnit.SECONDS).build()
        return c.newCall(req).execute()
    }

    /** 키를 차례로 시도하고, 실패하면 다음 키로 넘어감 */
    fun ask(keys: List<String>, model: String, hist: List<Entry>, o: Opts): String {
        if (keys.isEmpty()) throw Exception("API 키가 없어요 (앱에서 입력)")
        var last = ""
        for (i in keys.indices) {
            val k = (idx + i) % keys.size
            try {
                var r = withRetry("", k) { call(keys[k], model, buildBody(hist, o, o.maxTokens)) }
                if (r.truncated) { // 길이 제한에 걸려 중간에 끊겼으면 한도를 늘려서 다시 요청
                    Bridge.log("답이 길이 제한에 걸려 한도를 늘려 다시 요청해요")
                    r = withRetry("", k) { call(keys[k], model, buildBody(hist, o, minOf(o.maxTokens * 3, 8192))) }
                }
                var t = r.text
                if (t.isBlank()) throw Exception("빈 응답 (${r.reason})")
                if (r.truncated) t = trimToSentence(t)
                idx = k
                return t
            } catch (e: Exception) {
                last = e.message ?: e.toString()
                Bridge.log("키 ${k + 1} 실패: ${last.take(100)}")
            }
        }
        throw Exception("모든 키 실패: $last")
    }

    /** 글자가 만들어지는 대로 onDelta 로 넘겨주는 스트리밍 요청. 키를 바꿔 다시 시도할 때 onReset 호출 */
    fun stream(
        keys: List<String>, model: String, system: String, user: String,
        temp: Double, maxTokens: Int, onReset: () -> Unit, onDelta: (String) -> Unit
    ): String {
        if (keys.isEmpty()) throw Exception("API 키가 없어요 (앱에서 입력)")
        var last = ""
        for (i in keys.indices) {
            val k = (idx + i) % keys.size
            try {
                onReset()
                val sb = StringBuilder()
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", user)))))
                    .put("generationConfig", JSONObject().put("temperature", temp).put("maxOutputTokens", maxTokens))
                    .toString()
                withRetry("요약", k) {
                    sb.setLength(0)
                    onReset()
                    post("$BASE$model:streamGenerateContent?alt=sse", keys[k], body, 60).use { res ->
                        if (!res.isSuccessful) {
                            val err = res.body?.string() ?: ""
                            throw Exception("HTTP ${res.code} ${apiMsg(err)}")
                        }
                        val src = res.body!!.source()
                        while (true) {
                            val line = src.readUtf8Line() ?: break
                            if (!line.startsWith("data:")) continue
                            val js = line.substring(5).trim()
                            if (js.isEmpty() || js == "[DONE]") continue
                            val parts = JSONObject(js).optJSONArray("candidates")?.optJSONObject(0)
                                ?.optJSONObject("content")?.optJSONArray("parts") ?: continue
                            for (pi in 0 until parts.length()) {
                                val po = parts.getJSONObject(pi)
                                if (po.optBoolean("thought", false)) continue
                                val t = po.optString("text", "")
                                if (t.isNotEmpty()) { sb.append(t); onDelta(t) }
                            }
                        }
                    }
                }
                if (sb.isBlank()) throw Exception("빈 응답")
                idx = k
                return sb.toString().trim()
            } catch (e: Exception) {
                last = e.message ?: e.toString()
                Bridge.log("요약 키 ${k + 1} 실패: ${last.take(100)}")
            }
        }
        throw Exception("모든 키 실패: $last")
    }

    private fun buildBody(hist: List<Entry>, o: Opts, tokens: Int): String {
        val merged = ArrayList<Pair<String, String>>()
        for (e in hist.takeLast(o.context)) {
            val r = if (e.role == "user") "user" else "model"
            if (merged.isNotEmpty() && merged.last().first == r) {
                merged[merged.size - 1] = r to (merged.last().second + "\n" + e.text)
            } else merged.add(r to e.text)
        }
        while (merged.isNotEmpty() && merged[0].first != "user") merged.removeAt(0)

        val contents = JSONArray()
        merged.forEach { (r, t) ->
            contents.put(JSONObject().put("role", r)
                .put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        return JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", o.system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", o.temperature).put("maxOutputTokens", tokens))
            .toString()
    }

    private fun apiMsg(txt: String): String = try {
        JSONObject(txt).getJSONObject("error").optString("message", txt.take(120))
    } catch (e: Exception) { txt.take(120) }

    private fun call(key: String, model: String, body: String): Res {
        val txt = post("$BASE$model:generateContent", key, body, 90).use { res ->
            val t = res.body?.string() ?: ""
            if (t.isBlank()) throw Exception("HTTP ${res.code}")
            t
        }
        val j = JSONObject(txt)
        if (j.has("error")) throw Exception(j.getJSONObject("error").optString("message", "error"))
        val cand = j.getJSONArray("candidates").getJSONObject(0)
        val reason = cand.optString("finishReason", "")
        val content = cand.optJSONObject("content") ?: throw Exception("응답 없음 ($reason)")
        val parts = content.optJSONArray("parts") ?: throw Exception("응답 없음 ($reason)")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val po = parts.getJSONObject(i)
            if (!po.optBoolean("thought", false)) sb.append(po.optString("text", ""))
        }
        return Res(sb.toString().trim(), reason == "MAX_TOKENS", reason)
    }

    /** 그래도 끊겼을 때 마지막 완성된 문장까지만 사용 */
    private fun trimToSentence(t: String): String {
        val m = Regex("[.!?。]|[다요죠까네](?=\\s|$)").findAll(t).lastOrNull() ?: return t
        val end = m.range.last + 1
        return if (end >= t.length / 3) t.substring(0, end).trim() else t
    }

    /** 이모지 제거(선택) + 공백 정리 */
    fun clean(t: String, noEmoji: Boolean): String {
        var r = t
        if (noEmoji) r = r.replace(Regex("[\\p{So}\\uFE0F\\u200D]"), "")
        return r.replace(Regex("[ \\t]+\\n"), "\n").trim()
    }
}
