package com.hyewon.bot

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Gemini {
    private const val SYSTEM_PROMPT =
        "너는 카카오톡으로 대화하는 차분하고 똑똑한 친구야.\n" +
        "- 상대 말의 맥락과 이전 대화를 꼼꼼히 읽고, 질문이면 정확하고 구체적으로 답해.\n" +
        "- 말투는 담백하고 자연스럽게. 과장, 호들갑, 감탄사 남발, 지나친 공감 표현은 하지 마.\n" +
        "- 보통 1~2문장으로 짧게. 길게 설명해달라고 할 때만 길게.\n" +
        "- 이모지와 이모티콘은 쓰지 마. ㅋㅋ, ㅎㅎ도 상대가 쓸 때만 가끔.\n" +
        "- 모르는 건 아는 척하지 말고 모른다고 해.\n" +
        "- 'ㅋㅋ', 'ㅇㅇ', '응', '그래' 같은 단순 맞장구나 대화가 끝난 말에는 답할 필요가 없어.\n" +
        "  이럴 때는 다른 말 없이 정확히 [SKIP] 만 출력해."

    private const val TEMPERATURE = 0.4
    private const val CONTEXT_TURNS = 20

    @Volatile private var idx = 0

    /** 키를 차례로 시도하고, 실패하면 다음 키로 넘어감 */
    fun ask(keys: List<String>, model: String, hist: List<Entry>): String {
        if (keys.isEmpty()) throw Exception("API 키가 없어요 (앱에서 입력)")
        val body = buildBody(hist)
        var last = ""
        for (i in keys.indices) {
            val k = (idx + i) % keys.size
            try {
                val t = call(keys[k], model, body)
                idx = k
                return t
            } catch (e: Exception) {
                last = e.message ?: e.toString()
                Bridge.log("키 ${k + 1} 실패: ${last.take(80)}")
            }
        }
        throw Exception("모든 키 실패: $last")
    }

    private fun buildBody(hist: List<Entry>): String {
        val merged = ArrayList<Pair<String, String>>()
        for (e in hist.takeLast(CONTEXT_TURNS)) {
            val r = if (e.role == "user") "user" else "model"
            if (merged.isNotEmpty() && merged.last().first == r) {
                merged[merged.size - 1] = r to (merged.last().second + "\n" + e.text)
            } else merged.add(r to e.text)
        }
        while (merged.isNotEmpty() && merged[0].first != "user") merged.removeAt(0)

        val contents = JSONArray()
        merged.forEach { (r, t) ->
            contents.put(JSONObject().put("role", r)
                .put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        return JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", TEMPERATURE).put("maxOutputTokens", 600))
            .toString()
    }

    private fun call(key: String, model: String, body: String): String {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = (if (code in 200..299) c.inputStream else c.errorStream) ?: throw Exception("HTTP $code")
        val txt = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        val j = JSONObject(txt)
        if (j.has("error")) throw Exception(j.getJSONObject("error").optString("message", "error"))
        val parts = j.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        return sb.toString().trim()
    }

    /** 이모지 제거 */
    fun clean(t: String): String =
        t.replace(Regex("[\\p{So}\\uFE0F\\u200D]"), "").replace(Regex("[ \\t]+\\n"), "\n").trim()
}
