package com.hyewon.bot

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Opts(val system: String, val temperature: Double, val maxTokens: Int, val context: Int)

object Gemini {
    private class Res(val text: String, val truncated: Boolean, val reason: String)

    @Volatile private var idx = 0

    /** 키를 차례로 시도하고, 실패하면 다음 키로 넘어감 */
    fun ask(keys: List<String>, model: String, hist: List<Entry>, o: Opts): String {
        if (keys.isEmpty()) throw Exception("API 키가 없어요 (앱에서 입력)")
        var last = ""
        for (i in keys.indices) {
            val k = (idx + i) % keys.size
            try {
                var r = call(keys[k], model, buildBody(hist, o, o.maxTokens))
                if (r.truncated) { // 길이 제한에 걸려 중간에 끊겼으면 한도를 늘려서 다시 요청
                    Bridge.log("답이 길이 제한에 걸려 한도를 늘려 다시 요청해요")
                    r = call(keys[k], model, buildBody(hist, o, minOf(o.maxTokens * 3, 8192)))
                }
                var t = r.text
                if (t.isBlank()) throw Exception("빈 응답 (${r.reason})")
                if (r.truncated) t = trimToSentence(t)
                idx = k
                return t
            } catch (e: Exception) {
                last = e.message ?: e.toString()
                Bridge.log("키 ${k + 1} 실패: ${last.take(100)}")
            }
        }
        throw Exception("모든 키 실패: $last")
    }

    private fun buildBody(hist: List<Entry>, o: Opts, tokens: Int): String {
        val merged = ArrayList<Pair<String, String>>()
        for (e in hist.takeLast(o.context)) {
            val r = if (e.role == "user") "user" else "model"
            if (merged.isNotEmpty() && merged.last().first == r) {
                merged[merged.size - 1] = r to (merged.last().second + "\n" + e.text)
            } else merged.add(r to e.text)
        }
        while (merged.isNotEmpty() && merged[0].first != "user") merged.removeAt(0)

        val contents = JSONArray()
        merged.forEach { (r, t) ->
            contents.put(JSONObject().put("role", r)
                .put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        return JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", o.system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", o.temperature).put("maxOutputTokens", tokens))
            .toString()
    }

    private fun call(key: String, model: String, body: String): Res {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 90000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = (if (code in 200..299) c.inputStream else c.errorStream) ?: throw Exception("HTTP $code")
        val txt = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        val j = JSONObject(txt)
        if (j.has("error")) throw Exception(j.getJSONObject("error").optString("message", "error"))
        val cand = j.getJSONArray("candidates").getJSONObject(0)
        val reason = cand.optString("finishReason", "")
        val content = cand.optJSONObject("content") ?: throw Exception("응답 없음 ($reason)")
        val parts = content.optJSONArray("parts") ?: throw Exception("응답 없음 ($reason)")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val po = parts.getJSONObject(i)
            if (!po.optBoolean("thought", false)) sb.append(po.optString("text", ""))
        }
        return Res(sb.toString().trim(), reason == "MAX_TOKENS", reason)
    }

    /** 그래도 끊겼을 때 마지막 완성된 문장까지만 사용 */
    private fun trimToSentence(t: String): String {
        val m = Regex("[.!?。]|[다요죠까네](?=\\s|$)").findAll(t).lastOrNull() ?: return t
        val end = m.range.last + 1
        return if (end >= t.length / 3) t.substring(0, end).trim() else t
    }

    /** 이모지 제거(선택) + 공백 정리 */
    fun clean(t: String, noEmoji: Boolean): String {
        var r = t
        if (noEmoji) r = r.replace(Regex("[\\p{So}\\uFE0F\\u200D]"), "")
        return r.replace(Regex("[ \\t]+\\n"), "\n").trim()
    }
}
