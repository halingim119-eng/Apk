package com.hyewon.bot

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** ModCard 가 서비스에게 부탁하는 동작들 (누르면 패널이 닫히고 화면 위에 '■ 중지' 버튼이 뜸) */
class ModActions(
    val detect: () -> Unit,
    val deleteBad: () -> Unit,
    val scan: () -> Unit,
    val deleteRepeat: () -> Unit,
    val deleteGroups: (List<Mod.Group>) -> Unit,
    val search: (String) -> List<Mod.Group>
)

/**
 * /cmds 패널에 붙는 '욕 감지 · 메시지 삭제' 카드
 * - 욕 감지: 최대 2만 개 읽고 AI 에게 2번 나눠 물어봄 → 욕 쓴 사람 이름과 횟수
 * - 욕 지우기 / 반복 메세지 지우기 / 검색해서 전체 선택·골라서 삭제
 */
object ModCard {
    private val ui = Handler(Looper.getMainLooper())
    private const val MAX_ROWS = 300

    fun build(
        ctx: Context, base: Int, fg: Int, softCol: Int, lineCol: Int, hintCol: Int,
        act: ModActions, onFocus: () -> Unit
    ): LinearLayout {
        val app = ctx.applicationContext
        val dp = ctx.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun round(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
            setColor(color); cornerRadius = r * dp
            if (stroke != null) setStroke(px(1), stroke)
        }
        fun wrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        fun weight(left: Int) = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = left }
        fun label(t: String, size: Float = 12f, color: Int = hintCol) = TextView(ctx).apply {
            text = t; textSize = size; setTextColor(color)
        }
        fun pill(t: String, filled: Boolean, click: (TextView) -> Unit) = TextView(ctx).apply {
            text = t
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(px(8), px(10), px(8), px(10))
            isClickable = true
            if (filled) {
                setTextColor(base); setTypeface(null, Typeface.BOLD); background = round(fg, 12)
            } else {
                setTextColor(fg); background = round(Color.TRANSPARENT, 12, lineCol)
            }
            setOnClickListener { click(this) }
        }
        /** 두 번 눌러야 실행되는 위험한 버튼 (3초 안에 한 번 더) */
        fun armed(v: TextView, normal: String, ask: String, run: () -> Unit) {
            var on = false
            v.setOnClickListener {
                if (!on) {
                    on = true
                    v.text = ask
                    ui.postDelayed({ if (on) { on = false; v.text = normal } }, 3000)
                } else {
                    on = false
                    v.text = normal
                    run()
                }
            }
        }
        fun paintToggle(v: TextView, text: String, on: Boolean) {
            v.text = "$text ${if (on) "켜짐" else "꺼짐"}"
            v.setTextColor(if (on) base else fg)
            v.background = round(if (on) fg else Color.TRANSPARENT, 12, lineCol)
        }
        fun listBox(heightDp: Int, content: View): ScrollView = ScrollView(ctx).apply {
            background = round(softCol, 14, lineCol)
            setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
            addView(content)
        }

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(18), px(14), px(18), px(14))
            background = round(base, 22, lineCol)
        }
        card.addView(label("욕 감지 · 메시지 삭제", 16f, fg).apply { setTypeface(null, Typeface.BOLD) })
        card.addView(label("누르면 패널이 닫히고 화면 오른쪽 위에 '■ 중지' 버튼이 떠요. 그걸 누르면 언제든 멈춰요 (채팅방 안에서 눌러 주세요)")
            .apply { textSize = 11f }, wrap().apply { topMargin = px(2) })

        // ---- 스위치 ----
        val sw = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val admin = pill("", false) { v ->
            val on = !Cfg.p(app).getBoolean("modAdmin", false)
            Cfg.p(app).edit().putBoolean("modAdmin", on).apply()
            paintToggle(v, "방장/부방장", on)
        }
        paintToggle(admin, "방장/부방장", Cfg.p(app).getBoolean("modAdmin", false))
        val batch = pill("", false) { v ->
            val on = !Cfg.p(app).getBoolean("modBatch", true)
            Cfg.p(app).edit().putBoolean("modBatch", on).apply()
            paintToggle(v, "한꺼번에 선택", on)
        }
        paintToggle(batch, "한꺼번에 선택", Cfg.p(app).getBoolean("modBatch", true))
        sw.addView(admin, weight(0))
        sw.addView(batch, weight(px(8)))
        card.addView(sw, wrap().apply { topMargin = px(10) })
        card.addView(label("방장/부방장 꺼짐 = 내 메시지만 지워요 (남의 메시지는 건너뜀). 켜면 남의 메시지도 지워요. '한꺼번에 선택'은 화면에 보이는 것을 한 번에 골라 지워서 훨씬 빨라요")
            .apply { textSize = 11f }, wrap().apply { topMargin = px(4) })

        // ---- 메시지 읽는 방법 고르기 ----
        card.addView(label("메시지 읽는 방법", 14f, fg).apply { setTypeface(null, Typeface.BOLD) }, wrap().apply { topMargin = px(12) })
        val modeRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val modeScroll = pill("", false) { }
        val modeFile = pill("", false) { }
        val howto = label("", 11f)
        val nameEt = EditText(ctx).apply {
            hint = "내 카톡 이름 (파일에서 내 메시지를 구분)"
            setText(Cfg.p(app).getString("myName", "") ?: "")
            setTextColor(fg)
            setHintTextColor(hintCol)
            textSize = 14f
            isSingleLine = true
            background = round(softCol, 12, lineCol)
            setPadding(px(10), px(8), px(10), px(8))
            setOnFocusChangeListener { _, has -> if (has) onFocus() }
            setOnClickListener { onFocus() }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    Cfg.p(app).edit().putString("myName", s?.toString()?.trim() ?: "").apply()
                }
            })
        }
        fun paintMode() {
            val file = Cfg.p(app).getString("modReadMode", "scroll") == "file"
            fun style(v: TextView, text: String, on: Boolean) {
                v.text = text
                v.setTextColor(if (on) base else fg)
                v.background = round(if (on) fg else Color.TRANSPARENT, 12, lineCol)
            }
            style(modeScroll, "화면 스크롤로 읽기", !file)
            style(modeFile, "내보내기 파일로 읽기", file)
            howto.text = if (!file) "카톡 화면을 자동으로 위로 스크롤하며 읽어요 (오래 걸릴 수 있어요)"
            else Mod.FILE_HOWTO + (if (ModState.fromFile) "\n불러온 파일: 메시지 ${String.format("%,d", ModState.msgs.size)}개" else "\n아직 불러온 파일이 없어요")
            nameEt.visibility = if (file) View.VISIBLE else View.GONE
        }
        modeScroll.setOnClickListener { Cfg.p(app).edit().putString("modReadMode", "scroll").apply(); paintMode() }
        modeFile.setOnClickListener { Cfg.p(app).edit().putString("modReadMode", "file").apply(); paintMode() }
        modeRow.addView(modeScroll, weight(0))
        modeRow.addView(modeFile, weight(px(8)))
        card.addView(modeRow, wrap().apply { topMargin = px(6) })
        card.addView(howto, wrap().apply { topMargin = px(4) })
        card.addView(nameEt, wrap().apply { topMargin = px(6) })
        paintMode()

        // ---- 욕 감지 / 욕 지우기 ----
        val row1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(pill("욕 감지", true) { act.detect() }, weight(0))
        val delBad = pill("욕 지우기", false) { }
        armed(delBad, "욕 지우기", "정말? 한 번 더") { act.deleteBad() }
        row1.addView(delBad, weight(px(8)))
        card.addView(row1, wrap().apply { topMargin = px(10) })

        val report = label(
            if (ModState.lastReport.isEmpty()) "'욕 감지'를 누르면 최근 메시지를 최대 ${String.format("%,d", Mod.SCAN_LIMIT)}개까지 읽고, AI에게 2번 나눠 물어봐요"
            else ModState.lastReport, 12f, fg
        )
        card.addView(report, wrap().apply { topMargin = px(6) })
        if (ModState.stale) {
            card.addView(label("※ 지운 뒤라서 읽어 둔 내용이 지금과 다를 수 있어요. 다시 읽어 주세요"), wrap().apply { topMargin = px(2) })
        }

        // 욕 쓴 사람 이름 + 횟수
        val counts = ModState.counts()
        val namesCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(10), px(8), px(10), px(8)) }
        if (counts.isEmpty()) {
            namesCol.addView(label("욕 쓴 사람이 여기에 이름과 횟수로 나와요", 13f))
        } else {
            for ((who, n) in counts) {
                val line = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
                line.addView(label(who, 14f, fg), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                line.addView(label("${n}회", 14f, fg).apply { setTypeface(null, Typeface.BOLD) })
                namesCol.addView(line, wrap().apply { topMargin = px(2) })
            }
        }
        card.addView(listBox(120, namesCol), LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, px(if (counts.size <= 2) 70 else 120)).apply { topMargin = px(8) })

        // ---- 반복 메세지 지우기 ----
        card.addView(label("내가 반복 전송한 메시지", 14f, fg).apply { setTypeface(null, Typeface.BOLD) }, wrap().apply { topMargin = px(14) })
        val reps = RepMem.all(app)
        card.addView(label(
            if (reps.isEmpty()) "반복 전송을 하면 그 글자를 기억해 둬요. 지금은 기억된 게 없어요"
            else "기억된 글자 ${reps.size}개: " + reps.take(5).joinToString(" / ") { if (it.length > 14) it.take(14) + "…" else it }
        ), wrap().apply { topMargin = px(2) })
        val row2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val delRep = pill("반복 메세지 지우기", false) { }
        armed(delRep, "반복 메세지 지우기", "정말? 한 번 더") { act.deleteRepeat() }
        val clrRep = pill("기억 비우기", false) { v ->
            RepMem.clear(app)
            v.text = "비웠어요"
            ui.postDelayed({ v.text = "기억 비우기" }, 1500)
        }
        row2.addView(delRep, weight(0))
        row2.addView(clrRep, weight(px(8)))
        card.addView(row2, wrap().apply { topMargin = px(6) })

        // ---- 검색해서 지우기 ----
        card.addView(label("검색해서 지우기", 14f, fg).apply { setTypeface(null, Typeface.BOLD) }, wrap().apply { topMargin = px(14) })
        val have = ModState.msgs.size
        card.addView(label(
            if (have == 0) "먼저 '메시지 읽기'를 눌러 대화를 읽어 두세요 (최대 ${String.format("%,d", Mod.SCAN_LIMIT)}개)"
            else "읽어 둔 메시지 ${String.format("%,d", have)}개에서 찾아요. 같은 사람이 보낸 같은 글자는 한 줄로 묶여요"
        ), wrap().apply { topMargin = px(2) })

        val q = EditText(ctx).apply {
            hint = "찾을 글자"
            setText(ModState.query)
            setTextColor(fg)
            setHintTextColor(hintCol)
            textSize = 15f
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
            background = round(softCol, 12, lineCol)
            setPadding(px(10), px(8), px(10), px(8))
            setOnFocusChangeListener { _, has -> if (has) onFocus() }
            setOnClickListener { onFocus() }
        }
        val readBtn = pill("메시지 읽기", false) { act.scan() }
        val row3 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row3.addView(q, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row3.addView(readBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { leftMargin = px(8) })
        card.addView(row3, wrap().apply { topMargin = px(6) })

        var groups: List<Mod.Group> = emptyList()
        val selected = HashSet<String>()
        val rows = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(6), px(6), px(6), px(6)) }
        val info = label("", 12f)
        val delSel = pill("선택 삭제", false) { }
        val allBtn = pill("전체 선택", false) { }

        fun paintButtons() {
            val n = groups.count { it.key in selected }
            val all = groups.isNotEmpty() && n == groups.size
            allBtn.text = if (all) "전체 해제" else "전체 선택"
            delSel.text = "선택 삭제 ($n)"
            delSel.alpha = if (n > 0) 1f else 0.45f
        }

        fun render() {
            rows.removeAllViews()
            if (groups.isEmpty()) {
                rows.addView(label(if (q.text.isNullOrBlank()) "찾을 글자를 적으면 여기에 나와요" else "찾은 메시지가 없어요", 13f).apply { setPadding(px(6), px(4), px(6), px(4)) })
            }
            for (g in groups.take(MAX_ROWS)) {
                val on = g.key in selected
                val tv = TextView(ctx).apply {
                    val shown = if (g.text.length > 80) g.text.take(80) + "…" else g.text
                    text = (if (on) "☑ " else "☐ ") + g.who + " · " + shown + (if (g.count > 1) "  ×${g.count}" else "")
                    textSize = 13f
                    setTextColor(if (on) base else fg)
                    background = round(if (on) fg else Color.TRANSPARENT, 10)
                    setPadding(px(8), px(7), px(8), px(7))
                    isClickable = true
                    setOnClickListener {
                        if (g.key in selected) selected.remove(g.key) else selected.add(g.key)
                        val now = g.key in selected
                        text = (if (now) "☑ " else "☐ ") + text.substring(2)
                        setTextColor(if (now) base else fg)
                        background = round(if (now) fg else Color.TRANSPARENT, 10)
                        paintButtons()
                    }
                }
                rows.addView(tv, wrap().apply { topMargin = px(2) })
            }
            val total = groups.sumOf { it.count }
            info.text = if (groups.isEmpty()) "" else
                "${groups.size}종류 · 모두 ${String.format("%,d", total)}개" +
                    (if (groups.size > MAX_ROWS) " (위 ${MAX_ROWS}종류만 보여요. 전체 선택은 전부에 적용돼요)" else "")
            paintButtons()
        }

        q.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                ModState.query = s?.toString() ?: ""
                groups = act.search(ModState.query)
                selected.clear()
                render()
            }
        })

        card.addView(listBox(170, rows), LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, px(170)).apply { topMargin = px(8) })
        card.addView(info, wrap().apply { topMargin = px(4) })

        allBtn.setOnClickListener {
            val all = groups.isNotEmpty() && groups.all { it.key in selected }
            selected.clear()
            if (!all) for (g in groups) selected.add(g.key)
            render()
        }
        armed(delSel, "선택 삭제", "정말 지울까요? 한 번 더") {
            val picked = groups.filter { it.key in selected }
            if (picked.isNotEmpty()) act.deleteGroups(picked)
        }
        val row4 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        row4.addView(allBtn, weight(0))
        row4.addView(delSel, weight(px(8)))
        card.addView(row4, wrap().apply { topMargin = px(6) })

        // 패널을 다시 열었을 때 이전 검색어가 있으면 결과도 바로 보여줌
        if (ModState.query.isNotBlank()) { groups = act.search(ModState.query) }
        render()
        return card
    }
}
