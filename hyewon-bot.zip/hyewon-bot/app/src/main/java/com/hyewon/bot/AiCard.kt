package com.hyewon.bot

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

/** /cmds 패널에 붙는 'AI 자동답변' 카드: 반응으로 AI답변하기 / 모든 메세지 자동답변 */
object AiCard {
    fun build(ctx: Context, base: Int, fg: Int, softCol: Int, lineCol: Int, hintCol: Int): LinearLayout {
        val dp = ctx.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun round(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
            setColor(color); cornerRadius = r * dp
            if (stroke != null) setStroke(px(1), stroke)
        }
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(18), px(14), px(18), px(14))
            background = round(base, 22, lineCol)
        }
        card.addView(TextView(ctx).apply {
            text = "AI 자동답변"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(fg)
        })

        fun row(title: String, desc: String, get: () -> Boolean, set: (Boolean) -> Unit) {
            val line = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(ctx).apply { text = title; textSize = 15f; setTextColor(fg) })
            col.addView(TextView(ctx).apply { text = desc; textSize = 12f; setTextColor(hintCol) })
            line.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val tog = TextView(ctx).apply {
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(px(14), px(8), px(14), px(8))
                isClickable = true
            }
            fun paint() {
                val on = get()
                tog.text = if (on) "켜짐" else "꺼짐"
                tog.setTextColor(if (on) base else fg)
                tog.background = round(if (on) fg else Color.TRANSPARENT, 12, lineCol)
            }
            tog.setOnClickListener { set(!get()); paint() }
            paint()
            line.addView(tog)
            card.addView(line, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })
        }

        row("반응으로 AI답변하기", "내가 메시지에 반응/이모지를 달면 그 메시지에 AI가 답장",
            { Cfg.reactAi(ctx) }) { Cfg.p(ctx).edit().putBoolean("reactAi", it).apply(); Bridge.log("반응으로 AI답변: ${if (it) "켜짐" else "꺼짐"}") }
        row("모든 메세지 자동답변", "새 메시지가 생기면 실시간으로 감지해서 AI가 답장",
            { Cfg.everyone(ctx) }) { Cfg.p(ctx).edit().putBoolean("everyone", it).apply(); Bridge.log("모든 메세지 자동답변: ${if (it) "켜짐" else "꺼짐"}") }
        return card
    }
}
