package com.hyewon.bot

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

/**
 * 자리비움 자동응답.
 * 내가 고른 게임을 하는 중에 카톡 알림이 오면 AI어플 이름으로 답장하고,
 * 게임 화면 위에 작은 알림 + 답장 선택지를 띄움. 상대가 요약을 원하면 모아서 AI로 요약.
 */
object Away {
    private val h = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private class Room(val room: String) {
        var who = ""
        var game = ""
        var state = 0            // 0 = 알림 보냄, 1 = 요약할 말 모으는 중
        var lastNotice = 0L
        var lastSeen = 0L
        val msgs = ArrayList<String>()
        var task: Runnable? = null
    }

    private val rooms = HashMap<String, Room>()
    private val seen = ArrayList<String>()
    private val intentRe = Regex("요약|전달|남길|남겨|할\\s*말|말할게|말씀")
    private val endRe = Regex("^\\s*(끝|다\\s*했|이상|완료)")

    private const val NOTICE_COOLDOWN = 10 * 60 * 1000L
    private const val ROOM_IDLE = 30 * 60 * 1000L
    private const val COLLECT_WAIT = 8000L

    // ---------- 받침 확인 ----------
    private fun hasFinal(s: String): Boolean {
        val t = s.trimEnd { !it.isLetterOrDigit() }
        val ch = t.lastOrNull() ?: return false
        return when {
            ch in '가'..'힣' -> (ch - '가') % 28 != 0
            ch.isDigit() -> ch in "013678"
            ch.isLetter() -> ch.lowercaseChar() in "lmnr"
            else -> false
        }
    }

    private fun josa(word: String, withFinal: String, without: String) =
        if (hasFinal(word)) withFinal else without

    // ---------- 들어온 메시지 처리 ----------
    fun onMessage(ctx: Context, m: Replier.Msg, postTime: Long) {
        if (!Cfg.awayOn(ctx)) return
        if (m.text.isBlank() || m.text.startsWith("| ")) return
        val now = System.currentTimeMillis()
        if (now - postTime > 30000) return
        val key = m.room + "|" + m.text + "|" + postTime
        if (seen.contains(key)) return
        seen.add(key)
        while (seen.size > 30) seen.removeAt(0)
        if (m.isGroup && !Cfg.awayGroup(ctx)) return

        var r = rooms[m.room]
        if (r != null && now - r.lastSeen > ROOM_IDLE) {
            r.task?.let { h.removeCallbacks(it) }
            rooms.remove(m.room)
            r = null
        }
        // 요약할 말을 모으는 중이면 게임을 안 하고 있어도 계속 모음
        if (r != null && r.state == 1) {
            collect(ctx, r, m.text)
            return
        }

        val game = currentGame(ctx) ?: return
        if (r == null) {
            r = Room(m.room)
            rooms[m.room] = r
        }
        r.who = m.sender
        r.game = game
        r.lastSeen = now
        r.msgs.add(m.text)
        while (r.msgs.size > 30) r.msgs.removeAt(0)

        val first = r.lastNotice == 0L || now - r.lastNotice > NOTICE_COOLDOWN
        if (first) {
            r.lastNotice = now
            r.state = 0
            sendTo(ctx, r.room, noticeText(ctx, r))
            Bridge.log("자리비움 안내 전송: ${r.who} (${r.game})")
        } else if (intentRe.containsMatchIn(m.text)) {
            startCollect(ctx, r)
            return
        }
        showChoices(ctx, r, m.text)
    }

    private fun currentGame(ctx: Context): String? {
        val games = Cfg.awayGames(ctx)
        if (games.isEmpty()) return null
        if (!Foreground.hasAccess(ctx)) {
            Bridge.log("자리비움: '사용 정보 접근' 권한이 필요해요")
            return null
        }
        val top = Foreground.top(ctx) ?: return null
        if (!games.contains(top)) return null
        return Foreground.label(ctx, top)
    }

    private fun noticeText(ctx: Context, r: Room): String {
        val me = Cfg.userName(ctx)
        return "| AI어플. 지금 $me 님은 ${r.game}${josa(r.game, "을", "를")} 하는 중이에요.\n" +
            "$me 님에게 알려드릴 테니 기다려주세요.\n\n" +
            "하고 싶은 말이 있으시면 제가 ${r.who}님의 메세지를 요약해 ${me}한테 보낼 수 있어요."
    }

    private fun sendTo(ctx: Context, room: String, text: String): Boolean {
        val ok = Replier.send(ctx, listOf(room), text)
        if (!ok) Bridge.log("자리비움 전송 실패 (알림 답장 없음): $room")
        return ok
    }

    // ---------- 게임 화면 위 알림 + 선택지 ----------
    private fun options(ctx: Context, room: String): List<Pair<String, () -> Unit>> {
        val me = Cfg.userName(ctx)
        val r1 = Cfg.awayR1(ctx)
        val r2 = Cfg.awayR2(ctx)
        return listOf(
            "1. $r1" to { sendTo(ctx, room, "| $me 답장: $r1"); Unit },
            "2. $r2" to { sendTo(ctx, room, "| $me 답장: $r2"); Unit }
        )
    }

    private fun showChoices(ctx: Context, r: Room, latest: String) {
        val ui = BotService.inst?.awayUi
        if (ui == null) {
            Bridge.log("게임 화면 위 알림 못 띄움: 접근성 서비스가 꺼져 있어요")
            return
        }
        val title = if (r.state == 1) "📝 ${r.who}님 말씀 듣는 중" else "💬 ${r.who}님에게 메시지가 왔어요"
        ui.show(title, latest.replace("\n", " ").take(120), options(ctx, r.room), 30000L)
    }

    // ---------- 요약 ----------
    private fun startCollect(ctx: Context, r: Room) {
        r.state = 1
        val me = Cfg.userName(ctx)
        sendTo(
            ctx, r.room,
            "| AI어플. 네, 말씀하신 내용을 요약해서 $me 님께 전달할게요.\n" +
                "하고 싶은 말을 보내주세요. 다 보내셨으면 '끝'이라고 해주세요."
        )
        Bridge.log("요약 시작 (말 모으는 중): ${r.who}")
        showChoices(ctx, r, r.msgs.lastOrNull() ?: "")
        schedule(ctx, r)
    }

    private fun collect(ctx: Context, r: Room, text: String) {
        r.lastSeen = System.currentTimeMillis()
        if (endRe.containsMatchIn(text)) {
            summarize(ctx, r)
            return
        }
        r.msgs.add(text)
        while (r.msgs.size > 40) r.msgs.removeAt(0)
        showChoices(ctx, r, text)
        schedule(ctx, r)
    }

    private fun schedule(ctx: Context, r: Room) {
        r.task?.let { h.removeCallbacks(it) }
        val t = Runnable { summarize(ctx, r) }
        r.task = t
        h.postDelayed(t, COLLECT_WAIT)
    }

    private fun summarize(ctx: Context, r: Room) {
        r.task?.let { h.removeCallbacks(it) }
        r.task = null
        if (r.state != 1) return
        r.state = 0
        val texts = ArrayList(r.msgs)
        r.msgs.clear()
        val me = Cfg.userName(ctx)
        val who = r.who
        val ui = BotService.inst?.awayUi
        ui?.summaryStart(who)
        Bridge.log("요약 처리 시작: $who (메시지 ${texts.size}개)")

        val system = "너는 카카오톡 메시지 요약 도우미야. 아래는 어떤 사람이 ${me}님에게 남긴 메시지들이야. " +
            "누가 무엇을 원하는지, 꼭 알아야 할 내용만 한국어로 2~4줄로 간단히 요약해. " +
            "인사말과 군더더기는 빼고 요약문만 출력해."
        val user = "${who}님이 남긴 메시지:\n" + texts.joinToString("\n") { "- $it" }

        io.execute {
            try {
                val full = Gemini.stream(
                    Cfg.keys(ctx), Cfg.model(ctx), system, user, 0.3, 1024,
                    { ui?.summaryReset() }, { d -> ui?.summaryDelta(d) }
                )
                h.post {
                    ui?.summaryDone(who, full, options(ctx, r.room))
                    sendTo(ctx, r.room, "| AI어플. 요약해서 $me 님께 전달했어요. 조금만 기다려주세요.")
                    Bridge.log("요약 완료: ${full.replace("\n", " / ").take(200)}")
                }
            } catch (e: Exception) {
                h.post {
                    ui?.summaryFail(who, e.message ?: "알 수 없는 오류")
                    Bridge.log("요약 실패: ${e.message}")
                }
            }
        }
    }
}
