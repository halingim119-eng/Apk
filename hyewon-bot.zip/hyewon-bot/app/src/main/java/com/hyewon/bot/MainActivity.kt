package com.hyewon.bot

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private lateinit var logView: TextView
    private lateinit var enabled: Switch
    private lateinit var everyone: Switch
    private lateinit var names: EditText
    private lateinit var blocks: EditText
    private lateinit var model: EditText
    private lateinit var keys: EditText
    private lateinit var keyInfo: TextView
    private lateinit var prompt: EditText
    private lateinit var skipRule: Switch
    private lateinit var noEmoji: Switch
    private lateinit var autoSend: Switch
    private lateinit var temp: EditText
    private lateinit var maxTokens: EditText
    private lateinit var context: EditText
    private lateinit var waitSec: EditText

    private fun save(toast: Boolean) {
        Cfg.p(this).edit()
            .putBoolean("enabled", enabled.isChecked)
            .putBoolean("everyone", everyone.isChecked)
            .putString("names", names.text.toString())
            .putString("blocks", blocks.text.toString())
            .putString("model", model.text.toString().trim())
            .putString("keys", keys.text.toString())
            .putString("prompt", prompt.text.toString())
            .putBoolean("skipRule", skipRule.isChecked)
            .putBoolean("noEmoji", noEmoji.isChecked)
            .putBoolean("autoSend", autoSend.isChecked)
            .putString("temp", temp.text.toString().trim())
            .putString("maxTokens", maxTokens.text.toString().trim())
            .putString("context", context.text.toString().trim())
            .putString("waitSec", waitSec.text.toString().trim())
            .commit()
        val n = Cfg.keys(this).size
        keyInfo.text = "저장된 API 키: ${n}개"
        if (toast) Toast.makeText(this, "저장했어요 (API 키 ${n}개)", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(box) })

        fun header(t: String) = TextView(this).apply {
            text = t; textSize = 18f; setTypeface(null, Typeface.BOLD); setPadding(0, pad * 2, 0, 0)
        }
        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, pad, 0, 4) }
        fun field(v: String, lines: Int = 1) = EditText(this).apply {
            setText(v)
            if (lines > 1) {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                minLines = lines
            } else inputType = InputType.TYPE_CLASS_TEXT
        }
        fun sw(t: String, on: Boolean) = Switch(this).apply { text = t; isChecked = on; setPadding(0, pad / 2, 0, pad / 2) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        // ===== 기본 =====
        enabled = sw("봇 켜기", Cfg.enabled(this))
        box.addView(enabled)

        // ===== 누구에게 반응할지 =====
        box.addView(header("누구에게 반응할까요"))
        everyone = sw("모든 방, 모든 사람에게 반응", Cfg.everyone(this))
        box.addView(everyone)
        box.addView(label("반응할 사람/방 이름 (한 줄에 하나, 카톡에 보이는 이름 그대로). 위 스위치가 꺼져 있을 때만 사용"))
        names = field(Cfg.namesRaw(this), 3)
        box.addView(names)
        box.addView(label("제외할 사람/방 이름 (한 줄에 하나). 이 이름이 화면에 있으면 반응 안 함"))
        blocks = field(Cfg.blocksRaw(this), 2)
        box.addView(blocks)

        // ===== AI =====
        box.addView(header("AI 설정"))
        box.addView(label("Gemini 모델"))
        model = field(Cfg.model(this))
        box.addView(model)
        box.addView(label("Gemini API 키 (한 줄에 하나, 위에서부터 차례로 사용)"))
        keys = field(Cfg.keysRaw(this), 3)
        box.addView(keys)
        keyInfo = TextView(this).apply { text = "저장된 API 키: ${Cfg.keys(this@MainActivity).size}개" }
        box.addView(keyInfo)
        box.addView(label("AI 프롬프트 (말투/성격/규칙을 자유롭게 적으세요)"))
        prompt = field(Cfg.prompt(this), 8)
        box.addView(prompt)
        box.addView(btn("프롬프트를 기본값으로 되돌리기") { prompt.setText(Cfg.DEFAULT_PROMPT) })
        skipRule = sw("단순 맞장구(ㅋㅋ, ㅇㅇ 등)에는 답하지 않기", Cfg.skipRule(this))
        box.addView(skipRule)
        noEmoji = sw("답장에서 이모지 지우기", Cfg.noEmoji(this))
        box.addView(noEmoji)

        // ===== 세부 =====
        box.addView(header("세부 설정"))
        autoSend = sw("답장 자동 전송 (끄면 입력창에 적어두기만 함)", Cfg.autoSend(this))
        box.addView(autoSend)
        box.addView(label("상대가 말을 끝낼 때까지 기다리는 시간(초). 길수록 연속 메시지를 안 놓침"))
        waitSec = field(Cfg.waitRaw(this))
        box.addView(waitSec)
        box.addView(label("답장 최대 길이(토큰). 답이 중간에 끊기면 늘리세요"))
        maxTokens = field(Cfg.maxTokensRaw(this))
        box.addView(maxTokens)
        box.addView(label("창의성(온도) 0~2. 낮을수록 차분함"))
        temp = field(Cfg.tempRaw(this))
        box.addView(temp)
        box.addView(label("AI가 참고할 최근 대화 개수"))
        context = field(Cfg.contextRaw(this))
        box.addView(context)

        // ===== 버튼 =====
        box.addView(header("실행"))
        box.addView(btn("저장") { save(true) })
        box.addView(btn("AI 연결 테스트 (저장 후 눌러 보세요)") {
            save(false)
            val k = Cfg.keys(this)
            val m = Cfg.model(this)
            val o = Cfg.opts(this)
            Bridge.log("테스트 시작 (키 ${k.size}개, 모델 $m)")
            Thread {
                try {
                    val r = Gemini.ask(k, m, listOf(Entry("user", "안녕, 한 문장으로 인사해줘", "")), o)
                    Bridge.log("테스트 성공: ${r.take(100)}")
                } catch (e: Exception) {
                    Bridge.log("테스트 실패: ${e.message}")
                }
                runOnUiThread { logView.text = Bridge.text() }
            }.start()
        })
        box.addView(btn("접근성 설정 열기 (여기서 '혜원 봇' 켜기)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        box.addView(btn("화면 구조 덤프 요청 (카톡 채팅방을 연 상태에서)") {
            Bridge.dumpRequested = true
            Toast.makeText(this, "카톡 채팅방으로 가면 저장돼요", Toast.LENGTH_SHORT).show()
        })
        box.addView(btn("로그 새로고침") { logView.text = Bridge.text() })
        box.addView(btn("로그 지우기") { Bridge.clear(); logView.text = "" })

        box.addView(header("최근 로그 (아래쪽이 최신)"))
        logView = TextView(this).apply { setTextIsSelectable(true); setPadding(0, pad, 0, 0) }
        box.addView(logView)
    }

    override fun onPause() {
        super.onPause()
        save(false) // 화면을 나갈 때 자동 저장
    }

    override fun onResume() {
        super.onResume()
        logView.text = Bridge.text()
    }
}
