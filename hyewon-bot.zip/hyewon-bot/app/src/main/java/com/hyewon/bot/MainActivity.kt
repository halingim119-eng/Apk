package com.hyewon.bot

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private lateinit var logView: TextView
    private lateinit var enabled: Switch
    private lateinit var everyone: Switch
    private lateinit var names: EditText
    private lateinit var blocks: EditText
    private lateinit var groqModel: EditText
    private lateinit var groqKeys: EditText
    private lateinit var geminiModel: EditText
    private lateinit var geminiKeys: EditText
    private lateinit var fallback: Switch
    private lateinit var provGroup: RadioGroup
    private lateinit var keyInfo: TextView
    private lateinit var prompt: EditText
    private lateinit var skipRule: Switch
    private lateinit var noEmoji: Switch
    private lateinit var autoSend: Switch
    private lateinit var temp: EditText
    private lateinit var maxTokens: EditText
    private lateinit var context: EditText
    private lateinit var waitSec: EditText
    private lateinit var cmd: EditText
    private lateinit var themeEt: EditText
    private lateinit var themeDark: Switch
    private lateinit var viaScript: Switch
    private lateinit var autoColor: Switch
    private lateinit var notifyInfo: TextView
    private lateinit var userName: EditText
    private lateinit var awayR1: EditText
    private lateinit var awayR2: EditText
    private lateinit var awayInfo: TextView

    /** 카톡 알림으로 모인 이름 + 지금 화면의 이름을 불러와서 체크로 고르기 */
    private fun pickNames() {
        val screen = BotService.inst?.screenNames() ?: emptyList()
        Cfg.addKnown(this, *screen.toTypedArray())
        val cur = names.text.toString().split("\n", ",", ";").map { it.trim() }.filter { it.isNotEmpty() }
        val list = LinkedHashSet<String>()
        list.addAll(cur)           // 이미 적어 둔 이름은 맨 위에 (체크된 채로)
        list.addAll(screen)
        list.addAll(Cfg.known(this))
        if (list.isEmpty()) {
            Toast.makeText(this, "아직 불러올 이름이 없어요. 카톡 알림이 오거나 채팅방을 열어 둔 뒤 다시 눌러 주세요", Toast.LENGTH_LONG).show()
            return
        }
        val items = list.toTypedArray()
        val checked = BooleanArray(items.size) { cur.contains(items[it]) }
        android.app.AlertDialog.Builder(this)
            .setTitle("반응할 사람/방 고르기")
            .setMultiChoiceItems(items, checked) { _, i, on -> checked[i] = on }
            .setPositiveButton("적용") { _, _ ->
                val sel = items.filterIndexed { i, _ -> checked[i] }
                names.setText(sel.joinToString("\n"))
                save(false)
                Toast.makeText(this, "${sel.size}개 선택했어요", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun keyInfoText(): String {
        val g = Cfg.keysFor(this, Prov.GROQ).size
        val m = Cfg.keysFor(this, Prov.GEMINI).size
        return "지금 사용: ${Cfg.provider(this).label}  (저장된 키 - Groq ${g}개, Gemini ${m}개)"
    }

    private fun save(toast: Boolean) {
        Cfg.p(this).edit()
            .putBoolean("enabled", enabled.isChecked)
            .putBoolean("everyone", everyone.isChecked)
            .putString("names", names.text.toString())
            .putString("blocks", blocks.text.toString())
            .putString("provider", if (provGroup.checkedRadioButtonId == 2) "gemini" else "groq")
            .putBoolean("fallback", fallback.isChecked)
            .putString("model_groq", groqModel.text.toString().trim())
            .putString("keys_groq", groqKeys.text.toString())
            .putString("model_gemini", geminiModel.text.toString().trim())
            .putString("keys_gemini", geminiKeys.text.toString())
            .putString("prompt", prompt.text.toString())
            .putBoolean("skipRule", skipRule.isChecked)
            .putBoolean("noEmoji", noEmoji.isChecked)
            .putBoolean("autoSend", autoSend.isChecked)
            .putBoolean("viaScript", viaScript.isChecked)
            .putBoolean("autoColor", autoColor.isChecked)
            .putString("userName", userName.text.toString().trim())
            .putString("awayR1", awayR1.text.toString().trim())
            .putString("awayR2", awayR2.text.toString().trim())
            .putString("temp", temp.text.toString().trim())
            .putString("maxTokens", maxTokens.text.toString().trim())
            .putString("context", context.text.toString().trim())
            .putString("waitSec", waitSec.text.toString().trim())
            .putString("cmd", cmd.text.toString().trim())
            .putString("theme", themeEt.text.toString().trim())
            .putBoolean("themeDark", themeDark.isChecked)
            .commit()
        val n = Cfg.keys(this).size
        keyInfo.text = keyInfoText()
        if (toast) Toast.makeText(this, "저장했어요 (${Cfg.provider(this).label} 키 ${n}개)", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        NetCtx.ctx = applicationContext
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(box) })

        fun header(t: String) = TextView(this).apply {
            text = t; textSize = 18f; setTypeface(null, Typeface.BOLD); setPadding(0, pad * 2, 0, 0)
        }
        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, pad, 0, 4) }
        fun field(v: String, lines: Int = 1) = EditText(this).apply {
            setText(v)
            if (lines > 1) {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                minLines = lines
            } else inputType = InputType.TYPE_CLASS_TEXT
        }
        fun sw(t: String, on: Boolean) = Switch(this).apply { text = t; isChecked = on; setPadding(0, pad / 2, 0, pad / 2) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        // ===== 기본 =====
        enabled = sw("봇 켜기", Cfg.enabled(this))
        box.addView(enabled)

        // ===== 누구에게 반응할지 =====
        box.addView(header("누구에게 반응할까요"))
        everyone = sw("모든 방, 모든 사람에게 반응", Cfg.everyone(this))
        box.addView(everyone)
        box.addView(label("반응할 사람/방 이름 (한 줄에 하나, 카톡에 보이는 이름 그대로). 위 스위치가 꺼져 있을 때만 사용"))
        names = field(Cfg.namesRaw(this), 3)
        box.addView(names)
        box.addView(btn("목록에서 고르기 (자동으로 불러오기)") { pickNames() })
        box.addView(label("제외할 사람/방 이름 (한 줄에 하나). 이 이름이 화면에 있으면 반응 안 함"))
        blocks = field(Cfg.blocksRaw(this), 2)
        box.addView(blocks)

        // ===== AI =====
        box.addView(header("AI 설정"))
        box.addView(label("사용할 AI (누르면 바로 바뀌어요)"))
        provGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val rbGroq = RadioButton(this).apply { id = 1; text = "Groq" }
        val rbGemini = RadioButton(this).apply { id = 2; text = "Gemini" }
        provGroup.addView(rbGroq)
        provGroup.addView(rbGemini)
        provGroup.check(if (Cfg.provider(this) == Prov.GEMINI) 2 else 1)
        box.addView(provGroup)
        keyInfo = TextView(this).apply { text = keyInfoText() }
        provGroup.setOnCheckedChangeListener { _, _ ->
            Cfg.p(this).edit().putString("provider", if (provGroup.checkedRadioButtonId == 2) "gemini" else "groq").commit()
            keyInfo.text = keyInfoText()
            Bridge.log("AI 제공자: ${Cfg.provider(this).label}")
        }
        fallback = sw("지금 AI가 실패하면 다른 AI로 자동 전환 (그쪽 키가 있을 때)", Cfg.fallback(this))
        box.addView(fallback)

        box.addView(label("Groq API 키 (console.groq.com/keys, 한 줄에 하나)"))
        groqKeys = field(Cfg.keysRaw(this, Prov.GROQ), 2)
        box.addView(groqKeys)
        box.addView(label("Groq 모델 (기본: ${Prov.GROQ.defModel})"))
        groqModel = field(Cfg.modelRaw(this, Prov.GROQ))
        box.addView(groqModel)

        box.addView(label("Gemini API 키 (aistudio.google.com/apikey, 한 줄에 하나)"))
        geminiKeys = field(Cfg.keysRaw(this, Prov.GEMINI), 2)
        box.addView(geminiKeys)
        box.addView(label("Gemini 모델 (기본: ${Prov.GEMINI.defModel})"))
        geminiModel = field(Cfg.modelRaw(this, Prov.GEMINI))
        box.addView(geminiModel)
        box.addView(keyInfo)
        box.addView(label("AI 프롬프트 (말투/성격/규칙을 자유롭게 적으세요)"))
        prompt = field(Cfg.prompt(this), 8)
        box.addView(prompt)
        box.addView(btn("프롬프트를 기본값으로 되돌리기") { prompt.setText(Cfg.DEFAULT_PROMPT) })
        skipRule = sw("단순 맞장구(ㅋㅋ, ㅇㅇ 등)에는 답하지 않기", Cfg.skipRule(this))
        box.addView(skipRule)
        noEmoji = sw("답장에서 이모지 지우기", Cfg.noEmoji(this))
        box.addView(noEmoji)

        // ===== 세부 =====
        box.addView(header("세부 설정"))
        autoSend = sw("답장 자동 전송 (끄면 입력창에 적어두기만 함)", Cfg.autoSend(this))
        box.addView(autoSend)
        viaScript = sw("스크립트(알림 답장)로 전송 우선 - 안 되면 입력창 방식", Cfg.viaScript(this))
        box.addView(viaScript)
        notifyInfo = TextView(this)
        box.addView(notifyInfo)
        box.addView(btn("알림 접근 열기 (여기서 '혜원 봇 알림 답장' 켜기)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        box.addView(label("상대가 말을 끝낼 때까지 기다리는 시간(초). 길수록 연속 메시지를 안 놓침"))
        waitSec = field(Cfg.waitRaw(this))
        box.addView(waitSec)
        box.addView(label("답장 최대 길이(토큰). 답이 중간에 끊기면 늘리세요"))
        maxTokens = field(Cfg.maxTokensRaw(this))
        box.addView(maxTokens)
        box.addView(label("창의성(온도) 0~2. 낮을수록 차분함"))
        temp = field(Cfg.tempRaw(this))
        box.addView(temp)
        box.addView(label("AI가 참고할 최근 대화 개수"))
        context = field(Cfg.contextRaw(this))
        box.addView(context)

        // ===== 명령어 패널 =====
        box.addView(header("명령어 패널"))
        box.addView(label("채팅방에서 이걸 입력하면 내용을 적어서 보낼 수 있는 패널이 떠요"))
        cmd = field(Cfg.cmdWord(this))
        box.addView(cmd)
        autoColor = sw("패널 색을 카톡 입력창 색에서 자동 감지 (안드로이드 11 이상)", Cfg.autoColor(this))
        box.addView(autoColor)
        box.addView(label("자동 감지가 안 될 때 쓸 색 (예: #6C5CE7)"))
        themeEt = field(Cfg.themeRaw(this))
        box.addView(themeEt)
        val swatch = android.view.View(this).apply { setBackgroundColor(Cfg.themeColor(this@MainActivity)) }
        box.addView(swatch, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, pad * 2))
        themeEt.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                val t = (s?.toString() ?: "").trim()
                try { swatch.setBackgroundColor(android.graphics.Color.parseColor(if (t.startsWith("#")) t else "#$t")) } catch (e: Exception) { }
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        themeDark = sw("자동 감지가 안 될 때 어두운 패널", Cfg.themeDark(this))
        box.addView(themeDark)

        // ===== 자리비움 =====
        box.addView(header("자리비움 자동응답"))
        box.addView(label("/cmds 패널 아래의 '자리비움' 칸에서 게임을 고르고 켜면 돼요"))
        box.addView(label("내 이름 (AI어플 안내문과 답장에 들어가요)"))
        userName = field(Cfg.userName(this))
        box.addView(userName)
        box.addView(label("답장 선택지 1"))
        awayR1 = field(Cfg.awayR1Raw(this))
        box.addView(awayR1)
        box.addView(label("답장 선택지 2"))
        awayR2 = field(Cfg.awayR2Raw(this))
        box.addView(awayR2)
        awayInfo = TextView(this)
        box.addView(awayInfo)
        box.addView(btn("사용 정보 접근 열기 (지금 하는 게임을 알아내는 데 필요)") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })

        // ===== 버튼 =====
        box.addView(header("실행"))
        box.addView(btn("저장") { save(true) })
        box.addView(btn("AI 연결 테스트 (저장 후 눌러 보세요)") {
            save(false)
            val k = Cfg.keys(this)
            val m = Cfg.model(this)
            val o = Cfg.opts(this)
            Bridge.log("테스트 시작 (${Cfg.provider(this).label}, 키 ${k.size}개, 모델 $m)")
            Thread {
                try {
                    val r = Ai.ask(listOf(Entry("user", "안녕, 한 문장으로 인사해줘", "")), o)
                    Bridge.log("테스트 성공: ${r.take(100)}")
                } catch (e: Exception) {
                    Bridge.log("테스트 실패: ${e.message}")
                }
                runOnUiThread { logView.text = Bridge.text() }
            }.start()
        })
        box.addView(btn("접근성 설정 열기 (여기서 '혜원 봇' 켜기)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        box.addView(btn("화면 구조 덤프 요청 (카톡 채팅방을 연 상태에서)") {
            Bridge.dumpRequested = true
            Toast.makeText(this, "카톡 채팅방으로 가면 저장돼요", Toast.LENGTH_SHORT).show()
        })
        box.addView(btn("로그 새로고침") { logView.text = Bridge.text() })
        box.addView(btn("로그 지우기") { Bridge.clear(); logView.text = "" })

        box.addView(header("최근 로그 (아래쪽이 최신)"))
        logView = TextView(this).apply { setTextIsSelectable(true); setPadding(0, pad, 0, 0) }
        box.addView(logView)

        showUpdateNotice()
    }

    /** 코드가 새로 바뀐 빌드를 처음 열면 "업데이트 됐어요!" 화면을 보여줌 (빌드마다 신호값이 다름) */
    private fun showUpdateNotice() {
        val p = Cfg.p(this)
        if (p.getString("seenUpdate", "") == Cfg.UPDATE_SIGNAL) return
        val dp = resources.displayMetrics.density
        val pad = (28 * dp).toInt()
        val d = android.app.Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_Fullscreen)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        col.addView(TextView(this).apply {
            text = "업데이트 됐어요!"
            textSize = 30f
            setTypeface(null, Typeface.BOLD)
            gravity = android.view.Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = "신호값  ${Cfg.UPDATE_SIGNAL}"
            textSize = 18f
            gravity = android.view.Gravity.CENTER
            setPadding(0, pad / 2, 0, pad / 2)
        })
        col.addView(TextView(this).apply {
            text = Cfg.UPDATE_NOTES
            textSize = 15f
        })
        col.addView(Button(this).apply {
            text = "확인"
            setOnClickListener {
                p.edit().putString("seenUpdate", Cfg.UPDATE_SIGNAL).commit()
                d.dismiss()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = pad })
        d.setContentView(col)
        d.setCancelable(false)
        d.show()
    }

    private fun refreshNotifyInfo() {
        val n = Replier.count()
        notifyInfo.text = (if (Replier.connected) "알림 접근: 켜짐" else "알림 접근: 꺼짐 (아래 버튼으로 켜기)") +
            " / 알림 답장 준비된 방: ${n}개"
    }

    override fun onPause() {
        super.onPause()
        save(false) // 화면을 나갈 때 자동 저장
    }

    override fun onResume() {
        super.onResume()
        logView.text = Bridge.text()
        refreshNotifyInfo()
        awayInfo.text = "사용 정보 접근: " + (if (Foreground.hasAccess(this)) "켜짐" else "꺼짐 (아래 버튼으로 켜기)") +
            " / 선택한 게임: ${Cfg.awayGames(this).size}개 / 자동응답: " + (if (Cfg.awayOn(this)) "켜짐" else "꺼짐")
    }
}
