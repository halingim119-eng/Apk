package com.hyewon.bot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private lateinit var logView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val scroll = ScrollView(this).apply { addView(box) }
        setContentView(scroll)

        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, pad, 0, 4) }
        fun field(v: String, multi: Boolean = false) = EditText(this).apply {
            setText(v)
            if (multi) {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                minLines = 3
            } else inputType = InputType.TYPE_CLASS_TEXT
        }

        val enabled = Switch(this).apply { text = "봇 켜기"; isChecked = Cfg.enabled(this@MainActivity) }
        val target = field(Cfg.target(this))
        val model = field(Cfg.model(this))
        val keys = field(Cfg.keysRaw(this), true)

        box.addView(enabled)
        box.addView(label("반응할 사람 이름 (카톡에 보이는 이름 그대로)"))
        box.addView(target)
        box.addView(label("Gemini 모델"))
        box.addView(model)
        box.addView(label("Gemini API 키 (한 줄에 하나, 위에서부터 차례로 사용)"))
        box.addView(keys)

        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        box.addView(btn("저장") {
            Cfg.p(this).edit()
                .putBoolean("enabled", enabled.isChecked)
                .putString("target", target.text.toString().trim())
                .putString("model", model.text.toString().trim())
                .putString("keys", keys.text.toString())
                .apply()
            Toast.makeText(this, "저장했어요", Toast.LENGTH_SHORT).show()
        })
        box.addView(btn("접근성 설정 열기 (여기서 '혜원 봇' 켜기)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        box.addView(btn("화면 구조 덤프 요청 (카톡 채팅방을 연 상태에서)") {
            Bridge.dumpRequested = true
            Toast.makeText(this, "카톡 채팅방으로 가면 저장돼요", Toast.LENGTH_SHORT).show()
        })
        box.addView(btn("로그 새로고침") { logView.text = Bridge.text() })

        logView = TextView(this).apply { setTextIsSelectable(true); setPadding(0, pad, 0, 0) }
        box.addView(label("최근 로그"))
        box.addView(logView)
    }

    override fun onResume() {
        super.onResume()
        logView.text = Bridge.text()
    }
}
