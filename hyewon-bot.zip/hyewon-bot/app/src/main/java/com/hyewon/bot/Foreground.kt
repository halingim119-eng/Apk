package com.hyewon.bot

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Process

/** 지금 화면 맨 앞에 있는 앱이 뭔지 알아내기 (사용 정보 접근 권한 필요) */
object Foreground {

    @Suppress("DEPRECATION")
    fun hasAccess(c: Context): Boolean {
        return try {
            val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
            } else {
                ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    /** 최근 사용 기록에서 마지막으로 앞으로 나온 앱의 패키지 이름 */
    fun top(c: Context): String? {
        return try {
            val um = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis()
            val ev = um.queryEvents(end - 6L * 3600L * 1000L, end) ?: return null
            val e = UsageEvents.Event()
            var pkg: String? = null
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == 1) pkg = e.packageName                       // 앞으로 나옴
                else if (e.eventType == 2 && e.packageName == pkg) pkg = null   // 뒤로 감
            }
            pkg
        } catch (ex: Exception) {
            null
        }
    }

    fun label(c: Context, pkg: String): String {
        return try {
            val pm = c.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }
}
