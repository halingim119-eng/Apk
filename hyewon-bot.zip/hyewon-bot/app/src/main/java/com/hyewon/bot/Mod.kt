package com.hyewon.bot

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import android.view.View
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.concurrent.Executors

/** 화면에서 읽은 메시지 하나 (own = 내가 보낸 것, sender = 보낸 사람 이름) */
class Msg(var sender: String?, val text: String, val own: Boolean) {
    fun who(): String = if (own) "나" else (sender ?: "(이름 모름)")
}

fun normText(s: String): String = s.replace(Regex("\\s+"), " ").trim()

/** 패널을 닫았다 열어도 남아 있어야 하는 결과 */
object ModState {
    @Volatile var running = false
    @Volatile var msgs: List<Msg> = emptyList()      // 마지막으로 읽은 메시지 (오래된 것 → 최신)
    @Volatile var fromFile = false                   // 지금 읽어 둔 메시지가 '내보내기 파일'에서 온 것
    @Volatile var stale = false                       // 읽은 뒤에 삭제를 해서 내용이 달라졌을 수 있음
    @Volatile var bad: List<Msg> = emptyList()        // AI 가 욕이라고 한 메시지
    @Volatile var lastReport = ""
    @Volatile var query = ""

    fun counts(): List<Pair<String, Int>> =
        bad.groupingBy { it.who() }.eachCount().toList().sortedByDescending { it.second }
}

/** 반복 전송에 쓴 글자를 기억 (나중에 한꺼번에 지우기 위해) */
object RepMem {
    private const val K = "repMem"
    fun all(c: Context): List<String> =
        (Cfg.p(c).getString(K, "") ?: "").split("\u0001").filter { it.isNotEmpty() }

    fun add(c: Context, text: String) {
        val t = normText(text)
        if (t.isEmpty()) return
        val l = LinkedHashSet<String>()
        l.add(t)
        l.addAll(all(c))
        Cfg.p(c).edit().putString(K, l.take(30).joinToString("\u0001")).apply()
    }

    fun clear(c: Context) { Cfg.p(c).edit().remove(K).apply() }
}

/**
 * 카톡 채팅방 메시지 읽기 / 욕 감지(AI) / 빠른 삭제.
 * 전부 접근성 서비스로 화면을 읽고 누르는 방식이라, 카톡 화면 구조가 바뀌면 글자 라벨만 고치면 됨.
 */
class Mod(private val svc: BotService) {

    companion object {
        const val SCAN_LIMIT = 20000
        /** AI 에 한 번에 보내는 본문 최대 길이(글자). 넘으면 여러 번으로 나눠 보냄 */
        private const val MAX_BODY = 2000
        private const val KAKAO = "com.kakao.talk"
        // 삭제 확인창에서 누를 '모두에게서 삭제' 계열 (나에게서만 삭제는 누르지 않음)
        private val EVERYONE = listOf("모두에게서 삭제", "모든 멤버에게서 삭제", "모든 대화상대에게서 삭제",
            "모두에게 삭제", "모든 멤버에게 삭제", "모두 삭제", "전체 삭제")
        private val ONLY_ME = listOf("나에게서만 삭제", "나에게만 삭제", "내 채팅방에서만 삭제")
        const val FILE_HOWTO = "카톡 채팅방 메뉴(☰) → 대화내용 내보내기 → '텍스트만 저장' → 공유에서 '혜원 봇' 을 고르면 알아서 읽고 욕 검사까지 해요"
        private val BTN_DEL = Regex("^삭제\\s*\\(?\\d*\\)?$")
    }

    class Group(val who: String, val text: String, var count: Int) {
        val key: String get() = who + "\u0001" + text
    }

    private class Item(val node: AccessibilityNodeInfo, val msg: Msg, val top: Int)

    private val ui = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private val aiExec = Executors.newCachedThreadPool()
    @Volatile private var stop = false
    private var statusView: TextView? = null   // 작업 목록 (터치 안 받음)
    private var stopView: TextView? = null     // 작은 '■' 중지 버튼 (이것만 터치 받음)
    private var titleText = ""
    private var gen = 0
    private class Step(var name: String) { var st = 0; var detail = "" }  // st: 0 대기 1 진행 2 완료 3 멈춤/문제
    private val steps = ArrayList<Step>()
    private var chipBase = 0
    private var chipFg = 0
    private var dumped = false
    private var batchOk = true

    private val wm get() = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private fun admin() = Cfg.p(svc).getBoolean("modAdmin", false)
    private fun batchOn() = Cfg.p(svc).getBoolean("modBatch", true) && batchOk
    private fun now() = System.currentTimeMillis()
    private fun fmt(n: Int) = String.format("%,d", n)

    val running: Boolean get() = ModState.running

    fun requestStop() {
        if (!ModState.running) return
        stop = true
        setChip("멈추는 중…")
    }

    fun shutdown() {
        stop = true
        ui.post { hideChipNow() }
    }

    // ================= 공개 동작 =================

    /** 메시지를 어떻게 읽을지: scroll = 화면을 스크롤하며 읽기, file = 카톡 '대화내용 내보내기' 파일 */
    private fun fileMode() = Cfg.p(svc).getString("modReadMode", "scroll") == "file"

    /** 욕 감지: 메시지 읽기(스크롤 또는 내보내기 파일) → AI 에 2000자씩 나눠 물어보기 → 욕 쓴 사람/횟수 */
    fun detect(base: Int, fg: Int) = job("욕 감지", base, fg) {
        if (fileMode()) {
            if (!ModState.fromFile || ModState.msgs.isEmpty()) {
                fileFlow(true)
                return@job
            }
            plan("AI 검사", "결과 정리")
            detectOn(ModState.msgs, 0)
        } else {
            plan("메시지 읽기 (스크롤)", "AI 검사", "결과 정리")
            go(0)
            val list = scanAll("읽는 중") ?: return@job
            ModState.msgs = list
            ModState.fromFile = false
            ModState.stale = false
            setName(0, "메시지 읽기 ${fmt(list.size)}개")
            detectOn(list, 1)
        }
    }

    // ---------- 내보내기 파일 기다리기 ----------
    @Volatile private var waitingFile = false
    @Volatile private var alwaysShow = false
    @Volatile private var fileSlot: List<Msg>? = null

    /** 공유로 파일이 들어옴. 기다리는 작업이 있으면 그 작업에 넘기고, 없으면 바로 새 작업으로 처리 */
    fun deliverFile(list: List<Msg>, base: Int, fg: Int) {
        if (waitingFile) fileSlot = list else importAndDetect(list, base, fg)
    }

    /** 파일 모드에서 '욕 감지'/'메시지 읽기'를 눌렀는데 아직 파일이 없을 때: 해야 할 일을 띄우고 공유로 파일이 올 때까지 기다림 (job 안에서 호출) */
    private fun fileFlow(ai: Boolean) {
        val names = arrayListOf("카톡 채팅방 ☰ → 대화내용 내보내기", "'텍스트만 저장' 고르기", "공유에서 '혜원 봇' 고르기",
            "파일 기다리는 중", "파일 읽기", "내 이름 찾기")
        if (ai) names.add("AI 검사")
        names.add("결과 정리")
        plan(*names.toTypedArray())
        for (k in 0..2) mark(k, 4)
        go(3, "파일 기다리는 중 (공유하면 알아서 시작해요)")
        fileSlot = null
        waitingFile = true
        alwaysShow = true   // 공유 창이 뜨는 동안에도 목록이 보이게
        val t0 = now()
        try {
            while (!stop && fileSlot == null && now() - t0 < 10 * 60 * 1000L) {
                try { Thread.sleep(150) } catch (e: InterruptedException) { break }
            }
        } finally {
            waitingFile = false
            alwaysShow = false
        }
        val got = fileSlot
        fileSlot = null
        if (got == null) {
            ModState.lastReport = if (stop) "파일을 받기 전에 멈춤" else "10분 동안 파일이 안 와서 끝냈어요"
            return
        }
        setName(4, "파일 읽기 (${fmt(got.size)}개)")
        go(5)
        val list = resolveMe(got, 5)
        ModState.msgs = list
        ModState.fromFile = true
        ModState.stale = false
        ModState.bad = emptyList()
        if (ai) {
            detectOn(list, 6)
        } else {
            ModState.lastReport = "파일에서 메시지 ${fmt(list.size)}개 읽음"
        }
    }

    /** '내보내기 파일'을 공유로 받았을 때: 읽어 둔 뒤 내 이름 찾기 → 바로 AI 검사까지 */
    fun importAndDetect(list0: List<Msg>, base: Int, fg: Int) = job("욕 감지 (파일)", base, fg) {
        plan("파일 읽기 (${fmt(list0.size)}개)", "내 이름 찾기", "AI 검사", "결과 정리")
        go(1)
        val list = resolveMe(list0, 1)
        ModState.msgs = list
        ModState.fromFile = true
        ModState.stale = false
        ModState.bad = emptyList()
        detectOn(list, 2)
    }

    /**
     * 파일 속 '보낸 사람' 중 누가 나인지 자동으로 찾음.
     * 지금 카톡 화면에 보이는 내 말풍선 글자와 파일 속 글자를 맞춰 보고, 가장 많이 맞는 이름을 나로 정함.
     * 화면에서 못 찾으면 전에 찾아 둔 이름을 씀.
     */
    private fun resolveMe(list: List<Msg>, idx: Int): List<Msg> {
        setChip("화면의 내 말풍선과 맞춰 보는 중")
        val saved = Cfg.p(svc).getString("myName", "") ?: ""
        val mine = HashSet<String>()
        val screen = waitFor(2500, 100) { readScreen()?.takeIf { it.isNotEmpty() } }
        if (screen != null) for (i in screen) if (i.msg.own && i.msg.text.length >= 2) mine.add(i.msg.text)
        var name = ""
        if (mine.isNotEmpty()) {
            val perName = HashMap<String, HashSet<String>>()   // 이름 -> 화면의 내 글자 중 그 사람이 보낸 적 있는 것
            for (m in list) {
                val s = m.sender ?: continue
                if (m.text in mine) perName.getOrPut(s) { HashSet() }.add(m.text)
            }
            val top = perName.entries.sortedByDescending { it.value.size }
            if (top.isNotEmpty() && (top.size == 1 || top[0].value.size > top[1].value.size)) name = top[0].key
        }
        val how = if (name.isNotEmpty()) "자동 감지" else "전에 찾은 이름"
        if (name.isEmpty()) name = saved
        if (name.isEmpty()) {
            Bridge.log("내 이름을 못 찾음 (채팅방 화면에 내 말풍선이 보여야 해요)")
            setName(idx, "내 이름 못 찾음")
            return list
        }
        Cfg.p(svc).edit().putString("myName", name).apply()
        setName(idx, "내 이름: $name")
        Bridge.log("내 이름: $name ($how)")
        return list.map { if (it.sender == name) Msg(null, it.text, true) else it }
    }

    /** 이미 읽은 메시지에서 AI 로 욕 찾기 (job 안에서 호출). ai = 'AI 검사' 단계 번호 */
    private fun detectOn(list: List<Msg>, ai: Int) {
        if (stop) { ModState.lastReport = "중간에 멈춤 · 메시지 ${fmt(list.size)}개까지 읽음 (AI 검사는 안 함)"; return }
        if (list.isEmpty()) { ModState.lastReport = "읽은 메시지가 없어요. 채팅방 안에서 눌러 주세요"; return }
        go(ai, "AI 검사 준비")
        val r = checkBad(list) ?: return
        go(ai + 1)
        val (badTexts, calls) = r
        val bad = list.filter { badTexts.contains(it.text) }
        ModState.bad = bad
        val who = ModState.counts().size
        ModState.lastReport = "메시지 ${fmt(list.size)}개 ${if (ModState.fromFile) "(파일)" else ""} 읽음 · AI ${calls}번 검사 · 욕 ${fmt(bad.size)}개 · ${who}명"
        Bridge.log("욕 감지 끝: ${ModState.lastReport}")
    }

    /** 메시지만 읽기 (검색용) */
    fun scan(base: Int, fg: Int) {
        if (fileMode()) {
            job("파일로 읽기", base, fg) { fileFlow(false) }
            return
        }
        scanScreen(base, fg)
    }

    private fun scanScreen(base: Int, fg: Int) = job("메시지 읽기", base, fg) {
        plan("메시지 읽기 (스크롤)")
        go(0)
        val list = scanAll("읽는 중") ?: return@job
        ModState.msgs = list
        ModState.fromFile = false
        ModState.stale = false
        ModState.lastReport = if (stop) "중간에 멈춤 · 메시지 ${fmt(list.size)}개까지 읽음" else "메시지 ${fmt(list.size)}개 읽음"
    }

    /** 욕 지우기: 감지된 욕 메시지를 화면에서 찾아 자동 삭제 */
    fun deleteBad(base: Int, fg: Int) {
        val set = HashSet<String>()
        for (m in ModState.bad) set.add(m.text)
        if (set.isEmpty()) { ModState.lastReport = "지울 욕이 없어요. 먼저 '욕 감지'를 눌러 주세요"; return }
        job("욕 지우는 중", base, fg) {
            val r = deletePass("욕") { it.text in set }
            if (!r.stopped && !r.aborted && r.failed == 0) ModState.bad = emptyList()
        }
    }

    /** 반복 전송으로 보냈던 내 메시지 전부 지우기 */
    fun deleteRepeat(base: Int, fg: Int) {
        val reps = RepMem.all(svc)
        if (reps.isEmpty()) { ModState.lastReport = "기억된 반복 메세지가 없어요"; return }
        job("반복 메세지 지우는 중", base, fg) {
            deletePass("반복 메세지") { it.own && reps.any { r -> it.text == r || (it.text.startsWith("@") && it.text.endsWith(r)) } }
        }
    }

    /** 검색해서 고른 것 지우기 (같은 사람이 보낸 같은 글자는 전부) */
    fun deleteGroups(groups: List<Group>, base: Int, fg: Int) {
        val keys = HashSet<String>()
        for (g in groups) keys.add(g.key)
        if (keys.isEmpty()) return
        job("고른 메시지 지우는 중", base, fg) {
            deletePass("선택") { val m = it; (m.own || m.sender != null) && (m.who() + "\u0001" + m.text) in keys }
        }
    }

    /** 읽어 둔 메시지에서 글자 검색 (같은 사람·같은 글자는 묶어서) */
    fun search(q: String): List<Group> {
        val s = q.trim().lowercase()
        if (s.isEmpty()) return emptyList()
        val map = LinkedHashMap<String, Group>()
        for (m in ModState.msgs.asReversed()) {
            if (!m.text.lowercase().contains(s)) continue
            val g = Group(m.who(), m.text, 0)
            val e = map.getOrPut(g.key) { g }
            e.count++
        }
        return map.values.toList()
    }

    // ================= 작업 실행 틀 =================

    private fun job(title: String, base: Int, fg: Int, body: () -> Unit) {
        if (ModState.running) return
        ModState.running = true
        stop = false
        dumped = false
        batchOk = true
        svc.setPause(true)
        chipBase = base
        chipFg = fg
        val myGen = ++gen
        synchronized(steps) { steps.clear() }
        showChip(title)
        exec.execute {
            try {
                try { Thread.sleep(300) } catch (e: InterruptedException) { }  // 패널/키보드가 닫히고 카톡 화면이 보일 때까지
                if (stop) {
                    ModState.lastReport = "시작하기 전에 멈춤"
                } else {
                    body()
                }
            } catch (e: Exception) {
                Bridge.log("$title 오류: ${e.message}")
                ModState.lastReport = "오류: ${(e.message ?: e.toString()).take(120)}"
            } finally {
                ModState.running = false
                svc.setPause(false)
                val ok = !stop && !Regex("못 찾|못 읽|실패|오류").containsMatchIn(ModState.lastReport)
                finishSteps(ok)
                ui.post {
                    // 카톡 화면이 아닐 때(다른 앱 보는 중)는 패널을 억지로 띄우지 않고 짧은 알림만
                    if (svc.kakaoOnScreen()) svc.reopenPanel()
                    else Toast.makeText(svc.applicationContext, ModState.lastReport.take(120), Toast.LENGTH_LONG).show()
                    ui.postDelayed({ if (gen == myGen) hideChipNow() }, 2000) // 끝난 모습을 잠깐 보여주고 사라짐
                }
            }
        }
    }

    // ---------- 해야 할 일 목록 (실시간) ----------
    private fun plan(vararg names: String) {
        synchronized(steps) { steps.clear(); for (n in names) steps.add(Step(n)) }
        render()
    }

    /** i 번째 일을 '진행 중'으로. 앞의 일들은 완료로 */
    private fun go(i: Int, detail: String = "") {
        synchronized(steps) {
            for (k in steps.indices) if (k < i && steps[k].st != 3) steps[k].st = 2
            if (i in steps.indices) { steps[i].st = 1; steps[i].detail = detail }
        }
        render()
    }

    private fun mark(i: Int, st: Int) {
        synchronized(steps) { if (i in steps.indices) steps[i].st = st }
        render()
    }

    private fun setName(i: Int, name: String) {
        synchronized(steps) { if (i in steps.indices) steps[i].name = name }
        render()
    }

    private fun finishSteps(ok: Boolean) {
        synchronized(steps) {
            for (s in steps) {
                if (s.st == 1) { s.st = if (ok) 2 else 3; if (!ok) s.detail = if (stop) "멈춤" else "문제 있음" }
                else if ((s.st == 0 || s.st == 4) && ok) s.st = 2
            }
        }
        render()
    }

    private fun renderText(): String {
        val sb = StringBuilder(titleText)
        synchronized(steps) {
            for (s in steps) {
                sb.append('\n').append(when (s.st) { 0 -> "○ "; 1 -> "▶ "; 2 -> "✔ "; 4 -> "☐ "; else -> "✖ " })
                sb.append(if ((s.st == 1 || s.st == 3) && s.detail.isNotEmpty()) s.detail else s.name)
            }
        }
        return sb.toString()
    }

    private fun render() { ui.post { statusView?.text = renderText() } }

    private fun setChip(text: String) {
        synchronized(steps) { steps.firstOrNull { it.st == 1 }?.detail = text }
        render()
    }

    // ================= 화면 위 표시 (작게, 터치는 통과, '■' 만 눌림) =================

    private val visPoll = object : Runnable {
        override fun run() {
            if (statusView == null) return
            val vis = if (alwaysShow || svc.kakaoOnScreen()) View.VISIBLE else View.GONE // 카톡을 벗어나면 숨김
            statusView?.visibility = vis
            stopView?.visibility = vis
            ui.postDelayed(this, 700)
        }
    }

    private fun showChip(t: String) {
        titleText = t
        ui.post {
            hideChipNow()
            val dm = svc.resources.displayMetrics
            val dp = dm.density
            val bgc = (chipFg and 0x00FFFFFF) or (0xE0 shl 24)
            val y = (dm.heightPixels * 0.14).toInt()
            val st = TextView(svc).apply {
                textSize = 11f
                setTextColor(chipBase)
                setPadding((8 * dp).toInt(), (5 * dp).toInt(), (8 * dp).toInt(), (5 * dp).toInt())
                background = GradientDrawable().apply { setColor(bgc); cornerRadius = 10 * dp }
                maxWidth = (dm.widthPixels * 0.6).toInt()
                setText(renderText())
            }
            val lpS = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lpS.gravity = Gravity.TOP or Gravity.END
            lpS.x = (12 * dp).toInt() + (40 * dp).toInt()
            lpS.y = y
            val sp = TextView(svc).apply {
                setText("■")
                textSize = 14f
                setTypeface(null, Typeface.BOLD)
                gravity = Gravity.CENTER
                setTextColor(chipBase)
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(bgc) }
                isClickable = true
                setOnClickListener { requestStop() }
            }
            val lpB = WindowManager.LayoutParams(
                (34 * dp).toInt(), (34 * dp).toInt(),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            )
            lpB.gravity = Gravity.TOP or Gravity.END
            lpB.x = (12 * dp).toInt()
            lpB.y = y
            try {
                wm.addView(st, lpS); statusView = st
                wm.addView(sp, lpB); stopView = sp
                ui.postDelayed(visPoll, 700)
            } catch (e: Exception) { Bridge.log("작업 표시를 못 띄웠어요: ${e.message}") }
        }
    }

    private fun hideChipNow() {
        ui.removeCallbacks(visPoll)
        for (v in listOf(statusView, stopView)) if (v != null) { try { wm.removeView(v) } catch (e: Exception) { } }
        statusView = null
        stopView = null
    }

    // ================= 화면 읽기 =================

    private fun idOf(n: AccessibilityNodeInfo) = n.viewIdResourceName ?: ""
    private fun txt(n: AccessibilityNodeInfo) = n.text?.toString()?.trim() ?: ""
    private fun rect(n: AccessibilityNodeInfo): Rect = Rect().also { n.getBoundsInScreen(it) }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, d: Int = 0) {
        if (n == null || d > 60) return
        out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, d + 1)
    }

    private fun byId(root: AccessibilityNodeInfo, id: String): List<AccessibilityNodeInfo> =
        try { root.findAccessibilityNodeInfosByViewId(id) ?: emptyList() } catch (e: Exception) { emptyList() }

    /** 지금 화면의 메시지들 (위 → 아래). 카톡 화면이 없으면 null */
    private fun readScreen(): List<Item>? {
        val root = svc.kakaoRoot() ?: return null
        val dm = svc.resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        var msgNodes = byId(root, "com.kakao.talk:id/message").filter { txt(it).isNotEmpty() }
        var nameNodes = byId(root, "com.kakao.talk:id/name") + byId(root, "com.kakao.talk:id/nickname")
        if (msgNodes.isEmpty()) {
            // 아이디로 못 찾으면 화면 전체를 훑어서 찾음 (느리지만 안전망)
            val all = ArrayList<AccessibilityNodeInfo>()
            collect(root, all)
            val inputTop = all.firstOrNull { it.isEditable }?.let { rect(it).top } ?: h
            msgNodes = all.filter { idOf(it).endsWith("/message") && txt(it).isNotEmpty() }
            if (msgNodes.isEmpty()) {
                msgNodes = all.filter {
                    val r = rect(it)
                    it.className?.toString()?.endsWith("TextView") == true && !it.isEditable &&
                        txt(it).isNotEmpty() && r.top > h * 0.12 && r.bottom < inputTop
                }
            }
            nameNodes = all.filter { idOf(it).endsWith("/name") || idOf(it).endsWith("/nickname") }
        }
        class Ev(val top: Int, val node: AccessibilityNodeInfo, val isName: Boolean, val own: Boolean)
        val evs = ArrayList<Ev>()
        for (n in msgNodes) {
            val r = rect(n)
            evs.add(Ev(r.top, n, false, (r.left + r.right) / 2 > w * 0.56))
        }
        for (n in nameNodes) {
            if (txt(n).isEmpty()) continue
            val r = rect(n)
            if (r.top < h * 0.09 || (r.left + r.right) / 2 > w * 0.7) continue // 위쪽 제목줄/내 쪽 글자는 이름이 아님
            evs.add(Ev(r.top, n, true, false))
        }
        evs.sortBy { it.top }
        val out = ArrayList<Item>()
        var cur: String? = null
        for (e in evs) {
            if (e.isName) { cur = txt(e.node); continue }
            if (e.own) {
                cur = null
                out.add(Item(e.node, Msg(null, normText(txt(e.node)), true), e.top))
            } else {
                out.add(Item(e.node, Msg(cur, normText(txt(e.node)), false), e.top))
            }
        }
        return out
    }

    private fun sig(items: List<Item>): Int {
        var h = items.size
        for (i in items) { h = h * 31 + i.msg.text.hashCode(); h = h * 31 + i.top }
        return h
    }

    // ---------- 스크롤 ----------
    private fun findScroller(from: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var p = from.parent
        var d = 0
        while (p != null && d < 14) {
            if (p.isScrollable) return p
            p = p.parent
            d++
        }
        return null
    }

    private fun scrollerOf(items: List<Item>): AccessibilityNodeInfo? {
        for (it in items.take(4)) { val s = findScroller(it.node); if (s != null) return s }
        return null
    }

    private fun scrollOnce(sc: AccessibilityNodeInfo, up: Boolean): Boolean {
        val dir = if (up) AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP.id
        else AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.id
        if (sc.performAction(dir)) return true
        return sc.performAction(if (up) AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    private fun <T> waitFor(ms: Long, poll: Long = 10, f: () -> T?): T? {
        val end = now() + ms
        while (true) {
            val v = f()
            if (v != null) return v
            if (now() >= end) return null
            try { Thread.sleep(poll) } catch (e: InterruptedException) { return null }
        }
    }

    /** 스크롤 애니메이션이 끝나서 화면이 가만히 있을 때까지 기다렸다가 읽음 */
    private fun settle(first: List<Item>): List<Item> {
        var cur = first
        for (i in 0 until 8) {
            try { Thread.sleep(35) } catch (e: InterruptedException) { return cur }
            val n = readScreen() ?: return cur
            if (sig(n) == sig(cur)) return n
            cur = n
        }
        return cur
    }

    /** 한 번 스크롤하고 새 화면을 읽음. 더 못 움직이면(맨 위/맨 아래) null. 카톡이 옛 메시지를 불러오는 시간을 기다려 줌 */
    private fun scrollAndRead(items: List<Item>, up: Boolean, patience: Int = 6): List<Item>? {
        val prevSig = sig(items)
        var sc = scrollerOf(items) ?: return null
        for (attempt in 0 until patience) {
            if (stop) return null
            // 오래 안 움직이면(카톡이 옛 메시지를 아직 못 불러옴) 살짝 아래로 갔다 올라가서 불러오기를 다시 건드려 봄
            if (attempt > 0 && attempt % 4 == 0) {
                scrollOnce(sc, !up)
                try { Thread.sleep(150) } catch (e: InterruptedException) { return null }
            }
            val moved = scrollOnce(sc, up)
            val got = waitFor(if (moved) 900 else 300, 12) {
                val s = readScreen()
                if (s != null && s.isNotEmpty() && sig(s) != prevSig) s else null
            }
            if (got != null) return settle(got)
            if (!moved) { // 스크롤 대상이 낡았을 수 있어서 다시 찾음
                val again = readScreen()
                if (again != null) sc = scrollerOf(again) ?: sc
            }
        }
        return null
    }

    // ---------- 위치 기억 + 한 번에 확 점프 ----------
    /** 지금 화면 맨 위 메시지가 기억해 둔 목록(오래된 것 → 최신)에서 몇 번째인지. hint 에 가까운 것을 고름. 못 찾으면 -1 */
    private fun locate(items: List<Item>, live: List<Msg>, hint: Int): Int {
        if (items.isEmpty() || live.isEmpty()) return -1
        val k = minOf(items.size, 5)
        var best = -1
        var bestD = Int.MAX_VALUE
        var i = 0
        while (i + k <= live.size) {
            var ok = true
            for (j in 0 until k) {
                val a = live[i + j]; val b = items[j].msg
                if (a.text != b.text || a.own != b.own) { ok = false; break }
            }
            if (ok) {
                val d = if (hint < 0) 0 else Math.abs(i - hint)
                if (d < bestD) { bestD = d; best = i }
            }
            i++
        }
        return best
    }

    /** 스크롤 값을 크게 줘서 pages 쪽 위로 한꺼번에 올라감 (읽지 않고 쭉). 카톡이 옛 메시지를 불러오는 중이면 기다렸다가 계속 */
    private fun bigScroll(sc: AccessibilityNodeInfo, pages: Int) {
        var done = 0
        var stall = 0
        while (!stop && done < pages) {
            if (scrollOnce(sc, true)) {
                done++; stall = 0
                if (done % 10 == 0) setChip("확 올라가는 중 ${done}/${pages}")
                try { Thread.sleep(30) } catch (e: InterruptedException) { return }
            } else {
                stall++
                if (stall >= 14) return
                try { Thread.sleep(250) } catch (e: InterruptedException) { return }
            }
        }
    }

    /** 맨 아래(가장 최신)로 이동. 이미 아래면 바로 끝 */
    private fun jumpToBottom(): Boolean {
        var items = readScreen() ?: return false
        var sc = scrollerOf(items) ?: return false
        var fails = 0
        var pages = 0
        while (!stop) {
            if (scrollOnce(sc, false)) {
                fails = 0
                pages++
                if (pages % 15 == 0) setChip("맨 아래로 이동 중")
                try { Thread.sleep(30) } catch (e: InterruptedException) { return false }
            } else {
                fails++
                if (fails >= 3) break
                try { Thread.sleep(120) } catch (e: InterruptedException) { return false }
                items = readScreen() ?: return false
                sc = scrollerOf(items) ?: sc
            }
        }
        return !stop
    }

    // ================= 메시지 읽기 (맨 아래 → 위로) =================

    private class Acc {
        val chunks = ArrayList<List<Msg>>()   // 0번이 가장 최신 화면, 뒤로 갈수록 오래된 것
        var window: List<Msg> = emptyList()    // 지금까지 읽은 것 중 가장 오래된 쪽 몇 개 (겹침 찾기용)
        var count = 0

        private fun same(a: Msg, b: Msg) = a.text == b.text && a.own == b.own

        fun add(s: List<Msg>) {
            if (s.isEmpty()) return
            if (window.isEmpty()) { chunks.add(s); window = s.take(60); count += s.size; return }
            var k = 0
            for (kk in minOf(s.size, window.size) downTo 1) {
                var ok = true
                for (i in 0 until kk) if (!same(s[s.size - kk + i], window[i])) { ok = false; break }
                if (ok) { k = kk; break }
            }
            for (i in 0 until k) { // 겹친 부분은 이름이 더 잘 보이는 쪽 값으로 채움
                val a = window[i]; val b = s[s.size - k + i]
                if (a.sender == null && !a.own) a.sender = b.sender
            }
            val fresh = s.subList(0, s.size - k)
            if (fresh.isNotEmpty()) {
                chunks.add(fresh)
                window = (fresh + window).take(60)
                count += fresh.size
            }
        }

        fun flatten(): List<Msg> {
            val out = ArrayList<Msg>(count)
            for (i in chunks.indices.reversed()) out.addAll(chunks[i])
            // 이름이 한 번만 찍히는 연속 말풍선: 앞의 이름을 이어서 채움
            var cur: String? = null
            for (m in out) {
                if (m.own) { cur = null; continue }
                if (m.sender != null) cur = m.sender else m.sender = cur
            }
            return out
        }
    }

    /** 맨 아래에서부터 위로 올라가며 최대 SCAN_LIMIT 개 읽음. 실패하면 null (이유는 lastReport) */
    private fun scanAll(label: String): List<Msg>? {
        if (!jumpToBottom()) { if (stop) return emptyList(); ModState.lastReport = "카톡 채팅방 화면을 못 찾았어요 (채팅방 안에서 눌러 주세요)"; return null }
        var items = readScreen()
        if (items == null || items.isEmpty()) { ModState.lastReport = "화면에서 메시지를 못 찾았어요 (글자 메시지가 보이는 채팅방에서 눌러 주세요)"; return null }
        items = settle(items)
        val acc = Acc()
        acc.add(items.map { it.msg })
        while (!stop && acc.count < SCAN_LIMIT) {
            setChip("$label ${fmt(acc.count)} / ${fmt(SCAN_LIMIT)}")
            val next = scrollAndRead(items!!, true) ?: break
            items = next
            acc.add(next.map { it.msg })
        }
        val all = acc.flatten()
        return if (all.size > SCAN_LIMIT) all.takeLast(SCAN_LIMIT) else all
    }

    // ================= AI 로 욕 찾기 (2000자씩 나눠서) =================

    private fun worth(t: String): Boolean {
        if (t.length < 2) return false
        if (t.startsWith("삭제된 메시지")) return false
        if (!t.any { it in '가'..'힣' || it in 'ㄱ'..'ㅣ' || it.isLetter() }) return false
        if (t.all { it in "ㅋㅎㅠㅜㅡㅇㅏ.~!?,… " }) return false
        if (t.startsWith("http://") || t.startsWith("https://")) return false
        return true
    }

    private class StopEx : Exception("stop")

    /** AI 호출을 따로 돌리고, 중지 버튼이 눌리면 기다리지 않고 바로 빠져나옴. 분당 한도에 걸리면 잠깐 쉬었다가 다시 */
    private fun askStoppable(body: String, opts: Opts): String {
        var waits = 0
        while (true) {
            val fut = aiExec.submit<String> { Ai.ask(listOf(Entry("user", body, "")), opts) }
            try {
                while (true) {
                    if (stop) { fut.cancel(true); throw StopEx() }
                    try { return fut.get(150, java.util.concurrent.TimeUnit.MILLISECONDS) }
                    catch (e: java.util.concurrent.TimeoutException) { continue }
                }
            } catch (e: java.util.concurrent.ExecutionException) {
                val msg = e.cause?.message ?: e.message ?: ""
                val limited = msg.contains("분에") || msg.contains("쉬는 중") || msg.contains("429")
                if (!limited || ++waits > 12) throw Exception(msg)
                setChip("AI 한도 대기 ${waits}/12")
                for (i in 0 until 50) { if (stop) throw StopEx(); try { Thread.sleep(100) } catch (x: InterruptedException) { throw StopEx() } }
            }
        }
    }

    private fun parseIds(raw: String, n: Int): Set<Int> {
        val a = raw.indexOf('[')
        val b = raw.lastIndexOf(']')
        val body = when {
            a >= 0 && b > a -> raw.substring(a + 1, b)
            a >= 0 -> raw.substring(a + 1)
            else -> raw
        }
        return Regex("\\d+").findAll(body).mapNotNull { it.value.toIntOrNull() }.filter { it in 1..n }.toSet()
    }

    /** AI 에 보내는 한 줄: '번호|메시지' (메시지는 300자까지, 줄바꿈은 공백으로) */
    private fun bodyLine(n: Int, t: String): String = "$n|${t.take(300).replace("\n", " ")}"

    /** (욕이 든 글자들, AI 호출 횟수). 실패하면 null */
    private fun checkBad(list: List<Msg>): Pair<Set<String>, Int>? {
        val uniq = LinkedHashSet<String>()
        for (m in list) if (worth(m.text)) uniq.add(m.text)
        val texts = uniq.toList()
        if (texts.isEmpty()) return Pair(emptySet(), 0)
        // AI 에 한 번에 보내는 본문의 실제 길이가 MAX_BODY(2000자)를 넘지 않게 나눠서 여러 번 보냄
        val parts = ArrayList<List<String>>()
        var cur = ArrayList<String>()
        var curLen = 0
        for (t in texts) {
            val add = bodyLine(cur.size + 1, t).length + (if (cur.isEmpty()) 0 else 1)   // +1 = 줄바꿈
            if (cur.isNotEmpty() && curLen + add > MAX_BODY) {
                parts.add(cur)
                cur = ArrayList()
                curLen = 0
            }
            curLen += bodyLine(cur.size + 1, t).length + (if (cur.isEmpty()) 0 else 1)
            cur.add(t)
        }
        if (cur.isNotEmpty()) parts.add(cur)
        val bad = HashSet<String>()
        val opts = Opts(
            system = "너는 카카오톡 단톡방 관리 보조야. 아래는 '번호|메시지' 목록이야. " +
                "이 중 욕설, 비속어, 비하·모욕, 패드립(가족 욕), 성적 모욕, 혐오 표현이 들어 있는 메시지의 번호만 골라.\n" +
                "- 초성/변형 욕(ㅅㅂ, ㅂㅅ, ㅈㄹ, 시1발, 씨빨, 병1신, 좆, 개새끼 등)도 포함.\n" +
                "- 욕이 아닌 일반 감탄·속어('아 진짜', '대박', '미쳤다')나, 욕을 하지 말자는 말은 제외. 애매하면 제외.\n" +
                "- 출력은 번호 JSON 배열 하나만. 예: [3, 17, 42]. 없으면 []. 다른 설명은 쓰지 마.",
            temperature = 0.0, maxTokens = 8192, context = 1
        )
        for ((pi, part) in parts.withIndex()) {
            if (stop) { ModState.lastReport = "AI 검사 중 멈춤"; return null }
            setChip("AI 검사 ${pi + 1}/${parts.size}")
            val body = part.withIndex().joinToString("\n") { (i, t) -> bodyLine(i + 1, t) }
            val raw = try {
                askStoppable(body, opts)
            } catch (e: StopEx) {
                ModState.lastReport = "AI 검사 중 멈춤 (${pi}/${parts.size}번 끝남)"
                return null
            } catch (e: Exception) {
                ModState.lastReport = "AI 검사 ${pi + 1}/${parts.size} 실패: ${(e.message ?: "").take(100)}"
                Bridge.log(ModState.lastReport)
                return null
            }
            for (id in parseIds(raw, part.size)) bad.add(part[id - 1])
            Bridge.log("AI 검사 ${pi + 1}/${parts.size}: 욕 의심 누적 ${bad.size}개")
        }
        return Pair(bad, parts.size)
    }

    // ================= 삭제 =================

    private class Result(var deleted: Int = 0, var failed: Int = 0, var stopped: Boolean = false, var aborted: Boolean = false)

    private fun keyOf(i: Item) = (if (i.msg.own) "1" else "0") + i.msg.text + "@" + (i.msg.sender ?: "")

    /** 맨 아래로 간 뒤, 위로 올라가며 조건에 맞는 메시지를 지움. 내 것은 항상, 남의 것은 '방장/부방장' 스위치가 켜졌을 때만.
     *  읽어 둔 메시지 목록으로 '다음 지울 것'의 위치를 기억해 두고, 멀면 스크롤 값을 크게 줘서 확 올라감 */
    private fun deletePass(label: String, match: (Msg) -> Boolean): Result {
        val r = Result()
        val adm = admin()
        var mine = 0
        var others = 0
        val skippedOthers = HashSet<String>()
        val failCount = HashMap<String, Int>()
        var consec = 0
        val live = ArrayList<Msg>(ModState.msgs)   // 기억해 둔 위치 (지울 때마다 같이 줄어듦)
        var hint = live.size - 1
        var loadRetry = 0
        plan("맨 아래로 이동", "$label 지우는 중", "마무리")
        go(0)
        if (!jumpToBottom()) {
            r.aborted = true
            ModState.lastReport = if (stop) "맨 아래로 가는 중 멈춤" else "카톡 채팅방 화면을 못 찾았어요 (채팅방 안에서 눌러 주세요)"
            return r
        }
        go(1)
        var items: List<Item>? = readScreen()?.let { settle(it) }
        while (!stop && items != null) {
            var guard = 0
            while (!stop && guard++ < 2000) {
                val cands = items!!.filter { match(it.msg) && (failCount[keyOf(it)] ?: 0) < 3 }
                val allowed = ArrayList<Item>()
                for (c in cands) {
                    if (c.msg.own || adm) allowed.add(c) else skippedOthers.add(keyOf(c))
                }
                if (allowed.isEmpty()) break
                val t0 = now()
                val top0 = locate(items!!, live, hint)
                val done = deleteOne(allowed[0], allowed.drop(1))
                if (done.isNotEmpty()) {
                    consec = 0
                    loadRetry = 0
                    failCount.remove(keyOf(allowed[0]))
                    for (d in done) { if (d.msg.own) mine++ else others++ }
                    r.deleted += done.size
                    // 기억한 목록에서도 뺌 (위치가 어긋나지 않게 큰 번호부터)
                    if (top0 >= 0) {
                        val idxs = ArrayList<Int>()
                        for (d in done) {
                            val pos = items!!.indexOf(d)
                            if (pos >= 0 && top0 + pos < live.size && live[top0 + pos].text == d.msg.text) idxs.add(top0 + pos)
                        }
                        for (ix in idxs.sortedDescending()) live.removeAt(ix)
                        hint = top0
                    }
                    setChip("지우는 중 ${fmt(r.deleted)}개")
                    Bridge.log("삭제 ${done.size}개 (${now() - t0}ms)")
                    items = readScreen() ?: break
                } else {
                    consec++
                    r.failed++
                    val fk = keyOf(allowed[0])
                    failCount[fk] = (failCount[fk] ?: 0) + 1
                    Bridge.log("삭제 실패(${failCount[fk]}/3): ${allowed[0].msg.text.take(30)}")
                    if (consec >= 6) { r.aborted = true; break }
                    items = readScreen()?.let { settle(it) } ?: break
                }
            }
            if (stop || r.aborted) break
            val cur = items ?: break
            // ---- 다음 지울 것이 어디 있는지 기억에서 찾아서, 멀면 한 번에 확 올라감 ----
            val top = locate(cur, live, hint)
            var remainKnown = true
            if (top >= 0 && live.size > 1) {
                hint = top
                var t = -1
                var i = top - 1
                while (i >= 0) { if (match(live[i])) { t = i; break }; i-- }
                if (t < 0) { remainKnown = false }   // 위쪽에 더 지울 게 없음 → 끝
                else {
                    val per = maxOf(cur.size, 4)
                    val pages = (top - t) / per - 1
                    if (pages >= 2) {
                        val sc = scrollerOf(cur)
                        if (sc != null) { Bridge.log("점프: ${top - t}개 위로 (${pages}쪽)"); bigScroll(sc, pages) }
                    }
                }
            }
            if (!remainKnown) break
            if (stop) break
            val next = scrollAndRead(cur, true, if (top >= 0) 25 else 8)
            if (next == null) {
                // 카톡이 옛 메시지를 아직 못 불러온 것일 수 있음 → 지울 게 남아 있으면 몇 번 더 기다리며 시도
                if (!stop && top >= 0 && loadRetry++ < 4) {
                    Bridge.log("위로 안 올라감 → 불러오는 중인지 다시 시도 ($loadRetry/4)")
                    try { Thread.sleep(1200) } catch (e: InterruptedException) { }
                    items = readScreen()?.let { settle(it) } ?: break
                    continue
                }
                break
            }
            loadRetry = 0
            items = next
        }
        r.stopped = stop
        go(2)
        val sb = StringBuilder()
        sb.append(label).append(" 삭제 ").append(fmt(r.deleted)).append("개")
        if (r.deleted > 0) sb.append(" (내 것 ").append(mine).append(" · 남의 것 ").append(others).append(")")
        if (r.stopped) sb.append(" · 중간에 멈춤")
        if (r.aborted) sb.append(" · 연속 실패로 중단 (로그/덤프 확인)")
        else if (r.failed > 0) sb.append(" · 실패 ").append(r.failed)
        if (skippedOthers.isNotEmpty()) sb.append(" · 남의 메시지 ").append(skippedOthers.size).append("종류는 방장/부방장 스위치가 꺼져 있어 건너뜀")
        ModState.lastReport = sb.toString()
        ModState.stale = true
        Bridge.log(ModState.lastReport)
        return r
    }

    // ================= 전체 답장 =================

    /**
     * 욕으로 검사된 메시지마다 카톡 '답장' 기능으로 글을 보냄 (답장은 채팅방 모두에게 보임).
     * 맨 아래 → 위로 올라가며, 삭제와 똑같이 위치를 기억해 멀면 확 점프함.
     */
    fun replyAll(text: String, base: Int, fg: Int) {
        val msgText = text.trim()
        if (ModState.bad.isEmpty()) { ModState.lastReport = "답장할 욕이 없어요. 먼저 '욕 감지'를 눌러 주세요"; return }
        if (msgText.isEmpty()) { ModState.lastReport = "답장 내용을 적어 주세요"; return }
        job("욕에 전체 답장 중", base, fg) {
            val bad = ModState.bad
            val set = HashSet<String>()
            for (m in bad) set.add(m.text)
            val live = ArrayList<Msg>(ModState.msgs)
            // 이미 답장한 메시지는 기억 목록의 위치로 구분 (같은 글자를 여러 번 쓴 것도 각각 한 번씩)
            val repliedAt = HashSet<String>()
            var sent = 0
            var failed = 0
            var consec = 0
            var hint = live.size - 1
            var loadRetry = 0
            plan("맨 아래로 이동", "답장 보내는 중", "마무리")
            go(0)
            if (!jumpToBottom()) {
                ModState.lastReport = if (stop) "맨 아래로 가는 중 멈춤" else "카톡 채팅방 화면을 못 찾았어요 (채팅방 안에서 눌러 주세요)"
                return@job
            }
            go(1)
            var items: List<Item>? = readScreen()?.let { settle(it) }
            while (!stop && items != null) {
                val cur = items ?: break
                val top = locate(cur, live, hint)
                var did = false
                for ((pos, it) in cur.withIndex()) {
                    if (stop) break
                    if (!set.contains(it.msg.text)) continue
                    val key = if (top >= 0) "p${top + pos}" else "t${it.msg.text}@${it.msg.sender}@${it.top}"
                    if (!repliedAt.add(key)) continue
                    did = true
                    if (replyOne(it, msgText)) { sent++; consec = 0; setChip("답장 보내는 중 ${fmt(sent)}개") }
                    else { failed++; consec++ }
                    break   // 보낸 뒤에는 화면이 바뀌므로 다시 읽어서 이어감
                }
                if (consec >= 6) { Bridge.log("연속 실패로 중단"); break }
                if (did) {
                    items = readScreen()?.let { settle(it) } ?: break
                    continue
                }
                // 이 화면에서 더 할 게 없음 → 위쪽 위치 기억해서 점프
                if (top >= 0) {
                    hint = top
                    var t = -1
                    var i = top - 1
                    while (i >= 0) { if (set.contains(live[i].text)) { t = i; break }; i-- }
                    if (t < 0) break
                    val pages = (top - t) / maxOf(cur.size, 4) - 1
                    if (pages >= 2) { val sc = scrollerOf(cur); if (sc != null) bigScroll(sc, pages) }
                }
                val next = scrollAndRead(cur, true, if (top >= 0) 25 else 8)
                if (next == null) {
                    if (!stop && top >= 0 && loadRetry++ < 4) {
                        try { Thread.sleep(1200) } catch (e: InterruptedException) { }
                        items = readScreen()?.let { settle(it) } ?: break
                        continue
                    }
                    break
                }
                loadRetry = 0
                items = next
            }
            go(2)
            ModState.lastReport = "욕 ${fmt(bad.size)}개 중 답장 ${fmt(sent)}개 보냄" +
                (if (failed > 0) " · 실패 $failed" else "") + (if (stop) " · 중간에 멈춤" else "")
            Bridge.log(ModState.lastReport)
        }
    }

    /** 메시지 하나를 길게 눌러 '답장' → 입력창에 글 넣고 전송 */
    private fun replyOne(item: Item, text: String): Boolean {
        if (!longPress(item.node)) { dumpOnce("답장: 길게 누르기 실패"); return false }
        val menu = waitFor(1500) { findLabel(listOf("답장")) }
        if (menu == null) { dumpOnce("메뉴에서 '답장'을 못 찾음"); closeStray(); return false }
        if (!clickNode(menu)) { closeStray(); return false }
        // 입력창이 나타날 때까지
        val input = waitFor(1500) {
            kakaoRoots().firstNotNullOfOrNull { rt ->
                val all = ArrayList<AccessibilityNodeInfo>(); collect(rt, all)
                all.firstOrNull { it.isEditable }
            }
        }
        if (input == null) { dumpOnce("답장: 입력창을 못 찾음"); closeStray(); return false }
        input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = android.os.Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) { dumpOnce("답장: 글자 넣기 실패"); return false }
        val send = waitFor(1200) {
            kakaoRoots().firstNotNullOfOrNull { rt ->
                val all = ArrayList<AccessibilityNodeInfo>(); collect(rt, all)
                all.firstOrNull { idOf(it).endsWith("/send") || it.contentDescription?.toString() == "전송" || txt(it) == "전송" }
            }
        }
        if (send == null || !clickNode(send)) { dumpOnce("답장: 전송 버튼을 못 찾음"); return false }
        try { Thread.sleep(350) } catch (e: InterruptedException) { }
        return true
    }

    // ---------- 카톡 창 찾기/누르기 ----------
    private fun kakaoRoots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in svc.windows) {
                val r = w.root ?: continue
                if (r.packageName?.toString() == KAKAO) out.add(r)
            }
        } catch (e: Exception) { }
        if (out.isEmpty()) {
            val r = svc.rootInActiveWindow
            if (r != null && r.packageName?.toString() == KAKAO) out.add(r)
        }
        return out
    }

    private fun clickableUp(start: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var n: AccessibilityNodeInfo? = start
        var d = 0
        while (n != null && d < 7) {
            if (n.isClickable) return n
            n = n.parent
            d++
        }
        return null
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        var d = 0
        while (x != null && d < 7) {
            if (x.isClickable && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            x = x.parent
            d++
        }
        return false
    }

    private fun longPress(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        var d = 0
        while (x != null && d < 8) {
            if (x.isLongClickable && x.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) return true
            x = x.parent
            d++
        }
        // 롱클릭 표시가 없어도 한 번씩 시도
        x = n
        d = 0
        while (x != null && d < 6) {
            if (x.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) return true
            x = x.parent
            d++
        }
        return false
    }

    /** 글자가 정확히 labels 중 하나인 노드 (채팅 말풍선은 제외) */
    private fun findLabel(labels: List<String>): AccessibilityNodeInfo? {
        for (r in kakaoRoots()) {
            for (l in labels) {
                val found = try { r.findAccessibilityNodeInfosByText(l) ?: emptyList() } catch (e: Exception) { emptyList<AccessibilityNodeInfo>() }
                for (n in found) {
                    if (idOf(n).endsWith("/message")) continue
                    val t = txt(n)
                    val d = n.contentDescription?.toString()?.trim() ?: ""
                    if (t == l || d == l) return n
                }
            }
        }
        return null
    }

    /** '삭제' / '삭제 3' 같은 버튼 (선택 모드 아래쪽 버튼 또는 확인창) */
    private fun findDeleteButton(): AccessibilityNodeInfo? {
        for (r in kakaoRoots()) {
            val found = try { r.findAccessibilityNodeInfosByText("삭제") ?: emptyList() } catch (e: Exception) { emptyList<AccessibilityNodeInfo>() }
            for (n in found) {
                if (idOf(n).endsWith("/message")) continue
                val t = txt(n).ifEmpty { n.contentDescription?.toString()?.trim() ?: "" }
                if (BTN_DEL.matches(t) && clickableUp(n) != null) return n
            }
        }
        return null
    }

    // ---------- 선택 모드(체크박스) ----------
    private fun rowOf(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        var x: AccessibilityNodeInfo = n
        var d = 0
        while (d < 10) {
            val p = x.parent ?: break
            if (p.isScrollable) return x
            x = p
            d++
        }
        return n
    }

    private fun findCheckable(n: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (n == null || depth > 4) return null
        if (n.isCheckable) return n
        for (i in 0 until n.childCount) {
            val f = findCheckable(n.getChild(i), depth + 1)
            if (f != null) return f
        }
        return null
    }

    private fun hasCheckable(n: AccessibilityNodeInfo): Boolean = try {
        val row = rowOf(n); row.refresh(); findCheckable(row, 0) != null
    } catch (e: Exception) { false }

    private fun isChecked(n: AccessibilityNodeInfo): Boolean = try {
        val row = rowOf(n); row.refresh(); findCheckable(row, 0)?.isChecked == true
    } catch (e: Exception) { false }

    private fun isGone(i: Item): Boolean = try {
        if (!i.node.refresh()) true
        else if (!i.node.isVisibleToUser) true
        else normText(txt(i.node)) != i.msg.text
    } catch (e: Exception) { true }

    private fun closeStray() {
        val cancel = findLabel(listOf("취소"))
        if (cancel != null) { clickNode(cancel); return }
        if (findLabel(listOf("복사")) != null) svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
    }

    /** 선택 모드에서 같은 화면의 다른 대상들도 체크. 체크가 확인되지 않으면 취소하고 null */
    private fun selectOthers(first: Item, others: List<Item>): List<Item>? {
        if (!hasCheckable(first.node)) return emptyList()
        val tapped = ArrayList<Item>()
        for (o in others.take(60)) {
            try { o.node.refresh() } catch (e: Exception) { }
            if (clickNode(o.node)) tapped.add(o)
        }
        if (tapped.isEmpty()) return emptyList()
        try { Thread.sleep(40) } catch (e: InterruptedException) { }
        val ok = isChecked(first.node) && tapped.all { isChecked(it.node) }
        if (ok) return tapped
        // 기대와 다름 → 안전하게 선택 모드를 빠져나가고 한 개씩 지우는 방식으로 돌아감
        Bridge.log("한꺼번에 선택 확인 실패 -> 선택 취소하고 하나씩 지움")
        batchOk = false
        val cancel = findLabel(listOf("취소", "닫기"))
        if (cancel != null) clickNode(cancel) else svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        return null
    }

    /**
     * 메시지 하나(와, 선택 모드면 같은 화면의 다른 대상들)를 지움. 지운 것들을 돌려줌 (비어 있으면 실패).
     * 길게 누르기 → 메뉴 '삭제' → (선택 모드면 아래 '삭제') → '모두에게서 삭제'. 매 단계 0.01초 간격으로 확인해서 바로 다음 단계로 넘어감.
     */
    private fun deleteOne(first: Item, others: List<Item>): List<Item> {
        if (!longPress(first.node)) { dumpOnce("길게 누르기 실패"); return emptyList() }
        val menu = waitFor(1500) { findLabel(listOf("삭제")) }
        if (menu == null) { dumpOnce("메뉴에서 '삭제'를 못 찾음"); closeStray(); return emptyList() }
        if (!clickNode(menu)) { closeStray(); return emptyList() }
        waitFor(500) { if (findLabel(listOf("복사")) == null) true else null } // 메뉴가 닫힐 때까지

        val picked = ArrayList<Item>()
        picked.add(first)
        var btnClicks = 0
        var idleSince = 0L
        val end = now() + 4000
        while (now() < end) {
            val ev = findLabel(EVERYONE)
            if (ev != null) {
                clickNode(ev)
                waitFor(1500) { if (findLabel(EVERYONE) == null) true else null }
                val c2 = waitFor(200) { findLabel(listOf("확인")) } // 한 번 더 묻는 경우
                if (c2 != null) { clickNode(c2); waitFor(1000) { if (findLabel(listOf("확인")) == null) true else null } }
                return finish(picked)
            }
            if (findLabel(ONLY_ME) != null) { // '나에게서만 삭제'만 있으면 남들에게는 안 지워지므로 취소
                val ev2 = waitFor(150) { findLabel(EVERYONE) }
                if (ev2 == null) {
                    dumpOnce("'모두에게서 삭제' 선택지가 없음")
                    val cancel = findLabel(listOf("취소"))
                    if (cancel != null) clickNode(cancel) else svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                    return emptyList()
                }
                continue
            }
            val btn = findDeleteButton()
            if (btn != null && btnClicks < 2) {
                idleSince = 0
                if (btnClicks == 0 && others.isNotEmpty() && batchOn()) {
                    val extra = selectOthers(first, others)
                    if (extra == null) return emptyList()
                    picked.addAll(extra)
                }
                clickNode(btn)
                btnClicks++
                try { Thread.sleep(15) } catch (e: InterruptedException) { }
                continue
            }
            if (btnClicks > 0 && btn == null) { // 누를 게 더 없음 → 조금 기다렸다가 끝난 것으로 봄
                if (idleSince == 0L) idleSince = now() else if (now() - idleSince > 250) return finish(picked)
            }
            try { Thread.sleep(10) } catch (e: InterruptedException) { return emptyList() }
        }
        dumpOnce("삭제 단계가 끝나지 않음")
        closeStray()
        return emptyList()
    }

    /** 첫 메시지가 실제로 사라졌는지(또는 '삭제된 메시지'로 바뀌었는지) 확인 */
    private fun finish(picked: List<Item>): List<Item> {
        val gone = waitFor(900) { if (isGone(picked[0])) true else null }
        if (gone == null) { dumpOnce("눌렀는데 메시지가 그대로 있음"); return emptyList() }
        return picked.filter { isGone(it) }
    }

    /** 실패했을 때 화면 구조를 파일로 저장 (한 작업에 한 번) */
    private fun dumpOnce(why: String) {
        Bridge.log("삭제 문제: $why")
        if (dumped) return
        dumped = true
        try {
            val sb = StringBuilder("# $why\n")
            for (r in kakaoRoots()) {
                val all = ArrayList<AccessibilityNodeInfo>()
                collect(r, all)
                sb.append("--- window ---\n")
                for (n in all) {
                    val rc = rect(n)
                    sb.append("${n.className} | id=${idOf(n)} | text=${n.text} | desc=${n.contentDescription}")
                        .append(" | click=${n.isClickable} long=${n.isLongClickable} check=${n.isCheckable}/${n.isChecked}")
                        .append(" | [${rc.left},${rc.top},${rc.right},${rc.bottom}]\n")
                }
            }
            val f = File(svc.getExternalFilesDir(null) ?: svc.filesDir, "delete_dump.txt")
            f.writeText(sb.toString())
            Bridge.log("삭제 화면 구조 저장: ${f.absolutePath}")
        } catch (e: Exception) {
            Bridge.log("덤프 저장 실패: ${e.message}")
        }
    }
}
