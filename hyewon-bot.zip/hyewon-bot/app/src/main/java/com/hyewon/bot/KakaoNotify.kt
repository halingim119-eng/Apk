package com.hyewon.bot

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** 카톡 알림을 지켜보다가 '답장' 기능을 Replier 에 저장 */
class KakaoNotify : NotificationListenerService() {

    override fun onListenerConnected() {
        Replier.connected = true
        Bridge.log("알림 리스너 연결됨")
        try {
            activeNotifications?.forEach { grab(it) }
        } catch (e: Exception) { }
    }

    override fun onListenerDisconnected() {
        Replier.connected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) grab(sbn)
    }

    private fun grab(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.kakao.talk") return
        try { Replier.capture(sbn.notification) } catch (e: Exception) { }
    }
}
