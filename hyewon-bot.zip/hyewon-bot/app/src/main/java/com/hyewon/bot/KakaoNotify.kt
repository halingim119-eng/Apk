package com.hyewon.bot

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** 카톡 알림을 지켜보다가 '답장' 기능을 Replier 에 저장하고, 자리비움 응답을 처리 */
class KakaoNotify : NotificationListenerService() {

    override fun onListenerConnected() {
        Replier.connected = true
        Bridge.log("알림 리스너 연결됨")
        try {
            // 이미 떠 있던 알림은 답장 기능만 저장 (자동응답은 안 함)
            activeNotifications?.forEach {
                if (it.packageName == "com.kakao.talk") {
                    try { Replier.capture(it.notification) } catch (e: Exception) { }
                }
            }
        } catch (e: Exception) { }
    }

    override fun onListenerDisconnected() {
        Replier.connected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName != "com.kakao.talk") return
        try {
            val m = Replier.capture(sbn.notification) ?: return
            Away.onMessage(applicationContext, m, sbn.postTime)
        } catch (e: Exception) {
            Bridge.log("알림 처리 오류: ${e.message}")
        }
    }
}
