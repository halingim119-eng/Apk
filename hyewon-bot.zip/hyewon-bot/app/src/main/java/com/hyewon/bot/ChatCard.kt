package com.hyewon.bot

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.Executors

/** /cmds 패널에 붙는 'AI 대화' 카드: 감정 부여 / 내 대화 반영 / 대화 지우기 + 패널 안에서 AI와 대화 (최대 200개 저장) */
object ChatCard {
    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    @Volatile private var waiting = false

    fun build(ctx: Context, base: Int, fg: Int, softCol: Int, lineCol: Int, hintCol: Int, onFocus: () -> Unit): LinearLayout {
        val app = ctx.applicationContext
        val dp = ctx.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun round(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
            setColor(color); cornerRadius = r * dp
            if (stroke != null) setStroke(px(1), stroke)
        }
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(18), px(14), px(18), px(14))
            background = round(base, 22, lineCol)
        }
        card.addView(TextView(ctx).apply {
            text = "AI 대화"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(fg)
        })

        // ---- 버튼 ----
        fun pill(t: String, click: (TextView) -> Unit) = TextView(ctx).apply {
            text = t
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(px(8), px(10), px(8), px(10))
            isClickable = true
            setOnClickListener { click(this) }
        }
        fun paintToggle(v: TextView, label: String, on: Boolean) {
            v.text = "$label ${if (on) "켜짐" else "꺼짐"}"
            v.setTextColor(if (on) base else fg)
            v.background = round(if (on) fg else Color.TRANSPARENT, 12, lineCol)
        }
        val lp = { left: Int -> LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = left } }

        val row1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val emo = pill("") { v ->
            val on = !Cfg.emotion(app)
            Cfg.p(app).edit().putBoolean("emotion", on).apply()
            paintToggle(v, "감정 부여", on)
            Bridge.log("감정 부여: ${if (on) "켜짐" else "꺼짐"}")
        }
        paintToggle(emo, "감정 부여", Cfg.emotion(app))
        val mem = pill("") { v ->
            val on = !Cfg.ownerMem(app)
            Cfg.p(app).edit().putBoolean("ownerMem", on).apply()
            paintToggle(v, "내 대화 반영", on)
            Bridge.log("내 대화 반영: ${if (on) "켜짐" else "꺼짐"}")
        }
        paintToggle(mem, "내 대화 반영", Cfg.ownerMem(app))
        row1.addView(emo, lp(0))
        row1.addView(mem, lp(px(8)))
        card.addView(row1, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })

        card.addView(TextView(ctx).apply {
            text = "감정 부여: 따뜻하고 감정이 있는 F 성향 말투로 답해요 · 내 대화 반영: 아래 대화를 카톡 답장 때도 참고해요"
            textSize = 11f
            setTextColor(hintCol)
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(4) })

        // ---- 대화 보기 ----
        val tv = TextView(ctx).apply {
            textSize = 14f
            setTextColor(fg)
            setPadding(px(10), px(8), px(10), px(8))
        }
        val scroll = ScrollView(ctx).apply {
            background = round(softCol, 14, lineCol)
            // 패널 전체 스크롤과 겹치지 않게, 대화창 안에서는 이 스크롤이 먼저 움직임
            setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
            addView(tv)
        }
        card.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, px(170)).apply { topMargin = px(10) })

        val status = TextView(ctx).apply { textSize = 12f; setTextColor(hintCol); visibility = View.GONE }
        card.addView(status, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(4) })

        fun render() {
            val l = ChatLog.load(app)
            val who = Cfg.userName(app)
            tv.text = if (l.isEmpty()) "아직 대화가 없어요. 아래에 적어서 보내보세요." else
                l.joinToString("\n\n") { (if (it.role == "user") who else "AI") + ": " + it.text }
            scroll.post { scroll.scrollTo(0, 1_000_000) }
        }
        render()

        // ---- 입력 + 보내기 ----
        val input = EditText(ctx).apply {
            hint = "AI에게 말 걸기"
            setTextColor(fg)
            setHintTextColor(hintCol)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            maxLines = 4
            background = round(softCol, 12, lineCol)
            setPadding(px(10), px(8), px(10), px(8))
            setOnFocusChangeListener { _, has -> if (has) onFocus() }
            setOnClickListener { onFocus() }
        }
        fun send() {
            val t = input.text.toString().trim()
            if (t.isEmpty() || waiting) return
            input.setText("")
            ChatLog.add(app, "user", t)
            waiting = true
            render()
            status.text = "AI가 답을 쓰는 중이에요..."
            status.visibility = View.VISIBLE
            io.execute {
                var err: String? = null
                try {
                    val raw = Ai.ask(ChatLog.load(app), Cfg.chatOpts(app))
                    val ans = Ai.clean(raw.replace("[SKIP]", ""), Cfg.noEmoji(app))
                    if (ans.isEmpty()) err = "빈 답변이 왔어요. 다시 보내 주세요" else ChatLog.add(app, "bot", ans)
                } catch (e: Exception) {
                    err = "AI 실패: " + (e.message ?: e.toString()).take(100)
                    Bridge.log("패널 대화 $err")
                }
                ui.post {
                    waiting = false
                    render()
                    if (err != null) { status.text = err; status.visibility = View.VISIBLE } else status.visibility = View.GONE
                }
            }
        }
        val sendBtn = TextView(ctx).apply {
            text = "보내기"
            textSize = 15f
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
            setTextColor(base)
            background = round(fg, 12)
            setPadding(px(14), px(10), px(14), px(10))
            isClickable = true
            setOnClickListener { send() }
        }
        val row2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row2.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row2.addView(sendBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { leftMargin = px(8) })
        card.addView(row2, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(8) })

        // ---- 대화 지우기 (두 번 눌러야 지워짐) ----
        var armed = false
        val clr = pill("대화 지우기") { v ->
            if (!armed) {
                armed = true
                v.text = "정말 지울까요? 한 번 더"
                ui.postDelayed({ armed = false; v.text = "대화 지우기" }, 3000)
            } else {
                armed = false
                ChatLog.clear(app)
                v.text = "대화 지우기"
                status.visibility = View.GONE
                render()
            }
        }.apply {
            setTextColor(fg)
            background = round(Color.TRANSPARENT, 12, lineCol)
        }
        card.addView(clr, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(8) })
        return card
    }
}
