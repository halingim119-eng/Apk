package com.hyewon.bot

import android.content.Context
import android.content.SharedPreferences

object Cfg {
    fun p(c: Context): SharedPreferences = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    fun target(c: Context): String = p(c).getString("target", "혜원씌") ?: "혜원씌"
    fun model(c: Context): String = p(c).getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash"
    fun enabled(c: Context): Boolean = p(c).getBoolean("enabled", true)
    fun keysRaw(c: Context): String = p(c).getString("keys", "") ?: ""
    fun keys(c: Context): List<String> =
        keysRaw(c).split("\n", ",", " ").map { it.trim() }.filter { it.isNotEmpty() }
}
