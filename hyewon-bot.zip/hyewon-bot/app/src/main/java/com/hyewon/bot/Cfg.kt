package com.hyewon.bot

import android.content.Context
import android.graphics.Color
import android.content.SharedPreferences

object Cfg {
    // 코드를 고칠 때마다 이 값을 새로 바꿈 -> 앱을 열면 "업데이트 됐어요!" 화면이 한 번 뜸
    const val UPDATE_SIGNAL = "U1020-SISAARI-AI"
    const val UPDATE_NOTES =
        "- AI를 시사아리 AI(실시간 스트리밍)로 교체 (API 키는 앱에 기본으로 들어 있어요)\n" +
        "- /cmds 패널에 '반응으로 AI답변하기' 추가: 내가 메시지에 반응(공감/이모지)하면 그 메시지에 AI가 답장\n" +
        "- /cmds 패널에 '모든 메세지 자동답변' 추가: 새 메시지가 오면 실시간으로 감지해서 AI가 답장 (카톡이 백그라운드여도 알림으로 답장)"

    const val DEFAULT_PROMPT =
        "너는 카카오톡으로 대화하는 차분하고 똑똑한 친구야.\n" +
        "- 상대 말의 맥락과 이전 대화를 꼼꼼히 읽고, 질문이면 정확하고 구체적으로 답해.\n" +
        "- 항상 완성된 문장으로 답하고, 문장을 중간에 끊지 마.\n" +
        "- 말투는 담백하고 자연스럽게. 과장, 호들갑, 감탄사 남발, 지나친 공감 표현은 하지 마.\n" +
        "- 보통 2~3문장으로 답하고, 길게 설명해달라고 할 때만 길게.\n" +
        "- 이모지와 이모티콘은 쓰지 마. ㅋㅋ, ㅎㅎ도 상대가 쓸 때만 가끔.\n" +
        "- 모르는 건 아는 척하지 말고 모른다고 해."

    const val SKIP_RULE =
        "\n- 'ㅋㅋ', 'ㅇㅇ', '응', '그래' 같은 단순 맞장구나 대화가 끝난 말에는 답할 필요가 없어.\n" +
        "  이럴 때는 다른 말 없이 정확히 [SKIP] 만 출력해."

    fun p(c: Context): SharedPreferences = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    private fun str(c: Context, k: String, d: String): String = p(c).getString(k, d) ?: d
    private fun bool(c: Context, k: String, d: Boolean): Boolean = p(c).getBoolean(k, d)
    private fun splitLines(s: String): List<String> =
        s.split("\n", ",", ";").map { it.trim() }.filter { it.isNotEmpty() }

    fun enabled(c: Context) = bool(c, "enabled", true)
    fun everyone(c: Context) = bool(c, "everyone", false)
    fun namesRaw(c: Context): String {
        val sp = p(c)
        return sp.getString("names", null) ?: sp.getString("target", null) ?: "혜원씌"
    }
    fun names(c: Context) = splitLines(namesRaw(c)).map { it.removePrefix("@").trim() }.filter { it.isNotEmpty() }

    /** 카톡 알림/화면에서 자동으로 모은 이름들 (사람 + 방), 최근 것이 앞 */
    fun known(c: Context): List<String> = str(c, "known", "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    @Synchronized fun addKnown(c: Context, vararg ns: String) {
        val cur = LinkedHashSet<String>()
        for (n in ns) { val t = n.trim(); if (t.length in 1..40) cur.add(t) }
        if (cur.isEmpty()) return
        val old = known(c)
        if (old.take(cur.size).containsAll(cur)) return
        for (o in old) cur.add(o)
        p(c).edit().putString("known", cur.take(200).joinToString("\n")).apply()
    }
    fun blocksRaw(c: Context) = str(c, "blocks", "")
    fun blocks(c: Context) = splitLines(blocksRaw(c))
    // 예전 Gemini 설정이 저장돼 있어도 시사아리 AI 값으로 취급
    fun model(c: Context): String {
        val m = str(c, "model", Ai.DEFAULT_MODEL).trim()
        return if (m.isEmpty() || m.startsWith("gemini", true)) Ai.DEFAULT_MODEL else m
    }
    fun keysRaw(c: Context): String {
        val k = str(c, "keys", "")
        return if (keysOf(k).isEmpty()) Ai.DEFAULT_KEY else k
    }
    private fun keysOf(raw: String): List<String> =
        raw.split("\n", ",", " ").map { it.trim() }.filter { it.startsWith("sisaari_") }
    fun keys(c: Context): List<String> = keysOf(keysRaw(c)).ifEmpty { listOf(Ai.DEFAULT_KEY) }

    /** /cmds 패널의 '반응으로 AI답변하기' */
    fun reactAi(c: Context) = bool(c, "reactAi", false)

    fun prompt(c: Context) = str(c, "prompt", DEFAULT_PROMPT).ifBlank { DEFAULT_PROMPT }
    fun skipRule(c: Context) = bool(c, "skipRule", true)
    fun noEmoji(c: Context) = bool(c, "noEmoji", true)
    fun autoSend(c: Context) = bool(c, "autoSend", true)
    fun viaScript(c: Context) = bool(c, "viaScript", true)
    fun autoColor(c: Context) = bool(c, "autoColor", true)
    fun userName(c: Context) = str(c, "userName", "사용자").ifBlank { "사용자" }
    fun awayOn(c: Context) = bool(c, "awayOn", false)
    fun awayGroup(c: Context) = bool(c, "awayGroup", false)
    fun awayR1Raw(c: Context) = str(c, "awayR1", "조금 기다려주세요, 바로 갈게요.")
    fun awayR2Raw(c: Context) = str(c, "awayR2", "잠시만요, 몇 분 정도 걸려요.")
    fun awayR1(c: Context) = awayR1Raw(c).ifBlank { "조금 기다려주세요, 바로 갈게요." }
    fun awayR2(c: Context) = awayR2Raw(c).ifBlank { "잠시만요, 몇 분 정도 걸려요." }
    fun awayGames(c: Context): Set<String> = HashSet(p(c).getStringSet("awayGames", emptySet()) ?: emptySet())
    fun setAwayGames(c: Context, g: Set<String>) { p(c).edit().putStringSet("awayGames", HashSet(g)).apply() }
    fun repSecRaw(c: Context) = str(c, "repSec", "5")
    fun repCountRaw(c: Context) = str(c, "repCount", "")
    fun mentionRaw(c: Context) = str(c, "mention", "")

    fun tempRaw(c: Context) = str(c, "temp", "0.4")
    fun maxTokensRaw(c: Context) = str(c, "maxTokens", "2048")
    fun contextRaw(c: Context) = str(c, "context", "20")
    // 예전 기본값(3)이 저장돼 있어도 새 기본값(1)으로 취급
    fun waitRaw(c: Context): String { val v = str(c, "waitSec", "1").trim(); return if (v == "3" || v.isEmpty()) "1" else v }

    fun cmdWord(c: Context) = str(c, "cmd", "/cmds").trim()
    fun themeRaw(c: Context) = str(c, "theme", "#6C5CE7")
    fun themeDark(c: Context) = bool(c, "themeDark", false)
    fun themeColor(c: Context): Int {
        val s = themeRaw(c).trim()
        return try { Color.parseColor(if (s.startsWith("#")) s else "#$s") }
        catch (e: Exception) { Color.parseColor("#6C5CE7") }
    }

    fun waitMs(c: Context): Long =
        ((waitRaw(c).toDoubleOrNull() ?: 1.0).coerceIn(0.0, 30.0) * 1000).toLong()

    fun opts(c: Context): Opts = Opts(
        system = prompt(c) + if (skipRule(c)) SKIP_RULE else "",
        temperature = (tempRaw(c).toDoubleOrNull() ?: 0.4).coerceIn(0.0, 2.0),
        maxTokens = (maxTokensRaw(c).toIntOrNull() ?: 2048).coerceIn(100, 8192),
        context = (contextRaw(c).toIntOrNull() ?: 20).coerceIn(1, 100)
    )
}
