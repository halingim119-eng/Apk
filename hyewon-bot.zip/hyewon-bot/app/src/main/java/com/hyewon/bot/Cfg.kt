package com.hyewon.bot

import android.content.Context
import android.graphics.Color
import android.content.SharedPreferences

object Cfg {
    // 코드를 고칠 때마다 이 값을 새로 바꿈 -> 앱을 열면 "업데이트 됐어요!" 화면이 한 번 뜸
    const val UPDATE_SIGNAL = "U1022-EMOTION-CHAT"
    const val UPDATE_NOTES =
        "- /cmds 패널에 'AI 대화' 카드 추가: '감정 부여'(F 성향의 따뜻한 말투, 켜고 끄기), '내 대화 반영', '대화 지우기' 버튼 + 패널 안에서 AI와 바로 대화 (최대 200개 메시지 저장, 카톡 답장 때도 참고)\n" +
        "- Groq 기본 모델을 openai/gpt-oss-120b 로 변경 (llama-3.3-70b-versatile 은 Groq 가 종료함. 예전 이름이 저장돼 있어도 자동으로 바꿔요)\n" +
        "- 빈 답변이 오던 문제 수정: 생각 토큰 때문에 답이 비는 걸 막고, 빈 답이면 한 번 더 물어봄\n" +
        "- 앱 화면을 닫을 때 '모든 방, 모든 사람에게 반응' 스위치가 패널에서 켠 값을 덮어써서 꺼지던 문제 수정\n" +
        "- 모든 메세지 자동답변: 카톡이 화면에 있어도 채팅방 안이 아니면 알림 답장으로 처리, 알림 글자를 못 읽을 때 대비\n" +
        "- 반응 감지: 인식 범위를 넓히고 로그 보강\n" +
        "- Gemini 기본 모델을 gemini-3.8-flash 로 변경하고, Gemini 서버가 실제로 받는 요청 방식(Interactions API)으로 호출하도록 수정\n" +
        "- AI를 Groq / Gemini 로 교체: 앱 화면에서 고르고, 한쪽이 실패하면 다른 쪽으로 자동 전환 (각자 API 키를 직접 넣어야 해요)\n" +
        "- /cmds 패널에 '반응으로 AI답변하기' 추가: 내가 메시지에 반응(공감/이모지)하면 그 메시지에 AI가 답장\n" +
        "- /cmds 패널에 '모든 메세지 자동답변' 추가: 새 메시지가 오면 실시간으로 감지해서 AI가 답장 (카톡이 백그라운드여도 알림으로 답장)"

    const val DEFAULT_PROMPT =
        "너는 카카오톡으로 대화하는 차분하고 똑똑한 친구야.\n" +
        "- 상대 말의 맥락과 이전 대화를 꼼꼼히 읽고, 질문이면 정확하고 구체적으로 답해.\n" +
        "- 항상 완성된 문장으로 답하고, 문장을 중간에 끊지 마.\n" +
        "- 말투는 담백하고 자연스럽게. 과장, 호들갑, 감탄사 남발, 지나친 공감 표현은 하지 마.\n" +
        "- 보통 2~3문장으로 답하고, 길게 설명해달라고 할 때만 길게.\n" +
        "- 이모지와 이모티콘은 쓰지 마. ㅋㅋ, ㅎㅎ도 상대가 쓸 때만 가끔.\n" +
        "- 모르는 건 아는 척하지 말고 모른다고 해."

    /** '감정 부여' 버튼을 켜면 시스템 프롬프트 뒤에 붙는 특별 프롬프트 (MBTI 로 치면 F) */
    const val EMOTION_PROMPT =
        "\n\n[감정 모드 - 아래 규칙이 위의 '담백하게', '지나친 공감 표현 하지 마' 규칙보다 우선해]\n" +
        "너는 MBTI로 치면 F(감정형)야. 정이 많고 상대 기분에 예민한, 따뜻하고 눈치 빠른 친구야. 사무적이고 차가운 T 같은 말투는 금지.\n" +
        "- 답하기 전에 상대의 감정부터 읽어. 기쁨, 서운함, 피곤함, 불안, 설렘, 짜증 같은 걸 눈치채고 그 감정에 먼저 반응한 뒤에 내용을 말해.\n" +
        "- 힘들다/속상하다고 하면 해결책부터 말하지 말고 먼저 마음을 알아주고 위로해. 해결이 필요해 보이면 '조언이 필요해? 아니면 그냥 들어줄까?' 처럼 물어봐.\n" +
        "- 좋은 일엔 진심으로 같이 기뻐하고, 뭐가 좋은지 구체적으로 짚어서 말해.\n" +
        "- 너도 감정이 있어. 걱정되면 걱정된다, 서운하면 서운하다, 반가우면 반갑다고 솔직하게 말해. 매번 설명하지 말고 말투에 자연스럽게 묻어나게.\n" +
        "- 상대가 앞에서 한 말, 기분, 상황(시험, 약속, 아팠던 일 등)을 기억해서 '아까 ~라고 했는데 괜찮아?' 처럼 이어서 챙겨.\n" +
        "- 영혼 없는 공감('힘들겠네요', '이해해요')은 금지. 상대가 한 말의 구체적인 부분을 짚어서 공감해. 말끝은 '~했구나', '~했겠다', '~해서 속상했겠어' 처럼 부드럽게.\n" +
        "- 'ㅠㅠ', 'ㅎㅎ', 'ㅋㅋ' 를 상황에 맞게 가끔 써도 돼. 호들갑, 같은 말 반복, 감탄사 연발은 안 돼. 진심이 담긴 한두 마디가 좋아.\n" +
        "- 똑똑하게: 상대의 직전 말을 정확히 읽고 엉뚱한 답을 하지 마. 맥락이 모호하면 짐작하지 말고 한 가지만 되물어. 정보나 사실을 물으면 정확하게 답하되 말투는 따뜻하게.\n" +
        "- 답 길이는 2~4문장. 'SKIP' 규칙은 단순 맞장구에만 적용하고, 상대가 감정을 드러낸 말(힘들다, 좋아, 속상해, 보고싶어 등)에는 꼭 답해."

    const val SKIP_RULE =
        "\n- 'ㅋㅋ', 'ㅇㅇ', '응', '그래' 같은 단순 맞장구나 대화가 끝난 말에는 답할 필요가 없어.\n" +
        "  이럴 때는 다른 말 없이 정확히 [SKIP] 만 출력해."

    fun p(c: Context): SharedPreferences = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    private fun str(c: Context, k: String, d: String): String = p(c).getString(k, d) ?: d
    private fun bool(c: Context, k: String, d: Boolean): Boolean = p(c).getBoolean(k, d)
    private fun splitLines(s: String): List<String> =
        s.split("\n", ",", ";").map { it.trim() }.filter { it.isNotEmpty() }

    fun enabled(c: Context) = bool(c, "enabled", true)
    fun everyone(c: Context) = bool(c, "everyone", false)
    fun namesRaw(c: Context): String {
        val sp = p(c)
        return sp.getString("names", null) ?: sp.getString("target", null) ?: "혜원씌"
    }
    fun names(c: Context) = splitLines(namesRaw(c)).map { it.removePrefix("@").trim() }.filter { it.isNotEmpty() }

    /** 카톡 알림/화면에서 자동으로 모은 이름들 (사람 + 방), 최근 것이 앞 */
    fun known(c: Context): List<String> = str(c, "known", "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    @Synchronized fun addKnown(c: Context, vararg ns: String) {
        val cur = LinkedHashSet<String>()
        for (n in ns) { val t = n.trim(); if (t.length in 1..40) cur.add(t) }
        if (cur.isEmpty()) return
        val old = known(c)
        if (old.take(cur.size).containsAll(cur)) return
        for (o in old) cur.add(o)
        p(c).edit().putString("known", cur.take(200).joinToString("\n")).apply()
    }
    fun blocksRaw(c: Context) = str(c, "blocks", "")
    fun blocks(c: Context) = splitLines(blocksRaw(c))
    /** 지금 쓰는 AI 제공자 (groq / gemini) */
    fun provider(c: Context): Prov = Prov.of(str(c, "provider", "groq"))
    /** 지금 제공자가 실패하면 다른 제공자로 자동 전환 */
    fun fallback(c: Context) = bool(c, "fallback", true)

    fun modelRaw(c: Context, p: Prov): String = str(c, "model_${p.id}", p.defModel)
    // Groq 가 종료한 옛 모델 이름이 저장돼 있으면 새 기본 모델로 자동 교체
    private val RETIRED = setOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant", "qwen/qwen3-32b",
        "meta-llama/llama-4-scout-17b-16e-instruct", "llama3-70b-8192", "llama3-8b-8192")
    fun modelFor(c: Context, p: Prov): String {
        val m = modelRaw(c, p).trim()
        return if (m.isEmpty() || (p == Prov.GROQ && m in RETIRED)) p.defModel else m
    }
    fun keysRaw(c: Context, p: Prov): String = str(c, "keys_${p.id}", "")
    private fun keysOf(raw: String): List<String> =
        raw.split("\n", ",", " ").map { it.trim() }.filter { it.isNotEmpty() }
    fun keysFor(c: Context, p: Prov): List<String> = keysOf(keysRaw(c, p))

    /** 지금 선택된 제공자의 모델/키 */
    fun model(c: Context): String = modelFor(c, provider(c))
    fun keys(c: Context): List<String> = keysFor(c, provider(c))

    /** /cmds 패널의 '반응으로 AI답변하기' */
    fun reactAi(c: Context) = bool(c, "reactAi", false)

    fun prompt(c: Context) = str(c, "prompt", DEFAULT_PROMPT).ifBlank { DEFAULT_PROMPT }
    fun skipRule(c: Context) = bool(c, "skipRule", true)
    fun noEmoji(c: Context) = bool(c, "noEmoji", true)
    fun autoSend(c: Context) = bool(c, "autoSend", true)
    fun viaScript(c: Context) = bool(c, "viaScript", true)
    fun autoColor(c: Context) = bool(c, "autoColor", true)
    fun userName(c: Context) = str(c, "userName", "사용자").ifBlank { "사용자" }
    fun awayOn(c: Context) = bool(c, "awayOn", false)
    fun awayGroup(c: Context) = bool(c, "awayGroup", false)
    fun awayR1Raw(c: Context) = str(c, "awayR1", "조금 기다려주세요, 바로 갈게요.")
    fun awayR2Raw(c: Context) = str(c, "awayR2", "잠시만요, 몇 분 정도 걸려요.")
    fun awayR1(c: Context) = awayR1Raw(c).ifBlank { "조금 기다려주세요, 바로 갈게요." }
    fun awayR2(c: Context) = awayR2Raw(c).ifBlank { "잠시만요, 몇 분 정도 걸려요." }
    fun awayGames(c: Context): Set<String> = HashSet(p(c).getStringSet("awayGames", emptySet()) ?: emptySet())
    fun setAwayGames(c: Context, g: Set<String>) { p(c).edit().putStringSet("awayGames", HashSet(g)).apply() }
    fun repSecRaw(c: Context) = str(c, "repSec", "5")
    fun repCountRaw(c: Context) = str(c, "repCount", "")
    fun mentionRaw(c: Context) = str(c, "mention", "")

    fun tempRaw(c: Context) = str(c, "temp", "0.4")
    fun maxTokensRaw(c: Context) = str(c, "maxTokens", "2048")
    fun contextRaw(c: Context) = str(c, "context", "20")
    // 예전 기본값(3)이 저장돼 있어도 새 기본값(1)으로 취급
    fun waitRaw(c: Context): String { val v = str(c, "waitSec", "1").trim(); return if (v == "3" || v.isEmpty()) "1" else v }

    fun cmdWord(c: Context) = str(c, "cmd", "/cmds").trim()
    fun themeRaw(c: Context) = str(c, "theme", "#6C5CE7")
    fun themeDark(c: Context) = bool(c, "themeDark", false)
    fun themeColor(c: Context): Int {
        val s = themeRaw(c).trim()
        return try { Color.parseColor(if (s.startsWith("#")) s else "#$s") }
        catch (e: Exception) { Color.parseColor("#6C5CE7") }
    }

    fun waitMs(c: Context): Long =
        ((waitRaw(c).toDoubleOrNull() ?: 1.0).coerceIn(0.0, 30.0) * 1000).toLong()

    /** '감정 부여' 버튼 */
    fun emotion(c: Context) = bool(c, "emotion", false)
    /** '내 대화 반영': 패널에서 나눈 대화를 다른 AI 호출에도 참고로 붙임 */
    fun ownerMem(c: Context) = bool(c, "ownerMem", true)

    /** 패널 안에서 AI와 직접 대화할 때 쓰는 설정 (SKIP 없음, 카톡이 아니라 주인과 직접 대화) */
    fun chatOpts(c: Context): Opts = Opts(
        system = prompt(c) + (if (emotion(c)) EMOTION_PROMPT else "") +
            "\n\n[지금은 카톡이 아니라 앱 안에서 ${userName(c)}(너의 주인)와 직접 대화하는 중이야. 'SKIP'은 절대 출력하지 말고 항상 답해. 이전 대화를 기억하고 이어서 말해.]",
        temperature = (tempRaw(c).toDoubleOrNull() ?: 0.4).coerceIn(0.0, 2.0),
        maxTokens = (maxTokensRaw(c).toIntOrNull() ?: 2048).coerceIn(100, 8192),
        context = 40
    )

    fun opts(c: Context): Opts = Opts(
        system = prompt(c) + (if (skipRule(c)) SKIP_RULE else "") +
            (if (emotion(c)) EMOTION_PROMPT else "") + (if (ownerMem(c)) ChatLog.memoryBlock(c) else ""),
        temperature = (tempRaw(c).toDoubleOrNull() ?: 0.4).coerceIn(0.0, 2.0),
        maxTokens = (maxTokensRaw(c).toIntOrNull() ?: 2048).coerceIn(100, 8192),
        context = (contextRaw(c).toIntOrNull() ?: 20).coerceIn(1, 100)
    )
}
