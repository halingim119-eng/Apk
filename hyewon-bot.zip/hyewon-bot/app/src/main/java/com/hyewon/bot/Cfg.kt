package com.hyewon.bot

import android.content.Context
import android.graphics.Color
import android.content.SharedPreferences

object Cfg {
    // 코드를 고칠 때마다 이 값을 새로 바꿈 -> 앱을 열면 "업데이트 됐어요!" 화면이 한 번 뜸
    const val UPDATE_SIGNAL = "U1019-F3M9X"
    const val UPDATE_NOTES =
        "- 서명 고정: 지우고 다시 깔지 않고 바로 덮어 설치\n" +
        "- 메시지를 입력창 대신 알림 답장(스크립트)으로 전송\n" +
        "- /cmds 입력 즉시 감지\n" +
        "- 패널 색을 카톡 입력창 색에서 자동 감지, 한 색 계열로 통일\n" +
        "- 패널에서 초 단위 반복 전송"

    const val DEFAULT_PROMPT =
        "너는 카카오톡으로 대화하는 차분하고 똑똑한 친구야.\n" +
        "- 상대 말의 맥락과 이전 대화를 꼼꼼히 읽고, 질문이면 정확하고 구체적으로 답해.\n" +
        "- 항상 완성된 문장으로 답하고, 문장을 중간에 끊지 마.\n" +
        "- 말투는 담백하고 자연스럽게. 과장, 호들갑, 감탄사 남발, 지나친 공감 표현은 하지 마.\n" +
        "- 보통 2~3문장으로 답하고, 길게 설명해달라고 할 때만 길게.\n" +
        "- 이모지와 이모티콘은 쓰지 마. ㅋㅋ, ㅎㅎ도 상대가 쓸 때만 가끔.\n" +
        "- 모르는 건 아는 척하지 말고 모른다고 해."

    const val SKIP_RULE =
        "\n- 'ㅋㅋ', 'ㅇㅇ', '응', '그래' 같은 단순 맞장구나 대화가 끝난 말에는 답할 필요가 없어.\n" +
        "  이럴 때는 다른 말 없이 정확히 [SKIP] 만 출력해."

    fun p(c: Context): SharedPreferences = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    private fun str(c: Context, k: String, d: String): String = p(c).getString(k, d) ?: d
    private fun bool(c: Context, k: String, d: Boolean): Boolean = p(c).getBoolean(k, d)
    private fun splitLines(s: String): List<String> =
        s.split("\n", ",").map { it.trim() }.filter { it.isNotEmpty() }

    fun enabled(c: Context) = bool(c, "enabled", true)
    fun everyone(c: Context) = bool(c, "everyone", false)
    fun namesRaw(c: Context): String {
        val sp = p(c)
        return sp.getString("names", null) ?: sp.getString("target", null) ?: "혜원씌"
    }
    fun names(c: Context) = splitLines(namesRaw(c))
    fun blocksRaw(c: Context) = str(c, "blocks", "")
    fun blocks(c: Context) = splitLines(blocksRaw(c))
    fun model(c: Context) = str(c, "model", "gemini-3.8-flash").ifBlank { "gemini-3.8-flash" }
    fun keysRaw(c: Context) = str(c, "keys", "")
    fun keys(c: Context): List<String> =
        keysRaw(c).split("\n", ",", " ").map { it.trim() }.filter { it.isNotEmpty() }

    fun prompt(c: Context) = str(c, "prompt", DEFAULT_PROMPT).ifBlank { DEFAULT_PROMPT }
    fun skipRule(c: Context) = bool(c, "skipRule", true)
    fun noEmoji(c: Context) = bool(c, "noEmoji", true)
    fun autoSend(c: Context) = bool(c, "autoSend", true)
    fun viaScript(c: Context) = bool(c, "viaScript", true)
    fun autoColor(c: Context) = bool(c, "autoColor", true)
    fun repSecRaw(c: Context) = str(c, "repSec", "5")
    fun repCountRaw(c: Context) = str(c, "repCount", "")

    fun tempRaw(c: Context) = str(c, "temp", "0.4")
    fun maxTokensRaw(c: Context) = str(c, "maxTokens", "2048")
    fun contextRaw(c: Context) = str(c, "context", "20")
    fun waitRaw(c: Context) = str(c, "waitSec", "3")

    fun cmdWord(c: Context) = str(c, "cmd", "/cmds").trim()
    fun themeRaw(c: Context) = str(c, "theme", "#6C5CE7")
    fun themeDark(c: Context) = bool(c, "themeDark", false)
    fun themeColor(c: Context): Int {
        val s = themeRaw(c).trim()
        return try { Color.parseColor(if (s.startsWith("#")) s else "#$s") }
        catch (e: Exception) { Color.parseColor("#6C5CE7") }
    }

    fun waitMs(c: Context): Long =
        ((waitRaw(c).toDoubleOrNull() ?: 3.0).coerceIn(0.0, 30.0) * 1000).toLong()

    fun opts(c: Context): Opts = Opts(
        system = prompt(c) + if (skipRule(c)) SKIP_RULE else "",
        temperature = (tempRaw(c).toDoubleOrNull() ?: 0.4).coerceIn(0.0, 2.0),
        maxTokens = (maxTokensRaw(c).toIntOrNull() ?: 2048).coerceIn(100, 8192),
        context = (contextRaw(c).toIntOrNull() ?: 20).coerceIn(1, 100)
    )
}
