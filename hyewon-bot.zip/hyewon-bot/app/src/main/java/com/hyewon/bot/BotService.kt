package com.hyewon.bot

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.util.concurrent.Executors

class BotService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val scanTask = Runnable { scan() }
    private val pollTask = object : Runnable {
        override fun run() {
            scan()
            handler.postDelayed(this, 1000) // 이벤트가 안 와도 1초마다 직접 확인
        }
    }
    private lateinit var history: History

    private var handledRun: List<String> = emptyList() // 이미 처리한(또는 기준으로 잡은) 상대 메시지들
    private var prevAll: List<String> = emptyList()    // 직전 화면의 모든 메시지 (방 이동 감지용)
    private var haveBaseline = false
    private var presentBefore = false
    private var stableSig = ""
    private var stableSince = 0L
    private var lastNote = ""
    private var panel: View? = null
    private var panelShown = false
    private var panelOpening = false
    private var cmdBubbleHandled = false
    @Volatile private var busy = false
    private val sent = ArrayList<String>()
    private val shotExec = Executors.newSingleThreadExecutor()

    // 입력창 색 (미리 떠 둔 값)
    private var cachedBase = 0
    private var cachedAt = 0L
    private var palBase = Color.WHITE
    private var palFg = Color.BLACK
    private var panelRoom: List<String> = emptyList()

    // 반복 전송
    private var repRunning = false
    private var repText = ""
    private var repEveryMs = 1000L
    private var repLeft = -1
    private var repCount = 0
    private var repFails = 0
    private var repRoom: List<String> = emptyList()
    private var chip: TextView? = null
    private val repTask = Runnable { doRepeatSend() }

    override fun onServiceConnected() {
        val base = getExternalFilesDir(null) ?: filesDir
        history = History(File(base, "hyewon"))
        Bridge.log("서비스 연결됨. 저장 위치: ${File(base, "hyewon").absolutePath}")
        handler.removeCallbacks(pollTask)
        handler.post(pollTask)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        stopRepeat(false)
        handler.removeCallbacksAndMessages(null)
        hidePanel()
        return super.onUnbind(intent)
    }

    private fun note(m: String) {
        if (m != lastNote) { lastNote = m; Bridge.log(m) }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() != "com.kakao.talk") return
        // 글자가 바뀌는 즉시 이벤트 글자만 보고 판단 (화면 전체를 읽지 않아서 아주 빠름)
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED && fastCmd(event)) return
        handler.removeCallbacks(scanTask)
        handler.postDelayed(scanTask, 800)
    }

    private fun fastCmd(event: AccessibilityEvent): Boolean {
        val cmd = Cfg.cmdWord(this)
        if (cmd.isEmpty()) return false
        val t = (event.text?.joinToString("") ?: "").trim()
        if (t.isEmpty()) return false
        val src = event.source
        if (t != cmd) {
            // "/" 를 치는 순간 입력창 색을 미리 떠 둠 (패널이 더 빨리 뜸)
            if (t.length < cmd.length && cmd.startsWith(t) && src != null && Cfg.autoColor(this) &&
                System.currentTimeMillis() - cachedAt > 8000) {
                val r = rect(src)
                sampleInputColor(r) { c -> if (c != null) { cachedBase = c; cachedAt = System.currentTimeMillis() } }
            }
            return false
        }
        if (panelShown || panelOpening) return true
        if (src == null || !src.isEditable) return false
        val r = rect(src)
        val a = Bundle()
        a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
        src.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)
        currentNodes()?.let { panelRoom = headerNames(it) }
        openPanelFast(r)
        return true
    }

    override fun onInterrupt() {}

    // ---------- 화면 읽기 도우미 ----------
    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, d: Int = 0) {
        if (n == null || d > 60) return
        out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, d + 1)
    }

    private fun idOf(n: AccessibilityNodeInfo) = n.viewIdResourceName ?: ""
    private fun txt(n: AccessibilityNodeInfo) = n.text?.toString()?.trim() ?: ""
    private fun rect(n: AccessibilityNodeInfo): Rect = Rect().also { n.getBoundsInScreen(it) }

    // 키보드가 떠서 활성 창이 키보드여도, 열려 있는 모든 창에서 카톡 창을 찾아냄
    private fun kakaoRoot(): AccessibilityNodeInfo? {
        val r = rootInActiveWindow
        if (r?.packageName?.toString() == "com.kakao.talk") return r
        try {
            for (w in windows) {
                val wr = w.root ?: continue
                if (wr.packageName?.toString() == "com.kakao.talk") return wr
            }
        } catch (e: Exception) { }
        return null
    }

    private fun currentNodes(): List<AccessibilityNodeInfo>? {
        val root = kakaoRoot() ?: return null
        val list = ArrayList<AccessibilityNodeInfo>()
        collect(root, list)
        return list
    }

    private fun findInput(nodes: List<AccessibilityNodeInfo>): AccessibilityNodeInfo? =
        nodes.firstOrNull { it.isEditable }
            ?: nodes.firstOrNull { it.className?.toString()?.endsWith("EditText") == true }

    /** 화면 위쪽(방 이름이 있는 곳)의 글자들. 알림 답장 세션을 찾을 때 씀 */
    private fun headerNames(nodes: List<AccessibilityNodeInfo>): List<String> {
        val h = resources.displayMetrics.heightPixels
        val out = LinkedHashSet<String>()
        for (n in nodes) {
            if (n.isEditable) continue
            val r = rect(n)
            if (r.top < 0 || r.top > h * 0.2) continue
            val t = txt(n); if (t.isNotEmpty()) out.add(t)
            val d = n.contentDescription?.toString()?.trim() ?: ""; if (d.isNotEmpty()) out.add(d)
        }
        return out.toList()
    }

    /** 이미 처리한 메시지(handled)와 겹치는 앞부분을 빼고 새로 온 것만 돌려줌 (화면이 스크롤돼도 안전) */
    private fun freshOf(run: List<String>, handled: List<String>): List<String> {
        val max = minOf(run.size, handled.size)
        for (k in max downTo 1) {
            if (handled.subList(handled.size - k, handled.size) == run.subList(0, k)) return run.drop(k)
        }
        return run
    }

    // ---------- 새 메시지 확인 ----------
    private fun scan() {
        if (busy) return
        val nodes = currentNodes()
        if (nodes == null) { note("카톡 화면이 안 보여요 (카톡을 열어 주세요)"); return }
        if (Bridge.dumpRequested) {
            Bridge.dumpRequested = false
            dump(nodes)
        }

        val input = findInput(nodes)
        if (input == null) { note("카톡은 보이는데 채팅방 입력창이 없어요 (채팅방 안에 들어가 주세요)"); return }

        // ---- 명령어 (예: /cmds): 입력창에 치면 입력창을 비우고 패널을 띄움 ----
        val cmd = Cfg.cmdWord(this)
        val typed = input.text?.toString()?.trim() ?: ""
        if (!panelShown && !panelOpening && cmd.isNotEmpty() && typed == cmd) {
            val r = rect(input)
            val a = Bundle()
            a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
            input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)
            panelRoom = headerNames(nodes)
            openPanelFast(r)
            return
        }

        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        val inputTop = rect(input).top

        val byId = nodes.filter { idOf(it).endsWith("/message") && txt(it).isNotEmpty() }
        val msgNodes = if (byId.isNotEmpty()) byId else nodes.filter {
            val r = rect(it)
            it.className?.toString()?.endsWith("TextView") == true && !it.isEditable &&
                txt(it).isNotEmpty() && r.top > h * 0.12 && r.bottom < inputTop
        }
        // 위 → 아래 순서로 정렬해서 (글자, 내가 보낸 것인지) 목록 만들기
        val ordered = msgNodes.sortedBy { rect(it).top }.map {
            val r = rect(it)
            val own = (r.left + r.right) / 2 > w * 0.56 // 오른쪽에 붙은 말풍선 = 내가 보낸 것
            val t = txt(it)
            Pair(t, own || sent.contains(t))
        }

        // 이미 보내버린 "/cmds" 말풍선도 인식 (한 번만)
        val lastBubble = ordered.lastOrNull()
        if (lastBubble != null && lastBubble.first == cmd && lastBubble.second) {
            if (!cmdBubbleHandled && !panelShown && !panelOpening && cmd.isNotEmpty()) {
                cmdBubbleHandled = true
                panelRoom = headerNames(nodes)
                openPanelFast(rect(input))
                return
            }
        } else cmdBubbleHandled = false

        if (panelShown) return              // 패널이 열려 있는 동안 자동 답장은 쉼
        if (!Cfg.enabled(this)) return

        // 화면에 보이는 모든 글자 (방 이름/상대 이름 확인용)
        val screen = ArrayList<String>()
        for (n in nodes) {
            if (n.isEditable) continue
            val t = txt(n); if (t.isNotEmpty()) screen.add(t)
            val d = n.contentDescription?.toString()?.trim() ?: ""; if (d.isNotEmpty()) screen.add(d)
        }
        val everyone = Cfg.everyone(this)
        val names = Cfg.names(this)
        val present = everyone || names.any { nm -> screen.any { it.contains(nm) } }
        val blocked = Cfg.blocks(this).any { nm -> screen.any { it.contains(nm) } }

        if (ordered.isEmpty()) return

        // 맨 아래에서부터, 내가 보낸 말풍선이 나올 때까지 이어진 상대 메시지 전부
        val run = ArrayList<String>()
        for (i in ordered.indices.reversed()) {
            if (ordered[i].second) break
            run.add(0, ordered[i].first)
        }

        // 다른 채팅방으로 옮겨갔는지 확인: 직전 화면과 겹치는 메시지가 하나도 없으면 방이 바뀐 것
        val allTexts = ordered.map { it.first }
        val overlap = prevAll.isEmpty() || allTexts.any { prevAll.contains(it) }
        prevAll = allTexts
        if (!overlap) {
            handledRun = run
            haveBaseline = true
            stableSig = ""
            Bridge.log("채팅방이 바뀐 것 같아요. 기존 메시지는 기준으로만 잡았어요")
            return
        }

        val wasPresent = presentBefore
        presentBefore = present && !blocked
        if (!present) { note("반응 대상 이름/방이 화면에 없어요 (설정 확인)"); return }
        if (blocked) { note("제외 대상이라 건너뛰어요"); return }
        note("채팅방 감지됨")

        if (!wasPresent || !haveBaseline) { // 처음 보는 상태: 기준만 잡고 답하지 않음
            handledRun = run
            haveBaseline = true
            stableSig = ""
            Bridge.log("기준 설정 (기존 상대 메시지 ${run.size}개)")
            return
        }
        if (run.isEmpty()) { // 마지막이 내 말풍선 → 다음 대화를 새로 시작
            handledRun = emptyList()
            stableSig = ""
            return
        }
        val fresh = freshOf(run, handledRun)
        if (fresh.isEmpty()) { stableSig = ""; return }

        // 상대가 연달아 보내는 중일 수 있어서, 설정한 시간 동안 내용이 안 바뀔 때까지 기다림
        val now = System.currentTimeMillis()
        val sig = fresh.joinToString("\u0001")
        if (sig != stableSig) { stableSig = sig; stableSince = now; return }
        if (now - stableSince < Cfg.waitMs(this)) return
        stableSig = ""
        handledRun = run

        val text = fresh.joinToString("\n")
        val keys = Cfg.keys(this)
        val model = Cfg.model(this)
        val opts = Cfg.opts(this)
        val noEmoji = Cfg.noEmoji(this)
        Bridge.log("새 메시지 ${fresh.size}개: ${text.replace("\n", " / ").take(400)}  (키 ${keys.size}개)")
        busy = true
        worker.execute {
            try {
                history.add("user", text)
                val raw = Gemini.ask(keys, model, history.load(), opts)
                val answer = Gemini.clean(raw, noEmoji)
                if (raw.contains("[SKIP]") || answer.isEmpty()) {
                    Bridge.log("답하지 않음")
                    handler.post { finish() }
                } else {
                    history.add("bot", answer)
                    handler.post { reply(answer) }
                }
            } catch (e: Exception) {
                Bridge.log("AI 실패: ${e.message}")
                handler.post { finish() }
            }
        }
    }

    private fun finish() {
        busy = false
        handler.postDelayed(scanTask, 1000)
    }

    private fun rememberSent(t: String) {
        sent.add(t)
        while (sent.size > 10) sent.removeAt(0)
    }

    // ---------- 전송 (알림 답장 스크립트 우선, 안 되면 입력창) ----------
    /** names: 이 메시지를 보낼 방의 이름 후보 (화면 위쪽 글자). strictRoom: 입력창 방식일 때 방이 같은지 확인할 후보 */
    private fun sendText(text: String, names: List<String>, strictRoom: List<String>?, cb: (Boolean) -> Unit) {
        if (Cfg.viaScript(this) && Replier.send(this, names, text)) {
            rememberSent(text)
            Bridge.log("스크립트 전송: ${text.replace("\n", " / ").take(400)}")
            cb(true)
            return
        }
        if (Cfg.viaScript(this)) {
            Bridge.log("이 방은 알림 답장이 아직 준비 안 됨 -> 입력창 방식으로 전송 (방에서 알림이 한 번 오면 준비돼요)")
        }
        sendViaInput(text, strictRoom, cb)
    }

    private fun sendViaInput(text: String, strictRoom: List<String>?, cb: (Boolean) -> Unit) {
        busy = true
        handler.postDelayed({
            val nodes = currentNodes()
            val input = if (nodes == null) null else findInput(nodes)
            if (input == null) {
                Bridge.log("전송 실패: 카톡 입력창을 못 찾음 (채팅방이 닫힘?)")
                cb(false)
                return@postDelayed
            }
            if (strictRoom != null && strictRoom.isNotEmpty() &&
                headerNames(nodes!!).none { strictRoom.contains(it) }) {
                Bridge.log("전송 건너뜀: 처음 시작한 채팅방이 아니에요")
                cb(false)
                return@postDelayed
            }
            input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) Bridge.log("입력창에 글자 넣기 실패")
            handler.postDelayed({ clickSend(text, cb) }, 350)
        }, 150)
    }

    private fun clickSend(text: String, cb: (Boolean) -> Unit) {
        val nodes = currentNodes()
        val btn = nodes?.firstOrNull {
            idOf(it).endsWith("/send") ||
                it.contentDescription?.toString() == "전송" || txt(it) == "전송"
        }
        var done = false
        var n: AccessibilityNodeInfo? = btn
        while (n != null && !done) {
            if (n.isClickable) done = n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        if (done) {
            rememberSent(text)
            Bridge.log("입력창 방식 전송: ${text.replace("\n", " / ").take(400)}")
        } else {
            Bridge.log("전송 버튼을 못 찾음 (구조 덤프를 보내 주세요)")
        }
        cb(done)
    }

    // ---------- 자동 답장 ----------
    private fun reply(answer: String) {
        if (!Cfg.autoSend(this)) {
            // 자동 전송이 꺼져 있으면 입력창에 적어두기만 함
            val nodes = currentNodes()
            val input = if (nodes == null) null else findInput(nodes)
            if (input != null) {
                val args = Bundle()
                args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, answer)
                input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            }
            Bridge.log("입력창에만 입력함 (자동 전송 꺼짐): ${answer.take(400)}")
            finish()
            return
        }
        val nodes = currentNodes()
        val names = if (nodes == null) emptyList() else headerNames(nodes)
        sendText(answer, names, null) { finish() }
    }

    /** 패널에서 한 번 보내기 */
    private fun sendFromPanel(text: String) {
        if (text.isEmpty()) return
        busy = true
        val names = currentNodes()?.let { headerNames(it) }?.ifEmpty { null } ?: panelRoom
        sendText(text, names, null) { finish() }
    }

    // ---------- 반복 전송 ----------
    private fun startRepeat(text: String, sec: Double, count: Int) {
        stopRepeat(false)
        if (text.isEmpty()) return
        repRunning = true
        repText = text
        repEveryMs = (sec.coerceIn(1.0, 86400.0) * 1000).toLong()
        repLeft = if (count > 0) count else -1
        repCount = 0
        repFails = 0
        repRoom = currentNodes()?.let { headerNames(it) }?.ifEmpty { null } ?: panelRoom
        Bridge.log("반복 시작: ${repEveryMs / 1000.0}초마다" + (if (repLeft > 0) " ${repLeft}회" else " 무한") + " / 방 ${repRoom.take(3)}")
        showChip()
        handler.post(repTask)
    }

    private fun doRepeatSend() {
        if (!repRunning) return
        if (busy) { handler.postDelayed(repTask, 400); return }
        sendText(repText, repRoom, repRoom) { ok ->
            busy = false
            if (!repRunning) return@sendText
            if (ok) { repCount++; repFails = 0 } else repFails++
            updateChip()
            if (repLeft > 0 && repCount >= repLeft) { Bridge.log("반복 끝 (${repCount}회)"); stopRepeat(false); return@sendText }
            if (repFails >= 5) { Bridge.log("반복 중지: 연속 5번 전송 실패"); stopRepeat(false); return@sendText }
            handler.postDelayed(repTask, repEveryMs)
        }
    }

    private fun stopRepeat(log: Boolean) {
        val was = repRunning
        repRunning = false
        handler.removeCallbacks(repTask)
        hideChip()
        if (was && log) Bridge.log("반복 중지 (${repCount}회 보냄)")
    }

    private fun showChip() {
        hideChip()
        val dp = resources.displayMetrics.density
        val tv = TextView(this).apply {
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(palBase)
            setPadding((14 * dp).toInt(), (9 * dp).toInt(), (14 * dp).toInt(), (9 * dp).toInt())
            background = GradientDrawable().apply {
                setColor(palFg); cornerRadius = 22 * dp
            }
            isClickable = true
            setOnClickListener { stopRepeat(true) }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.END
        lp.x = (12 * dp).toInt()
        lp.y = (resources.displayMetrics.heightPixels * 0.10).toInt()
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(tv, lp)
            chip = tv
            updateChip()
        } catch (e: Exception) {
            Bridge.log("반복 중지 버튼을 못 띄웠어요: ${e.message}")
        }
    }

    private fun updateChip() {
        chip?.text = "■ 반복 중지 · ${repCount}회" + (if (repLeft > 0) " / $repLeft" else "")
    }

    private fun hideChip() {
        val v = chip
        if (v != null) {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (e: Exception) { }
        }
        chip = null
    }

    // ---------- 카톡 입력창 색 감지 ----------
    private fun sampleInputColor(r: Rect, cb: (Int?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30 || r.width() <= 0 || r.height() <= 0) { cb(null); return }
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, shotExec, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(res: AccessibilityService.ScreenshotResult) {
                    var color: Int? = null
                    try {
                        val hb = res.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(hb, res.colorSpace)
                        if (hw != null) {
                            val bmp = hw.copy(Bitmap.Config.ARGB_8888, false)
                            hw.recycle()
                            if (bmp != null) {
                                color = pickColor(bmp, r)
                                bmp.recycle()
                            }
                        }
                        hb.close()
                    } catch (e: Exception) {
                        Bridge.log("입력창 색 감지 실패: ${e.message}")
                    }
                    handler.post { cb(color) }
                }

                override fun onFailure(errorCode: Int) {
                    handler.post { cb(null) }
                }
            })
        } catch (e: Exception) {
            cb(null)
        }
    }

    /** 입력창 안쪽 여러 점을 찍어서 가장 많이 나온 색을 고름 */
    private fun pickColor(b: Bitmap, r: Rect): Int? {
        val dp = resources.displayMetrics.density
        val w = r.width().toFloat()
        val pts = listOf(
            floatArrayOf(r.left + 10 * dp, r.exactCenterY()),
            floatArrayOf(r.left + 10 * dp, r.top + 6 * dp),
            floatArrayOf(r.left + 10 * dp, r.bottom - 6 * dp),
            floatArrayOf(r.left + w * 0.5f, r.top + 5 * dp),
            floatArrayOf(r.left + w * 0.5f, r.bottom - 5 * dp),
            floatArrayOf(r.right - 10 * dp, r.exactCenterY())
        )
        val cols = ArrayList<Int>()
        for (p in pts) {
            val x = p[0].toInt()
            val y = p[1].toInt()
            if (x in 0 until b.width && y in 0 until b.height) cols.add(b.getPixel(x, y))
        }
        if (cols.isEmpty()) return null
        fun dist(a: Int, c: Int) = Math.abs(Color.red(a) - Color.red(c)) +
            Math.abs(Color.green(a) - Color.green(c)) + Math.abs(Color.blue(a) - Color.blue(c))
        var best = cols[0]
        var bestN = 0
        for (c in cols) {
            val n = cols.count { dist(it, c) < 24 }
            if (n > bestN) { bestN = n; best = c }
        }
        return Color.rgb(Color.red(best), Color.green(best), Color.blue(best))
    }

    // ---------- /cmds 패널 ----------
    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) * (1 - t) + Color.red(b) * t).toInt(),
        (Color.green(a) * (1 - t) + Color.green(b) * t).toInt(),
        (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
    )

    private fun lum(c: Int): Double = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255

    /** 입력창 색을 읽은 뒤(캐시가 있으면 바로) 패널을 띄움 */
    private fun openPanelFast(r: Rect) {
        panelOpening = true
        if (!Cfg.autoColor(this)) { showPanel(null); return }
        val now = System.currentTimeMillis()
        if (cachedBase != 0 && now - cachedAt < 15000) { showPanel(cachedBase); return }
        var done = false
        sampleInputColor(r) { c ->
            if (c != null) { cachedBase = c; cachedAt = System.currentTimeMillis() }
            if (!done) { done = true; showPanel(c) }
        }
        handler.postDelayed({ if (!done) { done = true; showPanel(null) } }, 450)
    }

    private fun showPanel(sampled: Int?) {
        if (panelShown) { panelOpening = false; return }
        val base: Int = when {
            sampled != null -> sampled
            cachedBase != 0 && Cfg.autoColor(this) -> cachedBase
            else -> {
                val accent = Cfg.themeColor(this)
                if (Cfg.themeDark(this)) mix(accent, Color.BLACK, 0.82f) else mix(accent, Color.WHITE, 0.90f)
            }
        }
        // 한 색 계열: 바탕(base) 하나에서 글자/칸/테두리를 전부 파생
        val fg = if (lum(base) < 0.5) mix(base, Color.WHITE, 0.92f) else mix(base, Color.BLACK, 0.88f)
        val softCol = mix(base, fg, 0.10f)
        val lineCol = mix(base, fg, 0.28f)
        val hintCol = mix(base, fg, 0.50f)
        palBase = base
        palFg = fg

        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun round(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
            setColor(color)
            cornerRadius = r * dp
            if (stroke != null) setStroke(px(1), stroke)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(18), px(16), px(18), px(16))
            background = round(base, 22, lineCol)
        }
        root.addView(TextView(this).apply {
            text = Cfg.cmdWord(this@BotService)
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(fg)
        })
        val edit = EditText(this).apply {
            hint = "보낼 내용을 적으세요"
            setTextColor(fg)
            setHintTextColor(hintCol)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            maxLines = 8
            gravity = Gravity.TOP
            background = round(softCol, 14, lineCol)
            setPadding(px(12), px(10), px(12), px(10))
        }
        root.addView(edit, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })

        // 반복 줄: [반복 꺼짐] [간격 ___ 초] [___ 회]
        fun small(hintText: String, initial: String, decimal: Boolean) = EditText(this).apply {
            hint = hintText
            setText(initial)
            setTextColor(fg)
            setHintTextColor(hintCol)
            textSize = 15f
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_NUMBER or (if (decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0)
            background = round(softCol, 12, lineCol)
            setPadding(px(10), px(8), px(10), px(8))
        }
        val secEt = small("간격(초)", Cfg.repSecRaw(this), true)
        val cntEt = small("횟수(비움=무한)", Cfg.repCountRaw(this), false)
        val tog = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(px(12), px(9), px(12), px(9))
            isClickable = true
        }
        val repRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        repRow.addView(tog)
        repRow.addView(secEt, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = px(8) })
        repRow.addView(cntEt, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f).apply { leftMargin = px(8) })
        root.addView(repRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun pill(t: String, bgc: Int, tc: Int, stroke: Int?, bold: Boolean, click: () -> Unit) = TextView(this).apply {
            text = t
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(tc)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            background = round(bgc, 14, stroke)
            setPadding(px(8), px(12), px(8), px(12))
            isClickable = true
            setOnClickListener { click() }
        }
        val lpBtn = { left: Int -> LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = left } }
        var repeatOn = false
        row.addView(pill("닫기", Color.TRANSPARENT, fg, lineCol, false) { hidePanel() }, lpBtn(0))
        if (repRunning) {
            row.addView(pill("반복 중지", Color.TRANSPARENT, fg, lineCol, false) { stopRepeat(true); hidePanel() }, lpBtn(px(10)))
        }
        val sendBtn = pill("전송", fg, base, null, true) {
            val text = edit.text.toString().trim()
            if (repeatOn) {
                val sec = secEt.text.toString().toDoubleOrNull() ?: 5.0
                val cnt = cntEt.text.toString().toIntOrNull() ?: 0
                Cfg.p(this).edit()
                    .putString("repSec", secEt.text.toString().trim())
                    .putString("repCount", cntEt.text.toString().trim())
                    .apply()
                hidePanel()
                startRepeat(text, sec, cnt)
            } else {
                hidePanel()
                sendFromPanel(text)
            }
        }
        row.addView(sendBtn, lpBtn(px(10)))
        root.addView(row, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(12) })

        fun paintToggle() {
            tog.text = if (repeatOn) "반복 켜짐" else "반복 꺼짐"
            tog.setTextColor(if (repeatOn) base else fg)
            tog.background = round(if (repeatOn) fg else Color.TRANSPARENT, 12, lineCol)
            secEt.alpha = if (repeatOn) 1f else 0.45f
            cntEt.alpha = if (repeatOn) 1f else 0.45f
            sendBtn.text = if (repeatOn) "반복 시작" else "전송"
        }
        tog.setOnClickListener { repeatOn = !repeatOn; paintToggle() }
        paintToggle()

        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        )
        lp.dimAmount = 0.35f
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = (resources.displayMetrics.heightPixels * 0.08).toInt()
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(root, lp)
            panel = root
            panelShown = true
            panelOpening = false
            Bridge.log("패널 열림")
            root.post {
                edit.requestFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(edit, InputMethodManager.SHOW_IMPLICIT)
            }
        } catch (e: Exception) {
            panelOpening = false
            Bridge.log("패널을 띄우지 못했어요: ${e.message}")
        }
    }

    private fun hidePanel() {
        val v = panel
        if (v != null) {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (e: Exception) { }
        }
        panel = null
        panelShown = false
        panelOpening = false
    }

    // ---------- 화면 구조 덤프 ----------
    private fun dump(nodes: List<AccessibilityNodeInfo>) {
        val sb = StringBuilder()
        for (n in nodes) {
            val r = rect(n)
            sb.append("${n.className} | id=${idOf(n)} | text=${n.text} | desc=${n.contentDescription}")
              .append(" | edit=${n.isEditable} click=${n.isClickable} | [${r.left},${r.top},${r.right},${r.bottom}]\n")
        }
        val f = File(getExternalFilesDir(null) ?: filesDir, "dump.txt")
        f.writeText(sb.toString())
        Bridge.log("구조 덤프 저장: ${f.absolutePath}")
    }
}
