package com.hyewon.bot

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.util.concurrent.Executors

class BotService : AccessibilityService() {

    companion object {
        @Volatile var inst: BotService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    val awayUi: AwayOverlay by lazy { AwayOverlay(this, handler) }
    private val worker = Executors.newSingleThreadExecutor()
    private val scanTask = Runnable { scan() }
    private val pollTask = object : Runnable {
        override fun run() {
            scan()
            handler.postDelayed(this, 300) // 이벤트가 안 와도 0.3초마다 직접 확인
        }
    }
    private lateinit var history: History

    private var handledRun: List<String> = emptyList() // 이미 처리한(또는 기준으로 잡은) 상대 메시지들
    private var prevAll: List<String> = emptyList()    // 직전 화면의 모든 메시지 (방 이동 감지용)
    private var haveBaseline = false
    private var presentBefore = false
    private var stableSig = ""
    private var stableSince = 0L
    private var lastNote = ""
    private var panel: View? = null
    private var panelShown = false
    private var panelOpening = false
    private var cmdBubbleHandled = false
    @Volatile private var busy = false
    @Volatile private var paused = false // 욕 감지/삭제 작업 중에는 자동답장·패널 감지를 쉼
    val mod: Mod by lazy { Mod(this) }
    @Volatile private var aiBusy = false // AI 답을 기다리는 중 (반복 전송은 이것 때문에 멈추지 않음)
    private val sent = ArrayList<String>()
    private val shotExec = Executors.newSingleThreadExecutor()

    // 입력창 색 (미리 떠 둔 값)
    private var cachedBase = 0
    private var cachedAt = 0L
    private var palBase = Color.WHITE
    private var palFg = Color.BLACK
    private var panelRoom: List<String> = emptyList()

    // 반복 전송
    private var repRunning = false
    private var repText = ""
    private var repEveryMs = 1000L
    private var repLeft = -1
    private var repCount = 0
    private var repFails = 0
    private var repRoom: List<String> = emptyList()
    private var repMention = ""
    private var chip: TextView? = null
    private val repTask = Runnable { doRepeatSend() }

    override fun onServiceConnected() {
        NetCtx.ctx = applicationContext
        inst = this
        val base = getExternalFilesDir(null) ?: filesDir
        history = History(File(base, "hyewon"))
        Bridge.log("서비스 연결됨. 저장 위치: ${File(base, "hyewon").absolutePath}")
        handler.removeCallbacks(pollTask)
        handler.post(pollTask)
    }

    fun chipBaseColor(): Int = palBase
    fun chipFgColor(): Int = palFg

    /** 욕 감지/삭제 작업이 도는 동안 화면 감시(자동답장 등)를 쉬게 함 */
    fun setPause(on: Boolean) {
        paused = on
        if (on) handler.removeCallbacks(scanTask)
    }

    /** 작업이 끝나면 패널을 다시 열어 결과를 보여줌 (키보드는 띄우지 않고 욕 감지 카드로 스크롤) */
    fun reopenPanel() {
        if (panelShown || panelOpening) return
        if (inst == null) return
        panelOpening = true
        showPanel(if (cachedBase != 0 && Cfg.autoColor(this)) cachedBase else null, focusInput = false, scrollToMod = true)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        inst = null
        try { mod.shutdown() } catch (e: Exception) { }
        try { awayUi.hide() } catch (e: Exception) { }
        stopRepeat(false)
        handler.removeCallbacksAndMessages(null)
        hidePanel()
        return super.onUnbind(intent)
    }

    /** 공백/특수문자 차이로 이름이 안 맞는 일 방지 (대소문자·공백 무시) */
    private fun squash(s: String) = s.lowercase().replace(Regex("[\\s\\u200B\\u00A0]+"), "")

    /** 지금 카톡 화면 위쪽에 보이는 이름 후보 (반응할 사람 목록 불러오기용) */
    fun screenNames(): List<String> = try {
        val nodes = currentNodes()
        if (nodes == null) emptyList() else {
            val out = LinkedHashSet<String>()
            val h = resources.displayMetrics.heightPixels
            for (n in nodes) {
                if (n.isEditable) continue
                val r = rect(n)
                val id = idOf(n)
                // 위쪽 제목줄 글자 + 대화 속 보낸 사람 이름(id 가 name 으로 끝나는 것)
                if (!(r.top in 0..(h * 0.2).toInt() || id.endsWith("/name") || id.endsWith("/nickname"))) continue
                for (t in listOf(txt(n), n.contentDescription?.toString()?.trim() ?: "")) {
                    if (t.length in 1..30 && !t.all { it.isDigit() || it == ':' || it == ' ' } && t != "전송") out.add(t)
                }
            }
            out.toList()
        }
    } catch (e: Exception) { emptyList() }

    private fun note(m: String) {
        if (m != lastNote) { lastNote = m; Bridge.log(m) }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() != "com.kakao.talk") return
        if (paused) return
        // 글자가 바뀌는 즉시 이벤트 글자만 보고 판단 (화면 전체를 읽지 않아서 아주 빠름)
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED && fastCmd(event)) return
        handler.removeCallbacks(scanTask)
        handler.postDelayed(scanTask, 250)
    }

    private fun fastCmd(event: AccessibilityEvent): Boolean {
        val cmd = Cfg.cmdWord(this)
        if (cmd.isEmpty()) return false
        val t = (event.text?.joinToString("") ?: "").trim()
        if (t.isEmpty()) return false
        val src = event.source
        if (t != cmd) {
            // "/" 를 치는 순간 입력창 색을 미리 떠 둠 (패널이 더 빨리 뜸)
            if (t.length < cmd.length && cmd.startsWith(t) && src != null && Cfg.autoColor(this) &&
                System.currentTimeMillis() - cachedAt > 8000) {
                val r = rect(src)
                sampleInputColor(r) { c -> if (c != null) { cachedBase = c; cachedAt = System.currentTimeMillis() } }
            }
            return false
        }
        if (panelShown || panelOpening) return true
        if (src == null || !src.isEditable) return false
        val r = rect(src)
        val a = Bundle()
        a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
        src.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)
        currentNodes()?.let { panelRoom = headerNames(it) }
        openPanelFast(r)
        return true
    }

    override fun onInterrupt() {}

    // ---------- 화면 읽기 도우미 ----------
    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, d: Int = 0) {
        if (n == null || d > 60) return
        out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, d + 1)
    }

    private fun idOf(n: AccessibilityNodeInfo) = n.viewIdResourceName ?: ""
    private fun txt(n: AccessibilityNodeInfo) = n.text?.toString()?.trim() ?: ""
    private fun rect(n: AccessibilityNodeInfo): Rect = Rect().also { n.getBoundsInScreen(it) }

    // 키보드가 떠서 활성 창이 키보드여도, 열려 있는 모든 창에서 카톡 창을 찾아냄
    fun kakaoRoot(): AccessibilityNodeInfo? {
        val r = rootInActiveWindow
        if (r?.packageName?.toString() == "com.kakao.talk") return r
        try {
            for (w in windows) {
                val wr = w.root ?: continue
                if (wr.packageName?.toString() == "com.kakao.talk") return wr
            }
        } catch (e: Exception) { }
        return null
    }

    private fun currentNodes(): List<AccessibilityNodeInfo>? {
        val root = kakaoRoot() ?: return null
        val list = ArrayList<AccessibilityNodeInfo>()
        collect(root, list)
        return list
    }

    private fun findInput(nodes: List<AccessibilityNodeInfo>): AccessibilityNodeInfo? =
        nodes.firstOrNull { it.isEditable }
            ?: nodes.firstOrNull { it.className?.toString()?.endsWith("EditText") == true }

    /** 화면 위쪽(방 이름이 있는 곳)의 글자들. 알림 답장 세션을 찾을 때 씀 */
    private fun headerNames(nodes: List<AccessibilityNodeInfo>): List<String> {
        val h = resources.displayMetrics.heightPixels
        val out = LinkedHashSet<String>()
        for (n in nodes) {
            if (n.isEditable) continue
            val r = rect(n)
            if (r.top < 0 || r.top > h * 0.2) continue
            val t = txt(n); if (t.isNotEmpty()) out.add(t)
            val d = n.contentDescription?.toString()?.trim() ?: ""; if (d.isNotEmpty()) out.add(d)
        }
        return out.toList()
    }

    /** 이미 처리한 메시지(handled)와 겹치는 앞부분을 빼고 새로 온 것만 돌려줌 (화면이 스크롤돼도 안전) */
    private fun freshOf(run: List<String>, handled: List<String>): List<String> {
        val max = minOf(run.size, handled.size)
        for (k in max downTo 1) {
            if (handled.subList(handled.size - k, handled.size) == run.subList(0, k)) return run.drop(k)
        }
        return run
    }

    // ---------- 새 메시지 확인 ----------
    private fun scan() {
        if (busy || paused) return
        val nodes = currentNodes()
        if (nodes == null) { note("카톡 화면이 안 보여요 (카톡을 열어 주세요)"); return }
        if (Bridge.dumpRequested) {
            Bridge.dumpRequested = false
            dump(nodes)
        }

        val input = findInput(nodes)
        if (input == null) { note("카톡은 보이는데 채팅방 입력창이 없어요 (채팅방 안에 들어가 주세요)"); return }

        // ---- 명령어 (예: /cmds): 입력창에 치면 입력창을 비우고 패널을 띄움 ----
        val cmd = Cfg.cmdWord(this)
        val typed = input.text?.toString()?.trim() ?: ""
        if (!panelShown && !panelOpening && cmd.isNotEmpty() && typed == cmd) {
            val r = rect(input)
            val a = Bundle()
            a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
            input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)
            panelRoom = headerNames(nodes)
            openPanelFast(r)
            return
        }

        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        val inputTop = rect(input).top

        val byId = nodes.filter { idOf(it).endsWith("/message") && txt(it).isNotEmpty() }
        val msgNodes = if (byId.isNotEmpty()) byId else nodes.filter {
            val r = rect(it)
            it.className?.toString()?.endsWith("TextView") == true && !it.isEditable &&
                txt(it).isNotEmpty() && r.top > h * 0.12 && r.bottom < inputTop
        }
        // 위 → 아래 순서로 정렬해서 (글자, 내가 보낸 것인지) 목록 만들기
        val ordered = msgNodes.sortedBy { rect(it).top }.map {
            val r = rect(it)
            val own = (r.left + r.right) / 2 > w * 0.56 // 오른쪽에 붙은 말풍선 = 내가 보낸 것
            val t = txt(it)
            Pair(t, own || sent.contains(t))
        }

        // 이미 보내버린 "/cmds" 말풍선도 인식 (한 번만)
        val lastBubble = ordered.lastOrNull()
        if (lastBubble != null && lastBubble.first == cmd && lastBubble.second) {
            if (!cmdBubbleHandled && !panelShown && !panelOpening && cmd.isNotEmpty()) {
                cmdBubbleHandled = true
                panelRoom = headerNames(nodes)
                openPanelFast(rect(input))
                return
            }
        } else cmdBubbleHandled = false

        if (panelShown) return              // 패널이 열려 있는 동안 자동 답장은 쉼
        if (!Cfg.enabled(this)) return

        // 화면에 보이는 모든 글자 (방 이름/상대 이름 확인용)
        val screen = ArrayList<String>()
        for (n in nodes) {
            if (n.isEditable) continue
            val t = txt(n); if (t.isNotEmpty()) screen.add(t)
            val d = n.contentDescription?.toString()?.trim() ?: ""; if (d.isNotEmpty()) screen.add(d)
        }
        val everyone = Cfg.everyone(this)
        val names = Cfg.names(this)
        val screenN = screen.map { squash(it) }
        fun onScreen(nm: String): Boolean { val q = squash(nm); return q.isNotEmpty() && screenN.any { it.contains(q) } }
        val present = everyone || names.any { onScreen(it) }
        val blocked = Cfg.blocks(this).any { onScreen(it) }

        if (ordered.isEmpty()) return

        // 맨 아래에서부터, 내가 보낸 말풍선이 나올 때까지 이어진 상대 메시지 전부
        val run = ArrayList<String>()
        for (i in ordered.indices.reversed()) {
            if (ordered[i].second) break
            run.add(0, ordered[i].first)
        }

        // 다른 채팅방으로 옮겨갔는지 확인: 직전 화면과 겹치는 메시지가 하나도 없으면 방이 바뀐 것
        val allTexts = ordered.map { it.first }
        val overlap = prevAll.isEmpty() || allTexts.any { prevAll.contains(it) }
        prevAll = allTexts
        if (!overlap) {
            handledRun = run
            haveBaseline = true
            stableSig = ""
            Bridge.log("채팅방이 바뀐 것 같아요. 기존 메시지는 기준으로만 잡았어요")
            return
        }

        // ---- 반응으로 AI답변하기: 내가 상대 메시지에 반응을 달면 그 메시지에 답함 ----
        if (Cfg.reactAi(this) && !blocked) {
            val reacted = detectReaction(nodes, msgNodes, w, h, inputTop)
            if (reacted != null) {
                Bridge.log("반응 감지 -> 이 메시지에 답해요: ${reacted.take(200)}")
                handledRun = run
                haveBaseline = true
                stableSig = ""
                runAi("(내가 이 메시지에 반응을 눌렀어. 이 메시지에 답해줘)\n" + reacted)
                return
            }
        }

        val wasPresent = presentBefore
        presentBefore = present && !blocked
        if (!present) { note("반응 대상 이름/방이 화면에 없어요 (찾는 이름: ${names.joinToString(", ")})"); return }
        if (blocked) { note("제외 대상이라 건너뛰어요"); return }
        note("채팅방 감지됨")

        if (!wasPresent || !haveBaseline) { // 처음 보는 상태: 기준만 잡고 답하지 않음
            handledRun = run
            haveBaseline = true
            stableSig = ""
            Bridge.log("기준 설정 (기존 상대 메시지 ${run.size}개)")
            return
        }
        if (run.isEmpty()) { // 마지막이 내 말풍선 → 다음 대화를 새로 시작
            handledRun = emptyList()
            stableSig = ""
            return
        }
        val fresh = freshOf(run, handledRun)
        if (fresh.isEmpty()) { stableSig = ""; return }

        // 상대가 연달아 보내는 중일 수 있어서, 설정한 시간 동안 내용이 안 바뀔 때까지 기다림
        val now = System.currentTimeMillis()
        val sig = fresh.joinToString("\u0001")
        if (sig != stableSig) { stableSig = sig; stableSince = now; return }
        if (now - stableSince < Cfg.waitMs(this)) return
        stableSig = ""
        handledRun = run

        runAi(fresh.joinToString("\n"))
    }

    /** AI 에게 물어보고 답을 보냄 (새 메시지/반응 둘 다 사용) */
    private fun runAi(text: String) {
        val opts = Cfg.opts(this)
        val noEmoji = Cfg.noEmoji(this)
        Bridge.log("AI에게 보냄: ${text.replace("\n", " / ").take(400)}")
        busy = true
        aiBusy = true
        worker.execute {
            try {
                history.add("user", text)
                val raw = Ai.ask(history.load(), opts)
                val answer = Ai.clean(raw, noEmoji)
                if (raw.contains("[SKIP]") || answer.isEmpty()) {
                    Bridge.log("답하지 않음")
                    handler.post { finish() }
                } else {
                    history.add("bot", answer)
                    handler.post { reply(answer) }
                }
            } catch (e: Exception) {
                Bridge.log("AI 실패: ${e.message}")
                handler.post { finish() }
            }
        }
    }

    /** 카톡 화면이 지금 보이는지 (알림 경로와 화면 경로가 겹쳐 답하지 않게) */
    fun kakaoOnScreen(): Boolean = try { kakaoRoot() != null } catch (e: Exception) { false }

    /** 카톡 '채팅방 안'이 화면에 열려 있는지 (입력창이 보이는지). 목록 화면이면 알림 경로가 답해야 함 */
    fun kakaoInRoom(): Boolean = try {
        val nodes = currentNodes()
        nodes != null && findInput(nodes) != null
    } catch (e: Exception) { false }

    // ---------- 반응(공감/이모지) 감지 ----------
    private val reactSeen = HashMap<String, String>()   // 메시지 글자 -> 마지막으로 본 반응 서명
    private var reactLogged = ""
    private val reactDone = HashMap<String, Long>()   // 이미 답한 메시지 -> 시간 (같은 메시지에 반복 답장 방지)
    private var lastReactAt = 0L

    private fun isReactionNode(n: AccessibilityNodeInfo): Boolean {
        if (n.isEditable) return false
        val id = idOf(n).lowercase()
        val d = n.contentDescription?.toString() ?: ""
        val t = txt(n)
        if (id.endsWith("/message")) return false
        return id.contains("reaction") || id.contains("emotion") || id.contains("feeling") ||
            id.contains("react") || id.contains("sticker") || id.contains("emoji") || id.contains("emoticon") ||
            id.contains("like") || id.contains("heart") ||
            d.contains("공감") || d.contains("리액션") || d.contains("반응") || d.contains("좋아요") || d.contains("하트") ||
            t.contains("공감") && t.length <= 6
    }

    /** 새로 반응이 붙은 '상대 메시지' 글자를 돌려줌. 처음 보는 메시지/이미 있던 반응은 기준으로만 기록 */
    private fun detectReaction(
        nodes: List<AccessibilityNodeInfo>, msgNodes: List<AccessibilityNodeInfo>,
        w: Int, h: Int, inputTop: Int
    ): String? {
        val dp = resources.displayMetrics.density
        val sigs = HashMap<String, StringBuilder>()
        val rNodes = nodes.filter { isReactionNode(it) && rect(it).top > h * 0.1 && rect(it).bottom <= inputTop }
        if (rNodes.isNotEmpty()) {
            val info = rNodes.joinToString(" | ") { idOf(it).substringAfterLast('/') + ":" + (it.contentDescription ?: txt(it)) }.take(200)
            if (info != reactLogged) { reactLogged = info; Bridge.log("반응 후보 노드: $info") }
        }
        for (rn in rNodes) {
            val rr = rect(rn)
            // 반응 표시 바로 위에 있고 가로로 겹치는 말풍선 = 반응이 붙은 메시지
            val host = msgNodes.filter {
                val mr = rect(it)
                mr.top < rr.top && mr.right > rr.left - 8 * dp && mr.left < rr.right + 8 * dp &&
                    rr.top - mr.bottom < 90 * dp
            }.maxByOrNull { rect(it).bottom } ?: continue
            val key = txt(host)
            val sig = idOf(rn) + "/" + (rn.contentDescription ?: "") + "/" + txt(rn) + "/" + rr.width()
            sigs.getOrPut(key) { StringBuilder() }.append(sig).append(';')
        }
        var result: String? = null
        for (mn in msgNodes) {
            val key = txt(mn)
            val own = (rect(mn).left + rect(mn).right) / 2 > w * 0.56 || sent.contains(key)
            val now = sigs[key]?.toString() ?: ""
            val before = reactSeen[key]
            if (before == null) {
                reactSeen[key] = now            // 처음 본 메시지: 기준만 기록
            } else if (now != before) {
                reactSeen[key] = now
                // 반응이 '없다가 새로 생긴' 상대 메시지에만 답함 (화면 깜빡임으로 인한 반복 방지: 같은 메시지 10분, 전체 8초 간격)
                val t = System.currentTimeMillis()
                val doneAt = reactDone[key] ?: 0L
                if (before.isEmpty() && now.isNotEmpty() && !own && result == null &&
                    t - doneAt > 10 * 60 * 1000L && t - lastReactAt > 8000L) {
                    result = key
                    reactDone[key] = t
                    lastReactAt = t
                }
            }
        }
        while (reactSeen.size > 300) reactSeen.remove(reactSeen.keys.first())
        while (reactDone.size > 100) reactDone.remove(reactDone.keys.first())
        return result
    }

    private fun finish() {
        busy = false
        aiBusy = false
        handler.postDelayed(scanTask, 300)
    }

    private fun rememberSent(t: String) {
        sent.add(t)
        while (sent.size > 10) sent.removeAt(0)
    }

    // ---------- 전송 (알림 답장 스크립트 우선, 안 되면 입력창) ----------
    /** names: 이 메시지를 보낼 방의 이름 후보 (화면 위쪽 글자). strictRoom: 입력창 방식일 때 방이 같은지 확인할 후보 */
    private fun sendText(text: String, names: List<String>, strictRoom: List<String>?, cb: (Boolean) -> Unit) {
        if (Cfg.viaScript(this) && Replier.send(this, names, text)) {
            rememberSent(text)
            Bridge.log("스크립트 전송: ${text.replace("\n", " / ").take(400)}")
            cb(true)
            return
        }
        if (Cfg.viaScript(this)) {
            Bridge.log("이 방은 알림 답장이 아직 준비 안 됨 -> 입력창 방식으로 전송 (방에서 알림이 한 번 오면 준비돼요)")
        }
        sendViaInput(text, strictRoom, cb)
    }

    private fun sendViaInput(text: String, strictRoom: List<String>?, cb: (Boolean) -> Unit) {
        busy = true
        handler.postDelayed({
            val nodes = currentNodes()
            val input = if (nodes == null) null else findInput(nodes)
            if (input == null) {
                Bridge.log("전송 실패: 카톡 입력창을 못 찾음 (채팅방이 닫힘?)")
                cb(false)
                return@postDelayed
            }
            if (strictRoom != null && strictRoom.isNotEmpty() &&
                headerNames(nodes!!).none { strictRoom.contains(it) }) {
                Bridge.log("전송 건너뜀: 처음 시작한 채팅방이 아니에요")
                cb(false)
                return@postDelayed
            }
            input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) Bridge.log("입력창에 글자 넣기 실패")
            handler.postDelayed({ clickSend(text, cb) }, 150)
        }, 60)
    }

    private fun clickSend(text: String, cb: (Boolean) -> Unit) {
        val nodes = currentNodes()
        val btn = nodes?.firstOrNull {
            idOf(it).endsWith("/send") ||
                it.contentDescription?.toString() == "전송" || txt(it) == "전송"
        }
        var done = false
        var n: AccessibilityNodeInfo? = btn
        while (n != null && !done) {
            if (n.isClickable) done = n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        if (done) {
            rememberSent(text)
            Bridge.log("입력창 방식 전송: ${text.replace("\n", " / ").take(400)}")
        } else {
            Bridge.log("전송 버튼을 못 찾음 (구조 덤프를 보내 주세요)")
        }
        cb(done)
    }

    // ---------- 자동 답장 ----------
    private fun reply(answer: String) {
        if (!Cfg.autoSend(this)) {
            // 자동 전송이 꺼져 있으면 입력창에 적어두기만 함
            val nodes = currentNodes()
            val input = if (nodes == null) null else findInput(nodes)
            if (input != null) {
                val args = Bundle()
                args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, answer)
                input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            }
            Bridge.log("입력창에만 입력함 (자동 전송 꺼짐): ${answer.take(400)}")
            finish()
            return
        }
        val nodes = currentNodes()
        val names = if (nodes == null) emptyList() else headerNames(nodes)
        sendText(answer, names, null) { finish() }
    }

    /** 패널에서 한 번 보내기 */
    private fun sendFromPanel(text: String, mention: String = "") {
        if (text.isEmpty()) return
        busy = true
        val names = currentNodes()?.let { headerNames(it) }?.ifEmpty { null } ?: panelRoom
        if (mention.isNotEmpty()) sendMention(mention, text, names, { finish() }) else sendText(text, names, null) { finish() }
    }

    // ---------- 멘션 전송 (입력창에 @이름 → 뜨는 멤버 목록에서 선택 → 내용 붙이기) ----------
    private fun nodeKey(n: AccessibilityNodeInfo): String {
        val r = rect(n)
        return txt(n) + "|" + (n.contentDescription?.toString() ?: "") + "|" + r.left + "," + r.top + "," + r.right + "," + r.bottom
    }

    private fun clickUp(start: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = start
        var d = 0
        while (n != null && d < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            d++
        }
        return false
    }

    private fun setInput(input: AccessibilityNodeInfo, t: String): Boolean {
        val a = Bundle()
        a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)
    }

    /** 멘션 전송. 목록에서 이름을 못 찾으면 '@이름 내용' 글자로 그냥 보냄 */
    private fun sendMention(name: String, text: String, strictRoom: List<String>?, cb: (Boolean) -> Unit) {
        busy = true
        handler.postDelayed({
            val nodes = currentNodes()
            val input = if (nodes == null) null else findInput(nodes)
            if (nodes == null || input == null) {
                Bridge.log("멘션 전송 실패: 카톡 입력창을 못 찾음")
                cb(false)
                return@postDelayed
            }
            if (strictRoom != null && strictRoom.isNotEmpty() && headerNames(nodes).none { strictRoom.contains(it) }) {
                Bridge.log("전송 건너뜀: 처음 시작한 채팅방이 아니에요")
                cb(false)
                return@postDelayed
            }
            val before = HashSet<String>()
            for (n in nodes) before.add(nodeKey(n))
            input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            setInput(input, "@$name")
            pickMention(name, text, before, 0, cb)
        }, 150)
    }

    private fun pickMention(name: String, text: String, before: Set<String>, tries: Int, cb: (Boolean) -> Unit) {
        val nodes = currentNodes()
        if (nodes != null) {
            // 방금 새로 나타난 항목(= 멤버 목록) 중에서 이름이 들어 있는 것
            val cand = nodes.firstOrNull {
                !it.isEditable && !idOf(it).endsWith("/message") && !before.contains(nodeKey(it)) &&
                    (txt(it).contains(name) || (it.contentDescription?.toString() ?: "").contains(name))
            }
            if (cand != null && clickUp(cand)) {
                handler.postDelayed({ appendAfterMention(text, cb) }, 120)
                return
            }
        }
        if (tries < 14) {
            handler.postDelayed({ pickMention(name, text, before, tries + 1, cb) }, 100)
            return
        }
        // 목록이 안 떴음 (1:1 방이거나 구조가 다름) -> 그냥 글자로 보냄
        Bridge.log("멘션 목록을 못 찾음 -> '@$name' 글자로 전송")
        val input = currentNodes()?.let { findInput(it) }
        if (input == null) { cb(false); return }
        setInput(input, "@$name $text")
        handler.postDelayed({ clickSend("@$name $text", cb) }, 150)
    }

    private fun appendAfterMention(text: String, cb: (Boolean) -> Unit) {
        val input = currentNodes()?.let { findInput(it) }
        if (input == null) { Bridge.log("멘션 전송 실패: 입력창 사라짐"); cb(false); return }
        input.refresh()
        val cur = input.text?.toString() ?: ""
        val add = (if (cur.isEmpty() || cur.last().isWhitespace()) "" else " ") + text
        var pasted = false
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("m", add))
            val sel = Bundle()
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, cur.length)
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, cur.length)
            input.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
            pasted = input.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        } catch (e: Exception) { }
        handler.postDelayed({
            val inp = currentNodes()?.let { findInput(it) }
            if (inp == null) { cb(false); return@postDelayed }
            inp.refresh()
            val now = inp.text?.toString() ?: ""
            if (!pasted || now.length <= cur.length) {
                // 붙여넣기가 안 먹으면 글자로 이어 붙임 (멘션 표시는 사라질 수 있음)
                setInput(inp, cur + add)
                Bridge.log("멘션 뒤 내용 붙이기: 글자 입력 방식 사용")
            }
            handler.postDelayed({ clickSend("$cur$add", cb) }, 120)
        }, 120)
    }

    // ---------- 반복 전송 ----------
    private fun startRepeat(text: String, sec: Double, count: Int, mention: String = "") {
        stopRepeat(false)
        if (text.isEmpty()) return
        repRunning = true
        RepMem.add(this, text) // 나중에 '반복 메세지 지우기'로 한꺼번에 지울 수 있게 기억
        repText = text
        repMention = mention
        repEveryMs = (sec.coerceAtLeast(0.0) * 1000).toLong() // 제한 없음 (0초도 가능)
        repLeft = if (count > 0) count else -1
        repCount = 0
        repFails = 0
        repRoom = currentNodes()?.let { headerNames(it) }?.ifEmpty { null } ?: panelRoom
        Bridge.log("반복 시작" + (if (mention.isNotEmpty()) "(멘션 @$mention)" else "") + ": ${repEveryMs / 1000.0}초마다" + (if (repLeft > 0) " ${repLeft}회" else " 무한") + " / 방 ${repRoom.take(3)}")
        showChip()
        handler.post(repTask)
    }

    private fun doRepeatSend() {
        if (!repRunning) return
        if (busy && !aiBusy) { handler.postDelayed(repTask, 100); return }
        val done: (Boolean) -> Unit = done@{ ok ->
            if (!aiBusy) busy = false
            if (!repRunning) return@done
            if (ok) { repCount++; repFails = 0 } else repFails++
            updateChip()
            if (repLeft > 0 && repCount >= repLeft) { Bridge.log("반복 끝 (${repCount}회)"); stopRepeat(false); return@done }
            if (repFails >= 5) { Bridge.log("반복 중지: 연속 5번 전송 실패"); stopRepeat(false); return@done }
            handler.postDelayed(repTask, repEveryMs)
        }
        try {
            if (repMention.isNotEmpty()) sendMention(repMention, repText, repRoom, done)
            else sendText(repText, repRoom, repRoom, done)
        } catch (e: Exception) {
            Bridge.log("반복 전송 오류: ${e.message}")
            done(false)
        }
    }

    private fun stopRepeat(log: Boolean) {
        val was = repRunning
        repRunning = false
        handler.removeCallbacks(repTask)
        hideChip()
        if (was && log) Bridge.log("반복 중지 (${repCount}회 보냄)")
    }

    private fun showChip() {
        hideChip()
        val dp = resources.displayMetrics.density
        val tv = TextView(this).apply {
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(palBase)
            setPadding((14 * dp).toInt(), (9 * dp).toInt(), (14 * dp).toInt(), (9 * dp).toInt())
            background = GradientDrawable().apply {
                setColor(palFg); cornerRadius = 22 * dp
            }
            isClickable = true
            setOnClickListener { stopRepeat(true) }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.END
        lp.x = (12 * dp).toInt()
        lp.y = (resources.displayMetrics.heightPixels * 0.10).toInt()
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(tv, lp)
            chip = tv
            updateChip()
        } catch (e: Exception) {
            Bridge.log("반복 중지 버튼을 못 띄웠어요: ${e.message}")
        }
    }

    private fun updateChip() {
        chip?.text = "■ 반복 중지 · ${repCount}회" + (if (repLeft > 0) " / $repLeft" else "")
    }

    private fun hideChip() {
        val v = chip
        if (v != null) {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (e: Exception) { }
        }
        chip = null
    }

    // ---------- 카톡 입력창 색 감지 ----------
    private fun sampleInputColor(r: Rect, cb: (Int?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30 || r.width() <= 0 || r.height() <= 0) { cb(null); return }
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, shotExec, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(res: AccessibilityService.ScreenshotResult) {
                    var color: Int? = null
                    try {
                        val hb = res.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(hb, res.colorSpace)
                        if (hw != null) {
                            val bmp = hw.copy(Bitmap.Config.ARGB_8888, false)
                            hw.recycle()
                            if (bmp != null) {
                                color = pickColor(bmp, r)
                                bmp.recycle()
                            }
                        }
                        hb.close()
                    } catch (e: Exception) {
                        Bridge.log("입력창 색 감지 실패: ${e.message}")
                    }
                    handler.post { cb(color) }
                }

                override fun onFailure(errorCode: Int) {
                    handler.post { cb(null) }
                }
            })
        } catch (e: Exception) {
            cb(null)
        }
    }

    /** 입력창 안쪽 여러 점을 찍어서 가장 많이 나온 색을 고름 */
    private fun pickColor(b: Bitmap, r: Rect): Int? {
        val dp = resources.displayMetrics.density
        val w = r.width().toFloat()
        val pts = listOf(
            floatArrayOf(r.left + 10 * dp, r.exactCenterY()),
            floatArrayOf(r.left + 10 * dp, r.top + 6 * dp),
            floatArrayOf(r.left + 10 * dp, r.bottom - 6 * dp),
            floatArrayOf(r.left + w * 0.5f, r.top + 5 * dp),
            floatArrayOf(r.left + w * 0.5f, r.bottom - 5 * dp),
            floatArrayOf(r.right - 10 * dp, r.exactCenterY())
        )
        val cols = ArrayList<Int>()
        for (p in pts) {
            val x = p[0].toInt()
            val y = p[1].toInt()
            if (x in 0 until b.width && y in 0 until b.height) cols.add(b.getPixel(x, y))
        }
        if (cols.isEmpty()) return null
        fun dist(a: Int, c: Int) = Math.abs(Color.red(a) - Color.red(c)) +
            Math.abs(Color.green(a) - Color.green(c)) + Math.abs(Color.blue(a) - Color.blue(c))
        var best = cols[0]
        var bestN = 0
        for (c in cols) {
            val n = cols.count { dist(it, c) < 24 }
            if (n > bestN) { bestN = n; best = c }
        }
        return Color.rgb(Color.red(best), Color.green(best), Color.blue(best))
    }

    // ---------- /cmds 패널 ----------
    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) * (1 - t) + Color.red(b) * t).toInt(),
        (Color.green(a) * (1 - t) + Color.green(b) * t).toInt(),
        (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
    )

    private fun lum(c: Int): Double = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255

    /** 입력창 색을 읽은 뒤(캐시가 있으면 바로) 패널을 띄움 */
    private fun openPanelFast(r: Rect) {
        panelOpening = true
        if (!Cfg.autoColor(this)) { showPanel(null); return }
        val now = System.currentTimeMillis()
        if (cachedBase != 0 && now - cachedAt < 15000) { showPanel(cachedBase); return }
        var done = false
        sampleInputColor(r) { c ->
            if (c != null) { cachedBase = c; cachedAt = System.currentTimeMillis() }
            if (!done) { done = true; showPanel(c) }
        }
        handler.postDelayed({ if (!done) { done = true; showPanel(null) } }, 450)
    }

    private fun showPanel(sampled: Int?, focusInput: Boolean = true, scrollToMod: Boolean = false) {
        if (panelShown) { panelOpening = false; return }
        val base: Int = when {
            sampled != null -> sampled
            cachedBase != 0 && Cfg.autoColor(this) -> cachedBase
            else -> {
                val accent = Cfg.themeColor(this)
                if (Cfg.themeDark(this)) mix(accent, Color.BLACK, 0.82f) else mix(accent, Color.WHITE, 0.90f)
            }
        }
        // 한 색 계열: 바탕(base) 하나에서 글자/칸/테두리를 전부 파생
        val fg = if (lum(base) < 0.5) mix(base, Color.WHITE, 0.92f) else mix(base, Color.BLACK, 0.88f)
        val softCol = mix(base, fg, 0.10f)
        val lineCol = mix(base, fg, 0.28f)
        val hintCol = mix(base, fg, 0.50f)
        palBase = base
        palFg = fg

        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun round(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
            setColor(color)
            cornerRadius = r * dp
            if (stroke != null) setStroke(px(1), stroke)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(18), px(16), px(18), px(16))
            background = round(base, 22, lineCol)
        }
        root.addView(TextView(this).apply {
            text = Cfg.cmdWord(this@BotService)
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(fg)
        })
        val edit = EditText(this).apply {
            hint = "보낼 내용을 적으세요"
            setTextColor(fg)
            setHintTextColor(hintCol)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            maxLines = 8
            gravity = Gravity.TOP
            background = round(softCol, 14, lineCol)
            setPadding(px(12), px(10), px(12), px(10))
        }
        root.addView(edit, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })

        val mentionEt = EditText(this).apply {
            hint = "멘션할 이름 (비우면 멘션 없음)"
            setText(Cfg.mentionRaw(this@BotService))
            setTextColor(fg)
            setHintTextColor(hintCol)
            textSize = 15f
            isSingleLine = true
            background = round(softCol, 12, lineCol)
            setPadding(px(10), px(8), px(10), px(8))
        }
        root.addView(mentionEt, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })

        // 반복 줄: [반복 꺼짐] [간격 ___ 초] [___ 회]
        fun small(hintText: String, initial: String, decimal: Boolean) = EditText(this).apply {
            hint = hintText
            setText(initial)
            setTextColor(fg)
            setHintTextColor(hintCol)
            textSize = 15f
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_NUMBER or (if (decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0)
            background = round(softCol, 12, lineCol)
            setPadding(px(10), px(8), px(10), px(8))
        }
        val secEt = small("간격(초)", Cfg.repSecRaw(this), true)
        val cntEt = small("횟수(비움=무한)", Cfg.repCountRaw(this), false)
        val tog = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(px(12), px(9), px(12), px(9))
            isClickable = true
        }
        val repRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        repRow.addView(tog)
        repRow.addView(secEt, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = px(8) })
        repRow.addView(cntEt, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f).apply { leftMargin = px(8) })
        root.addView(repRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun pill(t: String, bgc: Int, tc: Int, stroke: Int?, bold: Boolean, click: () -> Unit) = TextView(this).apply {
            text = t
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(tc)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            background = round(bgc, 14, stroke)
            setPadding(px(8), px(12), px(8), px(12))
            isClickable = true
            setOnClickListener { click() }
        }
        val lpBtn = { left: Int -> LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = left } }
        var repeatOn = false
        row.addView(pill("닫기", Color.TRANSPARENT, fg, lineCol, false) { hidePanel() }, lpBtn(0))
        if (repRunning) {
            row.addView(pill("반복 중지", Color.TRANSPARENT, fg, lineCol, false) { stopRepeat(true); hidePanel() }, lpBtn(px(10)))
        }
        val sendBtn = pill("전송", fg, base, null, true) {
            val text = edit.text.toString().trim()
            val mention = mentionEt.text.toString().trim().removePrefix("@").trim()
            Cfg.p(this).edit().putString("mention", mention).apply()
            if (repeatOn) {
                val sec = secEt.text.toString().toDoubleOrNull() ?: 5.0
                val cnt = cntEt.text.toString().toIntOrNull() ?: 0
                Cfg.p(this).edit()
                    .putString("repSec", secEt.text.toString().trim())
                    .putString("repCount", cntEt.text.toString().trim())
                    .apply()
                hidePanel()
                startRepeat(text, sec, cnt, mention)
            } else {
                hidePanel()
                sendFromPanel(text, mention)
            }
        }
        row.addView(sendBtn, lpBtn(px(10)))
        root.addView(row, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(12) })

        fun paintToggle() {
            tog.text = if (repeatOn) "반복 켜짐" else "반복 꺼짐"
            tog.setTextColor(if (repeatOn) base else fg)
            tog.background = round(if (repeatOn) fg else Color.TRANSPARENT, 12, lineCol)
            secEt.alpha = if (repeatOn) 1f else 0.45f
            cntEt.alpha = if (repeatOn) 1f else 0.45f
            sendBtn.text = if (repeatOn) "반복 시작" else "전송"
        }
        tog.setOnClickListener { repeatOn = !repeatOn; paintToggle() }
        paintToggle()

        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        )
        lp.dimAmount = 0.35f
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = (resources.displayMetrics.heightPixels * 0.08).toInt()
        lp.softInputMode = (if (focusInput) WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
            else WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN) or
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(root)
        var scrollRef: android.widget.ScrollView? = null
        var chatRef: View? = null
        val chatCard = ChatCard.build(this, base, fg, softCol, lineCol, hintCol) {
            // 입력창을 누르면 키보드에 가리지 않게 이 카드를 위로 올려 보여줌
            chatRef?.let { v -> scrollRef?.postDelayed({ scrollRef?.smoothScrollTo(0, v.top) }, 300) }
        }
        chatRef = chatCard
        col.addView(chatCard, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })
        val aiCard = AiCard.build(this, base, fg, softCol, lineCol, hintCol)
        col.addView(aiCard, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })
        var modRef: View? = null
        val modCard = ModCard.build(this, base, fg, softCol, lineCol, hintCol, ModActions(
            detect = { hidePanel(); mod.detect(palBase, palFg) },
            deleteBad = { hidePanel(); mod.deleteBad(palBase, palFg) },
            replyAll = { t -> hidePanel(); mod.replyAll(t, palBase, palFg) },
            scan = { hidePanel(); mod.scan(palBase, palFg) },
            deleteRepeat = { hidePanel(); mod.deleteRepeat(palBase, palFg) },
            deleteGroups = { g -> hidePanel(); mod.deleteGroups(g, palBase, palFg) },
            search = { q -> mod.search(q) }
        )) {
            // 검색칸을 누르면 키보드에 가리지 않게 이 카드를 위로 올려 보여줌
            modRef?.let { v -> scrollRef?.postDelayed({ scrollRef?.smoothScrollTo(0, v.top) }, 300) }
        }
        modRef = modCard
        col.addView(modCard, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })
        val awayCard = AwayCard.build(this, base, fg, softCol, lineCol, hintCol) { hidePanel() }
        col.addView(awayCard, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })
        // 카드가 여러 개라 화면보다 길어질 수 있어서 스크롤 가능하게 감쌈
        val scrollWrap = android.widget.ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) }
        scrollRef = scrollWrap
        lp.height = (resources.displayMetrics.heightPixels * 0.86).toInt()
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(scrollWrap, lp)
            panel = scrollWrap
            panelShown = true
            panelOpening = false
            Bridge.log("패널 열림")
            if (focusInput) {
                root.post {
                    edit.requestFocus()
                    (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                        .showSoftInput(edit, InputMethodManager.SHOW_IMPLICIT)
                }
            } else if (scrollToMod) {
                scrollWrap.postDelayed({ scrollWrap.scrollTo(0, modCard.top) }, 150)
            }
        } catch (e: Exception) {
            panelOpening = false
            Bridge.log("패널을 띄우지 못했어요: ${e.message}")
        }
    }

    private fun hidePanel() {
        val v = panel
        if (v != null) {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (e: Exception) { }
        }
        panel = null
        panelShown = false
        panelOpening = false
    }

    // ---------- 화면 구조 덤프 ----------
    private fun dump(nodes: List<AccessibilityNodeInfo>) {
        val sb = StringBuilder()
        for (n in nodes) {
            val r = rect(n)
            sb.append("${n.className} | id=${idOf(n)} | text=${n.text} | desc=${n.contentDescription}")
              .append(" | edit=${n.isEditable} click=${n.isClickable} | [${r.left},${r.top},${r.right},${r.bottom}]\n")
        }
        val f = File(getExternalFilesDir(null) ?: filesDir, "dump.txt")
        f.writeText(sb.toString())
        Bridge.log("구조 덤프 저장: ${f.absolutePath}")
    }
}
