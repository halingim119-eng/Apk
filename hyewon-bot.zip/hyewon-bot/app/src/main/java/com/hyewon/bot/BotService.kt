package com.hyewon.bot

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.util.concurrent.Executors

class BotService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val scanTask = Runnable { scan() }
    private val pollTask = object : Runnable {
        override fun run() {
            scan()
            handler.postDelayed(this, 1000) // 이벤트가 안 와도 1초마다 직접 확인
        }
    }
    private lateinit var history: History

    private var handledRun: List<String> = emptyList() // 이미 처리한(또는 기준으로 잡은) 상대 메시지들
    private var prevAll: List<String> = emptyList()    // 직전 화면의 모든 메시지 (방 이동 감지용)
    private var haveBaseline = false
    private var presentBefore = false
    private var stableSig = ""
    private var stableSince = 0L
    private var lastNote = ""
    private var panel: View? = null
    private var panelShown = false
    private var cmdBubbleHandled = false
    @Volatile private var busy = false
    private val sent = ArrayList<String>()

    override fun onServiceConnected() {
        val base = getExternalFilesDir(null) ?: filesDir
        history = History(File(base, "hyewon"))
        Bridge.log("서비스 연결됨. 저장 위치: ${File(base, "hyewon").absolutePath}")
        handler.removeCallbacks(pollTask)
        handler.post(pollTask)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        handler.removeCallbacksAndMessages(null)
        hidePanel()
        return super.onUnbind(intent)
    }

    private fun note(m: String) {
        if (m != lastNote) { lastNote = m; Bridge.log(m) }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() != "com.kakao.talk") return
        handler.removeCallbacks(scanTask)
        handler.postDelayed(scanTask, 800)
    }

    override fun onInterrupt() {}

    // ---------- 화면 읽기 도우미 ----------
    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, d: Int = 0) {
        if (n == null || d > 60) return
        out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, d + 1)
    }

    private fun idOf(n: AccessibilityNodeInfo) = n.viewIdResourceName ?: ""
    private fun txt(n: AccessibilityNodeInfo) = n.text?.toString()?.trim() ?: ""
    private fun rect(n: AccessibilityNodeInfo): Rect = Rect().also { n.getBoundsInScreen(it) }

    // 키보드가 떠서 활성 창이 키보드여도, 열려 있는 모든 창에서 카톡 창을 찾아냄
    private fun kakaoRoot(): AccessibilityNodeInfo? {
        val r = rootInActiveWindow
        if (r?.packageName?.toString() == "com.kakao.talk") return r
        try {
            for (w in windows) {
                val wr = w.root ?: continue
                if (wr.packageName?.toString() == "com.kakao.talk") return wr
            }
        } catch (e: Exception) { }
        return null
    }

    private fun currentNodes(): List<AccessibilityNodeInfo>? {
        val root = kakaoRoot() ?: return null
        val list = ArrayList<AccessibilityNodeInfo>()
        collect(root, list)
        return list
    }

    private fun findInput(nodes: List<AccessibilityNodeInfo>): AccessibilityNodeInfo? =
        nodes.firstOrNull { it.isEditable }
            ?: nodes.firstOrNull { it.className?.toString()?.endsWith("EditText") == true }

    /** 이미 처리한 메시지(handled)와 겹치는 앞부분을 빼고 새로 온 것만 돌려줌 (화면이 스크롤돼도 안전) */
    private fun freshOf(run: List<String>, handled: List<String>): List<String> {
        val max = minOf(run.size, handled.size)
        for (k in max downTo 1) {
            if (handled.subList(handled.size - k, handled.size) == run.subList(0, k)) return run.drop(k)
        }
        return run
    }

    // ---------- 새 메시지 확인 ----------
    private fun scan() {
        if (busy) return
        val nodes = currentNodes()
        if (nodes == null) { note("카톡 화면이 안 보여요 (카톡을 열어 주세요)"); return }
        if (Bridge.dumpRequested) {
            Bridge.dumpRequested = false
            dump(nodes)
        }

        val input = findInput(nodes)
        if (input == null) { note("카톡은 보이는데 채팅방 입력창이 없어요 (채팅방 안에 들어가 주세요)"); return }

        // ---- 명령어 (예: /cmds): 입력창에 치면 입력창을 비우고 패널을 띄움 ----
        val cmd = Cfg.cmdWord(this)
        val typed = input.text?.toString()?.trim() ?: ""
        if (!panelShown && cmd.isNotEmpty() && typed == cmd) {
            val a = Bundle()
            a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
            input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)
            showPanel()
            return
        }

        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        val inputTop = rect(input).top

        val byId = nodes.filter { idOf(it).endsWith("/message") && txt(it).isNotEmpty() }
        val msgNodes = if (byId.isNotEmpty()) byId else nodes.filter {
            val r = rect(it)
            it.className?.toString()?.endsWith("TextView") == true && !it.isEditable &&
                txt(it).isNotEmpty() && r.top > h * 0.12 && r.bottom < inputTop
        }
        // 위 → 아래 순서로 정렬해서 (글자, 내가 보낸 것인지) 목록 만들기
        val ordered = msgNodes.sortedBy { rect(it).top }.map {
            val r = rect(it)
            val own = (r.left + r.right) / 2 > w * 0.56 // 오른쪽에 붙은 말풍선 = 내가 보낸 것
            val t = txt(it)
            Pair(t, own || sent.contains(t))
        }

        // 이미 보내버린 "/cmds" 말풍선도 인식 (한 번만)
        val lastBubble = ordered.lastOrNull()
        if (lastBubble != null && lastBubble.first == cmd && lastBubble.second) {
            if (!cmdBubbleHandled && !panelShown && cmd.isNotEmpty()) {
                cmdBubbleHandled = true
                showPanel()
                return
            }
        } else cmdBubbleHandled = false

        if (panelShown) return              // 패널이 열려 있는 동안 자동 답장은 쉼
        if (!Cfg.enabled(this)) return

        // 화면에 보이는 모든 글자 (방 이름/상대 이름 확인용)
        val screen = ArrayList<String>()
        for (n in nodes) {
            if (n.isEditable) continue
            val t = txt(n); if (t.isNotEmpty()) screen.add(t)
            val d = n.contentDescription?.toString()?.trim() ?: ""; if (d.isNotEmpty()) screen.add(d)
        }
        val everyone = Cfg.everyone(this)
        val names = Cfg.names(this)
        val present = everyone || names.any { nm -> screen.any { it.contains(nm) } }
        val blocked = Cfg.blocks(this).any { nm -> screen.any { it.contains(nm) } }

        if (ordered.isEmpty()) return

        // 맨 아래에서부터, 내가 보낸 말풍선이 나올 때까지 이어진 상대 메시지 전부
        val run = ArrayList<String>()
        for (i in ordered.indices.reversed()) {
            if (ordered[i].second) break
            run.add(0, ordered[i].first)
        }

        // 다른 채팅방으로 옮겨갔는지 확인: 직전 화면과 겹치는 메시지가 하나도 없으면 방이 바뀐 것
        val allTexts = ordered.map { it.first }
        val overlap = prevAll.isEmpty() || allTexts.any { prevAll.contains(it) }
        prevAll = allTexts
        if (!overlap) {
            handledRun = run
            haveBaseline = true
            stableSig = ""
            Bridge.log("채팅방이 바뀐 것 같아요. 기존 메시지는 기준으로만 잡았어요")
            return
        }

        val wasPresent = presentBefore
        presentBefore = present && !blocked
        if (!present) { note("반응 대상 이름/방이 화면에 없어요 (설정 확인)"); return }
        if (blocked) { note("제외 대상이라 건너뛰어요"); return }
        note("채팅방 감지됨")

        if (!wasPresent || !haveBaseline) { // 처음 보는 상태: 기준만 잡고 답하지 않음
            handledRun = run
            haveBaseline = true
            stableSig = ""
            Bridge.log("기준 설정 (기존 상대 메시지 ${run.size}개)")
            return
        }
        if (run.isEmpty()) { // 마지막이 내 말풍선 → 다음 대화를 새로 시작
            handledRun = emptyList()
            stableSig = ""
            return
        }
        val fresh = freshOf(run, handledRun)
        if (fresh.isEmpty()) { stableSig = ""; return }

        // 상대가 연달아 보내는 중일 수 있어서, 설정한 시간 동안 내용이 안 바뀔 때까지 기다림
        val now = System.currentTimeMillis()
        val sig = fresh.joinToString("\u0001")
        if (sig != stableSig) { stableSig = sig; stableSince = now; return }
        if (now - stableSince < Cfg.waitMs(this)) return
        stableSig = ""
        handledRun = run

        val text = fresh.joinToString("\n")
        val keys = Cfg.keys(this)
        val model = Cfg.model(this)
        val opts = Cfg.opts(this)
        val noEmoji = Cfg.noEmoji(this)
        Bridge.log("새 메시지 ${fresh.size}개: ${text.replace("\n", " / ").take(400)}  (키 ${keys.size}개)")
        busy = true
        worker.execute {
            try {
                history.add("user", text)
                val raw = Gemini.ask(keys, model, history.load(), opts)
                val answer = Gemini.clean(raw, noEmoji)
                if (raw.contains("[SKIP]") || answer.isEmpty()) {
                    Bridge.log("답하지 않음")
                    handler.post { finish() }
                } else {
                    history.add("bot", answer)
                    handler.post { reply(answer) }
                }
            } catch (e: Exception) {
                Bridge.log("AI 실패: ${e.message}")
                handler.post { finish() }
            }
        }
    }

    private fun finish() {
        busy = false
        handler.postDelayed(scanTask, 1000)
    }

    // ---------- 답장 입력 + 전송 ----------
    private fun reply(answer: String) {
        val nodes = currentNodes()
        val input = if (nodes == null) null else findInput(nodes)
        if (input == null) {
            Bridge.log("입력창을 못 찾음 (채팅방이 닫힘?)")
            finish()
            return
        }
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, answer)
        val ok = input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (!ok) Bridge.log("입력창에 글자 넣기 실패")
        if (Cfg.autoSend(this)) {
            handler.postDelayed({ clickSend(answer) }, 600)
        } else {
            Bridge.log("입력창에만 입력함 (자동 전송 꺼짐): ${answer.take(400)}")
            finish()
        }
    }

    private fun clickSend(answer: String) {
        val nodes = currentNodes()
        val btn = nodes?.firstOrNull {
            idOf(it).endsWith("/send") ||
                it.contentDescription?.toString() == "전송" || txt(it) == "전송"
        }
        var done = false
        var n: AccessibilityNodeInfo? = btn
        while (n != null && !done) {
            if (n.isClickable) done = n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        if (done) {
            sent.add(answer)
            while (sent.size > 10) sent.removeAt(0)
            Bridge.log("답장 전송: ${answer.replace("\n", " / ").take(400)}")
        } else {
            Bridge.log("전송 버튼을 못 찾음 (구조 덤프를 보내 주세요)")
        }
        finish()
    }

    // ---------- /cmds 패널 ----------
    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) * (1 - t) + Color.red(b) * t).toInt(),
        (Color.green(a) * (1 - t) + Color.green(b) * t).toInt(),
        (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
    )

    private fun lum(c: Int): Double = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255

    private fun showPanel() {
        if (panelShown) return
        val accent = Cfg.themeColor(this)
        val dark = Cfg.themeDark(this)
        val bg = if (dark) mix(accent, Color.BLACK, 0.82f) else mix(accent, Color.WHITE, 0.90f)
        val fg = if (dark) mix(accent, Color.WHITE, 0.88f) else mix(accent, Color.BLACK, 0.80f)
        val accentText = if (dark) mix(accent, Color.WHITE, 0.35f) else mix(accent, Color.BLACK, 0.25f)
        val inputBg = if (dark) mix(accent, Color.BLACK, 0.68f) else Color.WHITE
        val btnText = if (lum(accent) > 0.6) Color.BLACK else Color.WHITE
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun round(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
            setColor(color)
            cornerRadius = r * dp
            if (stroke != null) setStroke(px(1), stroke)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(18), px(16), px(18), px(16))
            background = round(bg, 22, accent)
        }
        root.addView(TextView(this).apply {
            text = Cfg.cmdWord(this@BotService)
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(accentText)
        })
        val edit = EditText(this).apply {
            hint = "보낼 내용을 적으세요"
            setTextColor(fg)
            setHintTextColor(mix(fg, bg, 0.55f))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            maxLines = 8
            gravity = Gravity.TOP
            background = round(inputBg, 14, mix(accent, bg, 0.5f))
            setPadding(px(12), px(10), px(12), px(10))
        }
        root.addView(edit, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun pill(t: String, bgc: Int, tc: Int, stroke: Int?, bold: Boolean, click: () -> Unit) = TextView(this).apply {
            text = t
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(tc)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            background = round(bgc, 14, stroke)
            setPadding(px(8), px(12), px(8), px(12))
            isClickable = true
            setOnClickListener { click() }
        }
        val lpBtn = { left: Int -> LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = left } }
        row.addView(pill("닫기", Color.TRANSPARENT, accentText, accent, false) { hidePanel() }, lpBtn(0))
        row.addView(pill("전송", accent, btnText, null, true) {
            val text = edit.text.toString().trim()
            hidePanel()
            sendFromPanel(text)
        }, lpBtn(px(10)))
        root.addView(row, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(12) })

        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        )
        lp.dimAmount = 0.45f
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = (resources.displayMetrics.heightPixels * 0.08).toInt()
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(root, lp)
            panel = root
            panelShown = true
            Bridge.log("패널 열림")
            root.postDelayed({
                edit.requestFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(edit, InputMethodManager.SHOW_IMPLICIT)
            }, 300)
        } catch (e: Exception) {
            Bridge.log("패널을 띄우지 못했어요: ${e.message}")
        }
    }

    private fun hidePanel() {
        val v = panel
        if (v != null) {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (e: Exception) { }
        }
        panel = null
        panelShown = false
    }

    /** 패널에서 쓴 내용을 카톡 입력창에 넣고 전송 */
    private fun sendFromPanel(text: String) {
        if (text.isEmpty()) return
        busy = true
        handler.postDelayed({
            val nodes = currentNodes()
            val input = if (nodes == null) null else findInput(nodes)
            if (input == null) {
                Bridge.log("패널 전송 실패: 카톡 입력창을 못 찾음")
                finish()
            } else {
                input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                val args = Bundle()
                args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                handler.postDelayed({ clickSend(text) }, 600)
            }
        }, 400)
    }

    // ---------- 화면 구조 덤프 ----------
    private fun dump(nodes: List<AccessibilityNodeInfo>) {
        val sb = StringBuilder()
        for (n in nodes) {
            val r = rect(n)
            sb.append("${n.className} | id=${idOf(n)} | text=${n.text} | desc=${n.contentDescription}")
              .append(" | edit=${n.isEditable} click=${n.isClickable} | [${r.left},${r.top},${r.right},${r.bottom}]\n")
        }
        val f = File(getExternalFilesDir(null) ?: filesDir, "dump.txt")
        f.writeText(sb.toString())
        Bridge.log("구조 덤프 저장: ${f.absolutePath}")
    }
}
