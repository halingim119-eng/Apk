package com.hyewon.bot

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.File
import java.util.concurrent.Executors

class BotService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val scanTask = Runnable { firstPending = 0L; scan() }
    private lateinit var history: History

    private var handledRun: List<String> = emptyList() // 이미 처리한(또는 기준으로 잡은) 상대 메시지들
    private var haveBaseline = false
    private var presentBefore = false
    private var firstPending = 0L
    @Volatile private var busy = false
    private val sent = ArrayList<String>()

    override fun onServiceConnected() {
        val base = getExternalFilesDir(null) ?: filesDir
        history = History(File(base, "hyewon"))
        Bridge.log("서비스 연결됨. 저장 위치: ${File(base, "hyewon").absolutePath}")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() != "com.kakao.talk") return
        // 상대가 여러 줄/여러 말풍선을 연달아 보내는 걸 기다렸다가 한 번에 처리
        val now = System.currentTimeMillis()
        if (firstPending == 0L) firstPending = now
        handler.removeCallbacks(scanTask)
        handler.postDelayed(scanTask, if (now - firstPending > 5000) 0L else 1800L)
    }

    override fun onInterrupt() {}

    // ---------- 화면 읽기 도우미 ----------
    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, d: Int = 0) {
        if (n == null || d > 60) return
        out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, d + 1)
    }

    private fun idOf(n: AccessibilityNodeInfo) = n.viewIdResourceName ?: ""
    private fun txt(n: AccessibilityNodeInfo) = n.text?.toString()?.trim() ?: ""
    private fun rect(n: AccessibilityNodeInfo): Rect = Rect().also { n.getBoundsInScreen(it) }

    private fun currentNodes(): List<AccessibilityNodeInfo>? {
        val root = rootInActiveWindow ?: return null
        if (root.packageName?.toString() != "com.kakao.talk") return null
        val list = ArrayList<AccessibilityNodeInfo>()
        collect(root, list)
        return list
    }

    // ---------- 새 메시지 확인 ----------
    private fun scan() {
        if (busy || !Cfg.enabled(this)) return
        val nodes = currentNodes() ?: return
        if (Bridge.dumpRequested) {
            Bridge.dumpRequested = false
            dump(nodes)
        }

        val input = nodes.firstOrNull { it.isEditable } ?: return // 채팅방 화면이 아님
        val target = Cfg.target(this)
        val present = nodes.any {
            txt(it).contains(target) || (it.contentDescription?.toString() ?: "").contains(target)
        }

        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        val inputTop = rect(input).top

        val byId = nodes.filter { idOf(it).endsWith("/message") && txt(it).isNotEmpty() }
        val msgNodes = if (byId.isNotEmpty()) byId else nodes.filter {
            val r = rect(it)
            it.className?.toString()?.endsWith("TextView") == true && !it.isEditable &&
                txt(it).isNotEmpty() && r.top > h * 0.12 && r.bottom < inputTop
        }
        // 위 → 아래 순서로 정렬해서 (글자, 내가 보낸 것인지) 목록 만들기
        val ordered = msgNodes.sortedBy { rect(it).top }.map {
            val r = rect(it)
            val own = (r.left + r.right) / 2 > w * 0.56 // 오른쪽에 붙은 말풍선 = 내가 보낸 것
            val t = txt(it)
            Pair(t, own || sent.contains(t))
        }
        if (ordered.isEmpty()) return

        // 맨 아래에서부터, 내가 보낸 말풍선이 나올 때까지 이어진 상대 메시지 전부
        val run = ArrayList<String>()
        for (i in ordered.indices.reversed()) {
            if (ordered[i].second) break
            run.add(0, ordered[i].first)
        }

        val wasPresent = presentBefore
        presentBefore = present
        if (!present) return

        if (!wasPresent || !haveBaseline) { // 처음 보는 상태: 기준만 잡고 답하지 않음
            handledRun = run
            haveBaseline = true
            Bridge.log("기준 설정 (기존 상대 메시지 ${run.size}개)")
            return
        }
        if (run.isEmpty()) { // 마지막이 내 말풍선 → 다음 대화를 새로 시작
            handledRun = emptyList()
            return
        }
        val fresh = if (run.size >= handledRun.size && run.subList(0, handledRun.size) == handledRun)
            run.drop(handledRun.size) else run
        if (fresh.isEmpty()) return
        handledRun = run

        val text = fresh.joinToString("\n")
        val keys = Cfg.keys(this)
        val model = Cfg.model(this)
        Bridge.log("새 메시지 ${fresh.size}개: ${text.replace("\n", " / ").take(40)}  (키 ${keys.size}개)")
        busy = true
        worker.execute {
            try {
                history.add("user", text)
                val raw = Gemini.ask(keys, model, history.load())
                val answer = Gemini.clean(raw)
                if (raw.contains("[SKIP]") || answer.isEmpty()) {
                    Bridge.log("답하지 않음")
                    handler.post { finish() }
                } else {
                    history.add("bot", answer)
                    handler.post { reply(answer) }
                }
            } catch (e: Exception) {
                Bridge.log("AI 실패: ${e.message}")
                handler.post { finish() }
            }
        }
    }

    private fun finish() {
        busy = false
        handler.postDelayed(scanTask, 1000)
    }

    // ---------- 답장 입력 + 전송 ----------
    private fun reply(answer: String) {
        val input = currentNodes()?.firstOrNull { it.isEditable }
        if (input == null) {
            Bridge.log("입력창을 못 찾음 (채팅방이 닫힘?)")
            finish()
            return
        }
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, answer)
        val ok = input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (!ok) Bridge.log("입력창에 글자 넣기 실패")
        handler.postDelayed({ clickSend(answer) }, 500)
    }

    private fun clickSend(answer: String) {
        val nodes = currentNodes()
        val btn = nodes?.firstOrNull {
            idOf(it).endsWith("/send") ||
                it.contentDescription?.toString() == "전송" || txt(it) == "전송"
        }
        var done = false
        var n: AccessibilityNodeInfo? = btn
        while (n != null && !done) {
            if (n.isClickable) done = n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        if (done) {
            sent.add(answer)
            while (sent.size > 10) sent.removeAt(0)
            Bridge.log("답장 전송: ${answer.take(30)}")
        } else {
            Bridge.log("전송 버튼을 못 찾음 (구조 덤프를 보내 주세요)")
        }
        finish()
    }

    // ---------- 화면 구조 덤프 ----------
    private fun dump(nodes: List<AccessibilityNodeInfo>) {
        val sb = StringBuilder()
        for (n in nodes) {
            val r = rect(n)
            sb.append("${n.className} | id=${idOf(n)} | text=${n.text} | desc=${n.contentDescription}")
              .append(" | edit=${n.isEditable} click=${n.isClickable} | [${r.left},${r.top},${r.right},${r.bottom}]\n")
        }
        val f = File(getExternalFilesDir(null) ?: filesDir, "dump.txt")
        f.writeText(sb.toString())
        Bridge.log("구조 덤프 저장: ${f.absolutePath}")
    }
}
