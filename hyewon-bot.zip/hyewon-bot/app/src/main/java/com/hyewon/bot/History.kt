package com.hyewon.bot

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Entry(val role: String, val text: String, val time: String)

/** 최근 100개는 recent.json, 넘치는 건 archive_연-월.jsonl 로 이동 */
class History(private val dir: File) {
    private val recent = File(dir, "recent.json")
    private val maxKeep = 100

    init { dir.mkdirs() }

    private fun toJson(e: Entry) = JSONObject().put("role", e.role).put("text", e.text).put("time", e.time)

    @Synchronized
    fun load(): MutableList<Entry> {
        if (!recent.exists()) return mutableListOf()
        return try {
            val a = JSONArray(recent.readText())
            MutableList(a.length()) {
                val o = a.getJSONObject(it)
                Entry(o.getString("role"), o.getString("text"), o.getString("time"))
            }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    @Synchronized
    fun add(role: String, text: String) {
        val list = load()
        list.add(Entry(role, text, SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.KOREA).format(Date())))
        var keep: List<Entry> = list
        if (list.size > maxKeep) {
            val overflow = list.size - maxKeep
            val old = list.take(overflow)
            keep = list.drop(overflow)
            val ym = SimpleDateFormat("yyyy-MM", Locale.KOREA).format(Date())
            File(dir, "archive_$ym.jsonl").appendText(old.joinToString("\n") { toJson(it).toString() } + "\n")
        }
        val arr = JSONArray()
        keep.forEach { arr.put(toJson(it)) }
        recent.writeText(arr.toString(1))
    }
}
