# 혜원 봇 (카카오톡 접근성 서비스)

1. 이 폴더 전체를 GitHub 저장소에 올리기 (비공개 저장소 추천)
2. Actions 탭 → Build APK → 실행이 끝나면 Artifacts 의 hyewon-bot-apk 다운로드
3. 압축을 풀어 app-debug.apk 설치
4. 앱을 열어 API 키 입력 → 저장 → 접근성 설정에서 '혜원 봇' 켜기
5. 카톡에서 혜원씌 채팅방을 열어 둔 상태(화면 켜짐)에서 동작
